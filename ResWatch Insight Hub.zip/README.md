# ResWatch

Retail intelligence dashboard built with TanStack Start, React 19, Vite, Tailwind v4, and Supabase. AI chat is powered by Google Gemini (2.5 Flash).

## Prerequisites

- Node.js 20+ and npm 10+

## Setup

```bash
npm install
```

Then create / fill in `.env` at the project root:

```env
# Supabase (Lovable Cloud) — required
VITE_SUPABASE_PROJECT_ID="your-project-id"
VITE_SUPABASE_PUBLISHABLE_KEY="sb_publishable_xxx"
VITE_SUPABASE_URL="https://your-project-id.supabase.co"
SUPABASE_PROJECT_ID="your-project-id"
SUPABASE_PUBLISHABLE_KEY="sb_publishable_xxx"
SUPABASE_URL="https://your-project-id.supabase.co"

# Google Gemini — required for AI chat
GEMINI_API_KEY="your_gemini_api_key"
```

## Scripts

```bash
npm run dev       # local dev server
npm run build     # production build
npm run preview   # serve the production build locally
npm run lint      # eslint
npm run format    # prettier
```

## Project structure

- `src/routes/` — file-based routes (TanStack Router)
- `src/routes/api/` — server routes (e.g. `api/chat.ts` for Gemini streaming)
- `src/lib/` — data, services, and server helpers (`ai-context.server.ts` feeds the AI live app data)
- `src/components/` — UI + dashboard components
- `src/integrations/supabase/` — auto-generated Supabase client (do not edit)
