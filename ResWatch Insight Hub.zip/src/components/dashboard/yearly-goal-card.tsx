export function YearlyGoalCard({
  current,
  goal,
}: {
  current: number | null;
  goal: number | null;
}) {
  const c = current ?? 0;
  const g = goal ?? 0;
  const pct = g > 0 ? Math.min(100, Math.round((c / g) * 100)) : 0;
  const remaining = Math.max(0, g - c);
  const fmt = (n: number) => `RM ${n.toLocaleString("en-MY")}`;

  // Year-to-date progress to compare pace vs target
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 1);
  const end = new Date(now.getFullYear() + 1, 0, 1);
  const yearPct = Math.round(((now.getTime() - start.getTime()) / (end.getTime() - start.getTime())) * 100);
  const onPace = pct >= yearPct;

  return (
    <div className="rounded-2xl border-2 border-accent-blue bg-primary/40 p-5">
      <div className="flex items-baseline justify-between">
        <h2 className="text-base font-bold">Yearly Sales Goal</h2>
        <span className={`text-[10px] font-semibold uppercase tracking-wide ${onPace ? "text-emerald-400" : "text-amber-400"}`}>
          {onPace ? "On pace" : "Behind"}
        </span>
      </div>

      <div className="mt-4">
        <div className="flex items-baseline justify-between">
          <span className="text-2xl font-semibold">{fmt(c)}</span>
          <span className="text-xs text-muted-foreground">of {fmt(g)}</span>
        </div>

        <div className="relative mt-3 h-2.5 w-full overflow-hidden rounded-full bg-primary/70">
          {/* year progress marker */}
          <div
            className="absolute top-0 h-full w-px bg-foreground/40"
            style={{ left: `${yearPct}%` }}
            aria-label={`Year ${yearPct}% elapsed`}
          />
          <div
            className="h-full rounded-full bg-accent-blue transition-all"
            style={{ width: `${pct}%` }}
          />
        </div>

        <div className="mt-2 flex items-center justify-between text-[11px] text-muted-foreground">
          <span>{pct}% complete</span>
          <span>{yearPct}% of year elapsed</span>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3 border-t border-border/40 pt-3 text-xs">
        <div>
          <p className="text-muted-foreground">Remaining</p>
          <p className="mt-0.5 text-sm font-semibold">{fmt(remaining)}</p>
        </div>
        <div>
          <p className="text-muted-foreground">Gap vs pace</p>
          <p className={`mt-0.5 text-sm font-semibold ${onPace ? "text-emerald-400" : "text-amber-400"}`}>
            {onPace ? "+" : ""}{(pct - yearPct).toFixed(0)} pp
          </p>
        </div>
      </div>
    </div>
  );
}
