import { Star } from "lucide-react";

export function ReviewsCard({
  rating = 5,
  quote = "Saved my company lots of money",
}: {
  rating?: number;
  quote?: string;
}) {
  return (
    <div className="group rounded-2xl border-2 border-accent-blue bg-primary/40 p-5 transition-transform duration-300 hover:-translate-y-1 hover:shadow-glow-blue">
      <p className="text-xs font-semibold tracking-wider text-foreground/80">REVIEWS</p>
      <div className="mt-4 rounded-xl bg-primary/70 p-4">
        <div className="flex items-center gap-1">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star
              key={i}
              className={[
                "h-6 w-6 transition-all duration-300",
                i < rating ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground",
                "group-hover:scale-125 group-hover:drop-shadow-[0_0_8px_rgba(250,204,21,0.85)]",
              ].join(" ")}
              style={{ transitionDelay: `${i * 60}ms` }}
            />
          ))}
        </div>
        <p className="mt-3 text-sm leading-snug text-foreground/90">{quote}</p>
      </div>
    </div>
  );
}
