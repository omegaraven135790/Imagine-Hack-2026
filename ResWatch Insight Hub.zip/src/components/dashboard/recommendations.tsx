export type Recommendation = { id: string; text: string };

export function Recommendations({ items }: { items: Recommendation[] }) {
  return (
    <div className="rounded-2xl bg-accent-blue p-6 text-accent-blue-foreground shadow-glow-blue">
      <h2 className="text-lg font-semibold">Recommendation for Improvement</h2>
      <ul className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
        {items.map((item) => (
          <li
            key={item.id}
            className="rounded-lg bg-primary/80 px-4 py-2.5 text-sm font-medium"
          >
            • {item.text}
          </li>
        ))}
      </ul>
    </div>
  );
}
