import type { ReactNode } from "react";

export type Metric = {
  label: string;
  value: string;
  icon?: ReactNode;
};

export function MetricCard({ label, value, icon }: Metric) {
  return (
    <div className="rounded-2xl bg-accent-blue p-5 text-accent-blue-foreground shadow-glow-blue">
      <p className="text-xs font-medium opacity-80">{label}</p>
      <div className="mt-4 flex items-center gap-2 text-2xl font-bold">
        {icon}
        <span>{value}</span>
      </div>
    </div>
  );
}
