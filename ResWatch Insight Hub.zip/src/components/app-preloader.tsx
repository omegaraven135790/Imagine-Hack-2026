import { useEffect, useState } from "react";
import { useRouter } from "@tanstack/react-router";

const ROUTES = [
  "/",
  "/ai-chat",
  "/anomalies",
  "/energy-water",
  "/footfall-sales",
  "/forecast",
  "/insights",
  "/inventory",
  "/schedule",
  "/settings",
  "/transportation",
  "/waste-savings",
] as const;

const MAX_WAIT_MS = 10_000;

export function AppPreloader({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let cancelled = false;
    const total = ROUTES.length;
    let done = 0;

    const bump = () => {
      done += 1;
      if (!cancelled) setProgress(Math.round((done / total) * 100));
    };

    const all = Promise.all(
      ROUTES.map((to) =>
        router
          .preloadRoute({ to } as never)
          .catch(() => undefined)
          .finally(bump),
      ),
    );

    const timeout = new Promise<void>((res) => setTimeout(res, MAX_WAIT_MS));

    Promise.race([all, timeout]).then(() => {
      if (!cancelled) setReady(true);
    });

    return () => {
      cancelled = true;
    };
  }, [router]);

  return (
    <>
      {children}
      {!ready && (
        <div
          aria-hidden={ready}
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center gap-6 bg-background transition-opacity duration-300"
        >
          <div className="flex flex-col items-center gap-3">
            <div className="h-10 w-10 animate-spin rounded-full border-2 border-muted border-t-primary" />
            <p className="text-sm font-medium text-foreground">Preparing ResWatch…</p>
            <p className="text-xs text-muted-foreground">
              Warming up pages so everything's instant
            </p>
          </div>
          <div className="h-1 w-56 overflow-hidden rounded-full bg-muted">
            <div
              className="h-full bg-primary transition-all duration-200 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      )}
    </>
  );
}
