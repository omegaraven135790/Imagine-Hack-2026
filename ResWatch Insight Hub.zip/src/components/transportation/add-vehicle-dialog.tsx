import { useState } from "react";
import { Plus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { tx, type FuelType, type VehicleStatus } from "@/lib/transportation-data";

export function AddVehicleDialog({ onAdded }: { onAdded: () => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    registration_no: "",
    label: "",
    make: "",
    model: "",
    vehicle_type: "van",
    fuel_type: "diesel" as FuelType,
    capacity_kg: "",
    odometer_km: "",
    assigned_driver: "",
    status: "active" as VehicleStatus,
  });

  const update = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  const submit = () => {
    if (!form.registration_no.trim() || !form.label.trim()) {
      toast.error("Registration and label are required");
      return;
    }
    tx.addVehicle({
      registration_no: form.registration_no.trim(),
      label: form.label.trim(),
      make: form.make || undefined,
      model: form.model || undefined,
      vehicle_type: form.vehicle_type,
      fuel_type: form.fuel_type,
      capacity_kg: form.capacity_kg ? Number(form.capacity_kg) : undefined,
      odometer_km: form.odometer_km ? Number(form.odometer_km) : 0,
      assigned_driver: form.assigned_driver || undefined,
      status: form.status,
    });
    toast.success(`${form.label} added to fleet`);
    setOpen(false);
    setForm({ ...form, registration_no: "", label: "", make: "", model: "", capacity_kg: "", odometer_km: "", assigned_driver: "" });
    onAdded();
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" className="gap-1.5">
          <Plus className="h-4 w-4" /> Add vehicle
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[520px]">
        <DialogHeader>
          <DialogTitle>Add a vehicle</DialogTitle>
          <DialogDescription>Register a new rig to the fleet.</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4">
          <Field label="Registration *">
            <Input value={form.registration_no} onChange={(e) => update("registration_no", e.target.value)} placeholder="ABC 1234" />
          </Field>
          <Field label="Label *">
            <Input value={form.label} onChange={(e) => update("label", e.target.value)} placeholder="Penguin" />
          </Field>
          <Field label="Make">
            <Input value={form.make} onChange={(e) => update("make", e.target.value)} />
          </Field>
          <Field label="Model">
            <Input value={form.model} onChange={(e) => update("model", e.target.value)} />
          </Field>
          <Field label="Vehicle type">
            <Select value={form.vehicle_type} onValueChange={(v) => update("vehicle_type", v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {["van", "truck", "pickup", "trailer"].map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Fuel">
            <Select value={form.fuel_type} onValueChange={(v) => update("fuel_type", v as FuelType)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {(["electric", "hybrid", "diesel", "petrol"] as FuelType[]).map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Capacity (kg)">
            <Input inputMode="numeric" value={form.capacity_kg} onChange={(e) => update("capacity_kg", e.target.value)} />
          </Field>
          <Field label="Odometer (km)">
            <Input inputMode="numeric" value={form.odometer_km} onChange={(e) => update("odometer_km", e.target.value)} />
          </Field>
          <Field label="Driver">
            <Input value={form.assigned_driver} onChange={(e) => update("assigned_driver", e.target.value)} />
          </Field>
          <Field label="Status">
            <Select value={form.status} onValueChange={(v) => update("status", v as VehicleStatus)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {(["active", "maintenance", "inactive"] as VehicleStatus[]).map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={submit}>Add vehicle</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label className="text-xs">{label}</Label>
      {children}
    </div>
  );
}
