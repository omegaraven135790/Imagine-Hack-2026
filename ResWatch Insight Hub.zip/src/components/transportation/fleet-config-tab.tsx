import { useMemo, useState } from "react";
import { Plus, Trash2, Truck, MapPin, Users } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { AddVehicleDialog } from "./add-vehicle-dialog";
import { tx } from "@/lib/transportation-data";

export function FleetConfigTab({ onChange }: { onChange: () => void }) {
  const fleets = useMemo(() => tx.fleets(), []);
  const vehicles = useMemo(() => tx.vehicles(), []);
  const routes = useMemo(() => tx.routes(), []);
  const locations = useMemo(() => tx.locations(), []);

  return (
    <div className="flex flex-col gap-6">
      {/* FLEETS */}
      <section className="rounded-2xl border border-border bg-surface p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-lg font-semibold">
            <Users className="h-5 w-5 text-accent-blue" /> Fleets · {fleets.length}
          </h2>
          <AddFleetDialog onAdded={onChange} />
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {fleets.map((f) => {
            const count = vehicles.filter((v) => v.fleet_id === f.id).length;
            return (
              <div key={f.id} className="rounded-xl border border-border bg-primary/20 p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <span className="h-3 w-3 rounded-full" style={{ background: f.color }} />
                    <div>
                      <div className="font-semibold">{f.name}</div>
                      <div className="text-xs text-muted-foreground">{f.description}</div>
                    </div>
                  </div>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => {
                      tx.removeFleet(f.id);
                      toast.success(`${f.name} removed`);
                      onChange();
                    }}
                  >
                    <Trash2 className="h-4 w-4 text-rose-300" />
                  </Button>
                </div>
                <div className="mt-3 text-xs text-muted-foreground">{count} vehicle{count === 1 ? "" : "s"}</div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ROUTES */}
      <section className="rounded-2xl border border-border bg-surface p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-lg font-semibold">
            <MapPin className="h-5 w-5 text-accent-blue" /> Routes · {routes.length}
          </h2>
          <AddRouteDialog onAdded={onChange} />
        </div>
        <div className="grid gap-2">
          {routes.map((r) => {
            const allocated = vehicles.filter((v) => (v.assigned_route_ids ?? []).includes(r.id));
            return (
              <div key={r.id} className="flex items-center justify-between rounded-xl border border-border bg-primary/20 p-3">
                <div>
                  <div className="font-medium">{r.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {r.planned_distance_km} km · plan {Math.round(r.estimated_duration_minutes / 60)}h{r.estimated_duration_minutes % 60 ? ` ${r.estimated_duration_minutes % 60}m` : ""} · {allocated.length} allocated vehicle{allocated.length === 1 ? "" : "s"}
                  </div>
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => {
                    tx.removeRoute(r.id);
                    toast.success(`${r.name} removed`);
                    onChange();
                  }}
                >
                  <Trash2 className="h-4 w-4 text-rose-300" />
                </Button>
              </div>
            );
          })}
        </div>
      </section>

      {/* VEHICLES */}
      <section className="rounded-2xl border border-border bg-surface p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-lg font-semibold">
            <Truck className="h-5 w-5 text-accent-blue" /> Vehicles · {vehicles.length}
          </h2>
          <AddVehicleDialog onAdded={onChange} />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-left text-xs uppercase tracking-wider text-muted-foreground">
              <tr className="border-b border-border">
                <th className="px-2 py-2">Vehicle</th>
                <th className="px-2 py-2">Fleet</th>
                <th className="px-2 py-2">Allocated routes</th>
                <th className="px-2 py-2">Status</th>
                <th className="px-2 py-2"></th>
              </tr>
            </thead>
            <tbody>
              {vehicles.map((v) => (
                <tr key={v.id} className="border-b border-border/50">
                  <td className="px-2 py-3">
                    <div className="font-medium">{v.label}</div>
                    <div className="text-xs text-muted-foreground">{v.registration_no} · {v.capacity_m3 ?? "—"} m³</div>
                  </td>
                  <td className="px-2 py-3">
                    <Select
                      value={v.fleet_id ?? "none"}
                      onValueChange={(val) => {
                        tx.assignVehicleToFleet(v.id, val === "none" ? undefined : val);
                        onChange();
                      }}
                    >
                      <SelectTrigger className="h-8 w-[180px]"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">— Unassigned —</SelectItem>
                        {fleets.map((f) => <SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="px-2 py-3">
                    <div className="flex flex-wrap gap-1">
                      {routes.map((r) => {
                        const on = (v.assigned_route_ids ?? []).includes(r.id);
                        return (
                          <button
                            key={r.id}
                            onClick={() => { tx.toggleVehicleRoute(v.id, r.id); onChange(); }}
                            className={[
                              "rounded-full border px-2 py-0.5 text-[11px] transition-colors",
                              on
                                ? "border-accent-blue/60 bg-accent-blue/20 text-accent-blue"
                                : "border-border bg-background/40 text-muted-foreground hover:border-accent-blue/40",
                            ].join(" ")}
                          >
                            {r.name}
                          </button>
                        );
                      })}
                    </div>
                  </td>
                  <td className="px-2 py-3">
                    <Select
                      value={v.status}
                      onValueChange={(val) => {
                        tx.updateVehicle(v.id, { status: val as typeof v.status });
                        onChange();
                      }}
                    >
                      <SelectTrigger className="h-8 w-[130px]"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {(["active", "maintenance", "inactive"] as const).map((s) => (
                          <SelectItem key={s} value={s}>{s}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </td>
                  <td className="px-2 py-3 text-right">
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => {
                        if (confirm(`Remove ${v.label}?`)) {
                          tx.removeVehicle(v.id);
                          toast.success(`${v.label} removed from fleet`);
                          onChange();
                        }
                      }}
                    >
                      <Trash2 className="h-4 w-4 text-rose-300" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

function AddFleetDialog({ onAdded }: { onAdded: () => void }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [color, setColor] = useState("#1E60FF");

  const submit = () => {
    if (!name.trim()) { toast.error("Fleet name required"); return; }
    tx.addFleet({ name: name.trim(), description: description.trim() || undefined, color });
    toast.success(`Fleet ${name} created`);
    setName(""); setDescription(""); setColor("#1E60FF");
    setOpen(false);
    onAdded();
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" className="gap-1.5"><Plus className="h-4 w-4" /> New fleet</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[440px]">
        <DialogHeader>
          <DialogTitle>Create a fleet</DialogTitle>
          <DialogDescription>Group vehicles for routing & ops.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-3">
          <Field label="Name"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Northern Express" /></Field>
          <Field label="Description"><Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Long-haul up north" /></Field>
          <Field label="Color">
            <div className="flex items-center gap-2">
              <input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="h-9 w-12 cursor-pointer rounded border border-border bg-transparent" />
              <span className="text-xs text-muted-foreground">{color}</span>
            </div>
          </Field>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={submit}>Create</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function AddRouteDialog({ onAdded }: { onAdded: () => void }) {
  const [open, setOpen] = useState(false);
  const locations = tx.locations();
  const [name, setName] = useState("");
  const [origin, setOrigin] = useState(locations[0]?.id ?? "");
  const [destination, setDestination] = useState(locations[1]?.id ?? "");
  const [distance, setDistance] = useState("");
  const [duration, setDuration] = useState("");

  const submit = () => {
    if (!name.trim() || !origin || !destination || !distance || !duration) {
      toast.error("All fields are required"); return;
    }
    if (origin === destination) { toast.error("Origin and destination must differ"); return; }
    tx.addRoute({
      name: name.trim(),
      origin_location_id: origin,
      destination_location_id: destination,
      planned_distance_km: Number(distance),
      estimated_duration_minutes: Number(duration),
    });
    toast.success(`Route ${name} added`);
    setName(""); setDistance(""); setDuration("");
    setOpen(false);
    onAdded();
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" className="gap-1.5"><Plus className="h-4 w-4" /> New route</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add a route</DialogTitle>
          <DialogDescription>Define a planned origin → destination corridor.</DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Name" className="col-span-2"><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="KL → Melaka" /></Field>
          <Field label="Origin">
            <Select value={origin} onValueChange={setOrigin}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{locations.map((l) => <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Field label="Destination">
            <Select value={destination} onValueChange={setDestination}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{locations.map((l) => <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>)}</SelectContent>
            </Select>
          </Field>
          <Field label="Distance (km)"><Input inputMode="numeric" value={distance} onChange={(e) => setDistance(e.target.value)} /></Field>
          <Field label="Est. duration (min)"><Input inputMode="numeric" value={duration} onChange={(e) => setDuration(e.target.value)} /></Field>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={submit}>Add route</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, children, className }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={["flex flex-col gap-1.5", className ?? ""].join(" ")}>
      <Label className="text-xs">{label}</Label>
      {children}
    </div>
  );
}
