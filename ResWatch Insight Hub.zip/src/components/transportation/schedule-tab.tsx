import { useEffect, useMemo, useState } from "react";
import {
  Calendar,
  Clock,
  Truck,
  Sparkles,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  Check,
  CheckCheck,
  History,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { buildWeeklySchedule, type ScheduleSlot } from "@/lib/transportation-schedule";

const PRIORITY_STYLES: Record<ScheduleSlot["priority"], string> = {
  high: "bg-rose-500/20 text-rose-300 border-rose-500/40",
  normal: "bg-accent-blue/20 text-accent-blue border-accent-blue/40",
  low: "bg-zinc-500/20 text-zinc-300 border-zinc-500/40",
};

const ANCHOR = new Date("2026-06-20T00:00:00Z");

export function ScheduleTab({ tick }: { tick: number }) {
  const [includeWeekends, setIncludeWeekends] = useState(true);
  const [seed, setSeed] = useState(0);
  const [approved, setApproved] = useState<ScheduleSlot[]>([]);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});

  // Initial "current" schedule once on mount (so there's something to compare to)
  useEffect(() => {
    setApproved(buildWeeklySchedule(ANCHOR, { includeWeekends: true, seed: 0 }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const suggested = useMemo(
    () => buildWeeklySchedule(ANCHOR, { includeWeekends, seed }),
    [includeWeekends, seed, tick],
  );

  const approvedIds = useMemo(() => new Set(approved.map((s) => s.id)), [approved]);

  const byDay = useMemo(() => {
    const days: Record<string, { suggested: ScheduleSlot[]; current: ScheduleSlot[] }> = {};
    suggested.forEach((s) => {
      (days[s.date] ||= { suggested: [], current: [] }).suggested.push(s);
    });
    approved.forEach((s) => {
      (days[s.date] ||= { suggested: [], current: [] }).current.push(s);
    });
    return days;
  }, [suggested, approved]);

  const sortedDays = useMemo(() => Object.keys(byDay).sort(), [byDay]);

  const summary = useMemo(() => {
    const totalKm = suggested.reduce((a, s) => a + s.route.planned_distance_km, 0);
    const currentKm = approved.reduce((a, s) => a + s.route.planned_distance_km, 0);
    const delta = suggested.length - approved.length;
    return {
      total: suggested.length,
      high: suggested.filter((s) => s.priority === "high").length,
      low: suggested.filter((s) => s.priority === "low").length,
      totalKm,
      currentCount: approved.length,
      currentKm,
      delta,
    };
  }, [suggested, approved]);

  const recalculate = () => {
    setSeed((s) => s + 1);
    toast.success("Recalculated suggested schedule", {
      description: "Re-ran the algorithm with fresh jitter on demand baselines.",
    });
  };

  const approveSlot = (slot: ScheduleSlot) => {
    setApproved((prev) => {
      if (prev.find((p) => p.id === slot.id)) return prev;
      // replace any current slot for same route+date+hour
      const filtered = prev.filter(
        (p) => !(p.route.id === slot.route.id && p.date === slot.date && p.departHour === slot.departHour),
      );
      return [...filtered, slot];
    });
    toast.success(`Approved ${slot.route.name} @ ${String(slot.departHour).padStart(2, "0")}:00`);
  };

  const approveDay = (date: string) => {
    const daySuggested = suggested.filter((s) => s.date === date);
    setApproved((prev) => {
      const others = prev.filter((p) => p.date !== date);
      return [...others, ...daySuggested];
    });
    const d = new Date(date + "T00:00:00Z").toLocaleDateString(undefined, {
      weekday: "long",
      timeZone: "UTC",
    });
    toast.success(`Approved all ${daySuggested.length} trips for ${d}`);
  };

  const approveAll = () => {
    setApproved(suggested);
    toast.success("Suggested schedule promoted to current", {
      description: `${suggested.length} trips approved across 7 days.`,
    });
  };

  return (
    <div className="flex flex-col gap-4">
      {/* Header / controls */}
      <div className="rounded-2xl border border-accent-blue/30 bg-accent-blue/10 p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-sm font-semibold text-accent-blue">
              <Sparkles className="h-4 w-4" /> Suggested Schedule
            </div>
            <p className="mt-1 max-w-2xl text-xs text-muted-foreground">
              Derived from last 30-day demand, week-over-week trend, average cargo fill, and allocated active vehicles.
              Departure windows avoid 07–09 / 17–19 congestion.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 rounded-lg border border-border bg-background/40 px-3 py-2">
              <Checkbox
                id="include-weekends"
                checked={includeWeekends}
                onCheckedChange={(v) => setIncludeWeekends(!!v)}
              />
              <Label htmlFor="include-weekends" className="cursor-pointer text-xs">
                Include weekends
              </Label>
            </div>
            <Button size="sm" variant="outline" onClick={recalculate}>
              <RefreshCw className="mr-1.5 h-3.5 w-3.5" />
              Recalculate
            </Button>
            <Button size="sm" onClick={approveAll}>
              <CheckCheck className="mr-1.5 h-3.5 w-3.5" />
              Approve all
            </Button>
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <SummaryTile label="Suggested trips" value={String(summary.total)} sub={`${summary.totalKm.toLocaleString()} km`} />
          <SummaryTile label="High priority" value={String(summary.high)} accent="rose" />
          <SummaryTile label="Low / consolidate" value={String(summary.low)} />
          <SummaryTile
            label="Current schedule"
            value={String(summary.currentCount)}
            sub={`${summary.currentKm.toLocaleString()} km · Δ ${summary.delta >= 0 ? "+" : ""}${summary.delta}`}
          />
        </div>
      </div>

      {sortedDays.length === 0 && (
        <div className="rounded-2xl border border-border bg-surface p-10 text-center">
          <Sparkles className="mx-auto h-8 w-8 text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">
            No demand history yet. Once shipments are recorded the scheduler will recommend trips here.
          </p>
        </div>
      )}

      {sortedDays.map((date) => {
        const { suggested: daySuggested, current: dayCurrent } = byDay[date];
        const d = new Date(date + "T00:00:00Z");
        const allApproved =
          daySuggested.length > 0 && daySuggested.every((s) => approvedIds.has(s.id));
        return (
          <div key={date} className="rounded-2xl border border-border bg-surface p-5">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-accent-blue" />
                <h3 className="font-semibold">
                  {d.toLocaleDateString(undefined, {
                    weekday: "long",
                    month: "short",
                    day: "numeric",
                    timeZone: "UTC",
                  })}
                </h3>
                <Badge className="bg-muted text-muted-foreground">
                  {daySuggested.length} suggested · {dayCurrent.length} current
                </Badge>
              </div>
              <Button
                size="sm"
                variant={allApproved ? "secondary" : "outline"}
                disabled={daySuggested.length === 0 || allApproved}
                onClick={() => approveDay(date)}
              >
                <Check className="mr-1.5 h-3.5 w-3.5" />
                {allApproved ? "Day approved" : "Approve day"}
              </Button>
            </div>

            <div className="grid gap-4 lg:grid-cols-2">
              {/* Suggested column */}
              <div>
                <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-accent-blue">
                  <Sparkles className="h-3 w-3" /> Suggested
                </div>
                <div className="grid gap-2">
                  {daySuggested.length === 0 && (
                    <EmptyHint>No trips suggested for this day.</EmptyHint>
                  )}
                  {daySuggested.map((slot) => {
                    const isOpen = !!expanded[slot.id];
                    const isApproved = approvedIds.has(slot.id);
                    return (
                      <div
                        key={slot.id}
                        className={[
                          "rounded-xl border",
                          isApproved
                            ? "border-emerald-500/40 bg-emerald-500/10"
                            : "border-border bg-primary/20",
                        ].join(" ")}
                      >
                        <div className="flex items-center justify-between gap-2 p-3">
                          <button
                            onClick={() => setExpanded((e) => ({ ...e, [slot.id]: !e[slot.id] }))}
                            className="flex flex-1 items-center gap-3 text-left text-sm"
                          >
                            <span className="flex items-center gap-1 font-mono text-accent-blue">
                              <Clock className="h-3.5 w-3.5" />
                              {String(slot.departHour).padStart(2, "0")}:00
                            </span>
                            <span className="font-medium">{slot.route.name}</span>
                            <Badge className={["border text-[10px]", PRIORITY_STYLES[slot.priority]].join(" ")}>
                              {slot.priority}
                            </Badge>
                            {isOpen ? (
                              <ChevronUp className="ml-auto h-4 w-4 text-muted-foreground" />
                            ) : (
                              <ChevronDown className="ml-auto h-4 w-4 text-muted-foreground" />
                            )}
                          </button>
                          <Button
                            size="sm"
                            variant={isApproved ? "secondary" : "default"}
                            disabled={isApproved}
                            onClick={() => approveSlot(slot)}
                          >
                            <Check className="mr-1 h-3 w-3" />
                            {isApproved ? "Approved" : "Approve"}
                          </Button>
                        </div>
                        <div className="border-t border-border/60 px-3 pb-2 pt-2 text-xs text-muted-foreground">
                          <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                            <span className="flex items-center gap-1">
                              <Truck className="h-3 w-3" />
                              {slot.vehicle?.label ?? "Unassigned"}
                            </span>
                            <span>
                              {slot.recommendedLoadM3} / {slot.capacityM3} m³ ({slot.fillPct}%)
                            </span>
                            <span>{slot.route.planned_distance_km} km</span>
                          </div>
                        </div>
                        {isOpen && (
                          <div className="border-t border-border bg-background/40 p-3">
                            <h4 className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                              Why this slot
                            </h4>
                            <ul className="space-y-1 text-xs">
                              {slot.reasoning.map((r, i) => (
                                <li key={i} className="flex gap-2 text-muted-foreground">
                                  <span className="text-accent-blue">•</span>
                                  <span>{r}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Current column */}
              <div>
                <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  <History className="h-3 w-3" /> Current (approved)
                </div>
                <div className="grid gap-2">
                  {dayCurrent.length === 0 && (
                    <EmptyHint>No approved trips for this day.</EmptyHint>
                  )}
                  {dayCurrent.map((slot) => (
                    <div
                      key={slot.id}
                      className="rounded-xl border border-border bg-background/40 p-3 text-sm"
                    >
                      <div className="flex items-center gap-3">
                        <span className="flex items-center gap-1 font-mono text-muted-foreground">
                          <Clock className="h-3.5 w-3.5" />
                          {String(slot.departHour).padStart(2, "0")}:00
                        </span>
                        <span className="font-medium">{slot.route.name}</span>
                        <Badge className="ml-auto border border-emerald-500/40 bg-emerald-500/10 text-[10px] text-emerald-300">
                          active
                        </Badge>
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Truck className="h-3 w-3" />
                          {slot.vehicle?.label ?? "Unassigned"}
                        </span>
                        <span>
                          {slot.recommendedLoadM3} / {slot.capacityM3} m³ ({slot.fillPct}%)
                        </span>
                        <span>{slot.route.planned_distance_km} km</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );
      })}

      <div className="rounded-xl border border-dashed border-border p-3 text-center text-xs text-muted-foreground">
        Tip: allocate vehicles to specific routes in <strong>Fleet Configuration</strong> for more accurate matching.
      </div>
    </div>
  );
}

function SummaryTile({
  label,
  value,
  sub,
  accent,
}: {
  label: string;
  value: string;
  sub?: string;
  accent?: "rose";
}) {
  return (
    <div className="rounded-xl bg-background/40 p-3">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={["mt-1 text-lg font-bold", accent === "rose" ? "text-rose-300" : ""].join(" ")}>{value}</div>
      {sub && <div className="text-[10px] text-muted-foreground">{sub}</div>}
    </div>
  );
}

function EmptyHint({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-dashed border-border/60 p-3 text-center text-xs text-muted-foreground">
      {children}
    </div>
  );
}
