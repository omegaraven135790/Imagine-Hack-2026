import { useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { LogOut, LayoutDashboard, PanelLeftClose, PanelLeftOpen } from "lucide-react";
import { NAV_ITEMS } from "@/lib/nav";

export function AppSidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(true);

  return (
    <>
      {/* Floating open button when collapsed */}
      {!open && (
        <button
          type="button"
          onClick={() => setOpen(true)}
          aria-label="Open sidebar"
          className="fixed left-3 top-3 z-50 grid h-9 w-9 place-items-center rounded-md bg-surface-elevated text-foreground shadow-md hover:bg-surface"
        >
          <PanelLeftOpen className="h-5 w-5" />
        </button>
      )}

      <aside
        className={[
          "sticky top-0 z-40 flex h-screen shrink-0 flex-col bg-background px-4 py-6 transition-all duration-200",
          open ? "w-60" : "w-0 overflow-hidden px-0",
        ].join(" ")}
      >
        <div className="mb-8 flex items-center justify-between gap-2 px-2">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-md bg-accent-blue text-accent-blue-foreground">
              <LayoutDashboard className="h-5 w-5" />
            </div>
            <span className="text-lg font-semibold tracking-tight">ResWatch</span>
          </div>
          <button
            type="button"
            onClick={() => setOpen(false)}
            aria-label="Collapse sidebar"
            className="grid h-8 w-8 place-items-center rounded-md text-muted-foreground hover:bg-surface hover:text-foreground"
          >
            <PanelLeftClose className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex flex-1 flex-col gap-1 overflow-y-auto">
          {NAV_ITEMS.map((item) => {
            const active = pathname === item.to;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={[
                  "rounded-lg px-4 py-2.5 text-sm font-medium transition-colors",
                  active
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:bg-surface hover:text-foreground",
                ].join(" ")}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <button
          type="button"
          className="mt-6 flex items-center gap-3 rounded-lg px-3 py-2 text-base font-medium text-foreground transition-colors hover:bg-surface"
        >
          <span>Sign Out</span>
          <LogOut className="h-5 w-5" />
        </button>
      </aside>
    </>
  );
}
