import { useEffect, useRef, useState, type ReactNode } from "react";
import { ChevronDown } from "lucide-react";

/**
 * Hides the native scrollbar and shows a subtle floating chevron at the
 * bottom of the scroll container while more content is below the fold.
 * Click it to ease-scroll one viewport down.
 */
export function ScrollHint({ children, className = "" }: { children: ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [show, setShow] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const update = () => {
      const more = el.scrollTop + el.clientHeight < el.scrollHeight - 12;
      setShow(more);
    };
    update();
    el.addEventListener("scroll", update, { passive: true });
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => { el.removeEventListener("scroll", update); ro.disconnect(); };
  }, []);

  return (
    <div className={`relative flex-1 min-h-0 ${className}`}>
      <div ref={ref} className="h-full overflow-y-auto no-scrollbar">
        {children}
      </div>
      <button
        type="button"
        aria-label="Scroll down"
        onClick={() => ref.current?.scrollBy({ top: ref.current.clientHeight * 0.85, behavior: "smooth" })}
        className={[
          "pointer-events-auto absolute bottom-4 left-1/2 -translate-x-1/2 grid h-9 w-9 place-items-center",
          "rounded-full border border-border bg-surface-elevated/90 text-foreground backdrop-blur",
          "shadow-[0_10px_30px_-10px_color-mix(in_oklab,var(--accent-blue)_45%,transparent)]",
          "transition-all duration-300 hover:bg-accent-blue hover:text-accent-blue-foreground hover:scale-105",
          show ? "opacity-100" : "opacity-0 pointer-events-none translate-y-1",
        ].join(" ")}
      >
        <ChevronDown className="h-4 w-4 animate-bounce" />
      </button>
    </div>
  );
}
