import type { ReactNode } from "react";
import { TrendingDown, TrendingUp, Minus } from "lucide-react";

export function Delta({ pct, suffix = "%", invert = false }: { pct: number; suffix?: string; invert?: boolean }) {
  const abs = Math.abs(pct);
  if (abs < 0.1) return <span className="flex items-center gap-1 text-muted-foreground text-xs"><Minus className="h-3 w-3" />0{suffix}</span>;
  const isGood = invert ? pct > 0 : pct < 0;
  const cls = isGood ? "text-chart-2" : "text-destructive";
  const Icon = pct < 0 ? TrendingDown : TrendingUp;
  return <span className={`flex items-center gap-1 text-xs ${cls}`}><Icon className="h-3 w-3" />{pct < 0 ? "−" : "+"}{abs.toFixed(1)}{suffix}</span>;
}

export function KpiCard({
  icon, label, primary, secondary, delta, deltaSuffix = "%", invertDelta = false,
}: {
  icon: ReactNode; label: string; primary: string; secondary: string;
  delta?: number; deltaSuffix?: string; invertDelta?: boolean;
}) {
  return (
    <div className="rounded-xl border border-border bg-surface p-5 space-y-3 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">{icon}{label}</div>
        {delta !== undefined && <Delta pct={delta} suffix={deltaSuffix} invert={invertDelta} />}
      </div>
      <p className="text-2xl font-semibold tracking-tight">{primary}</p>
      <p className="text-xs text-muted-foreground">{secondary}</p>
    </div>
  );
}

export function PeriodSelector({ value, onChange, options = [7, 14, 30] }: { value: number; onChange: (n: number) => void; options?: number[] }) {
  return (
    <div className="flex items-center gap-1 rounded-lg border border-border bg-surface p-1">
      {options.map((d) => (
        <button key={d} onClick={() => onChange(d)} className={`rounded px-3 py-1 text-sm font-medium transition-colors ${value === d ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>{d}d</button>
      ))}
    </div>
  );
}
