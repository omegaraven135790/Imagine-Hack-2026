// Override-aware Supabase client wrapper.
// Reads the "Use my own Supabase project" override saved by the Settings page
// from localStorage. If a valid override is present, returns a client pointed
// at that project. Otherwise returns the default Lovable Cloud client.
//
// Auth/session code should keep using the default `supabase` from
// `@/integrations/supabase/client` — swapping auth backends mid-session would
// log everyone out. Use `activeSupabase` for data/query call sites only.
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { supabase as defaultClient } from "./client";
import type { Database } from "./types";

const SETTINGS_KEY = "reswatch.settings.v1";

type Override = { enabled: boolean; url: string; anonKey: string };

function readOverride(): Override | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    const o = parsed?.supabaseOverride;
    if (!o?.enabled) return null;
    const url = String(o.url ?? "").trim();
    const anonKey = String(o.anonKey ?? "").trim();
    if (!url || !anonKey) return null;
    if (!/^https:\/\/[^/]+/.test(url)) return null;
    return { enabled: true, url, anonKey };
  } catch {
    return null;
  }
}

let cached: { key: string; client: SupabaseClient<Database> } | null = null;

function getActive(): SupabaseClient<Database> {
  const o = readOverride();
  if (!o) return defaultClient as unknown as SupabaseClient<Database>;
  const key = `${o.url}|${o.anonKey}`;
  if (cached && cached.key === key) return cached.client;
  const client = createClient<Database>(o.url, o.anonKey, {
    auth: {
      storage: undefined,
      persistSession: false,
      autoRefreshToken: false,
    },
  });
  cached = { key, client };
  return client;
}

// Use like: import { activeSupabase } from "@/integrations/supabase/active-client";
export const activeSupabase = new Proxy({} as SupabaseClient<Database>, {
  get(_, prop, receiver) {
    return Reflect.get(getActive(), prop, receiver);
  },
});
