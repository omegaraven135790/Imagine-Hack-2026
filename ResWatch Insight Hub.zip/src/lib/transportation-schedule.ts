import { tx, type FleetVehicle, type TransportationRoute } from "@/lib/transportation-data";

export interface ScheduleSlot {
  id: string;
  date: string; // YYYY-MM-DD
  weekday: string;
  departHour: number; // 0-23
  route: TransportationRoute;
  vehicle?: FleetVehicle;
  recommendedLoadM3: number;
  capacityM3: number;
  fillPct: number;
  priority: "high" | "normal" | "low";
  reasoning: string[];
}

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export interface ScheduleOptions {
  includeWeekends?: boolean;
  /** jitter seed — change to produce a fresh recomputation */
  seed?: number;
}

export function buildWeeklySchedule(
  startDate: Date = new Date(),
  opts: ScheduleOptions = {},
): ScheduleSlot[] {
  const includeWeekends = opts.includeWeekends ?? true;
  const seed = opts.seed ?? 0;
  const routes = tx.routes();
  const vehicles = tx.vehicles();
  const shipments = tx.shipments();
  const NOW = startDate.getTime();
  const DAY = 86_400_000;

  const slots: ScheduleSlot[] = [];

  routes.forEach((route, rIdx) => {
    const routeShips = shipments.filter((s) => s.route_id === route.id);
    const last30 = routeShips.filter((s) => NOW - new Date(s.scheduled_departure).getTime() < 30 * DAY);
    const recent7 = routeShips.filter((s) => NOW - new Date(s.scheduled_departure).getTime() < 7 * DAY).length;
    const prior7 = routeShips.filter((s) => {
      const t = new Date(s.scheduled_departure).getTime();
      return t < NOW - 7 * DAY && t >= NOW - 14 * DAY;
    }).length;

    const baseline = last30.length / 30;
    const rawTrend = (recent7 - prior7) / Math.max(1, prior7);
    const trendMult = 1 + Math.max(-0.4, Math.min(0.4, rawTrend));
    const tripsPerDay = Math.max(0, Math.round(baseline * trendMult * 10) / 10);

    const avgVol = last30.length
      ? last30.reduce((a, s) => a + (s.cargo_volume_m3 ?? 0), 0) / last30.length
      : 6;
    const trendUp = rawTrend > 0.15;
    const trendDown = rawTrend < -0.15;

    const eligible = vehicles
      .filter((v) => v.status === "active" && (v.assigned_route_ids ?? []).includes(route.id))
      .sort((a, b) => (b.capacity_m3 ?? 0) - (a.capacity_m3 ?? 0));
    const pool = eligible.length
      ? eligible
      : vehicles.filter((v) => v.status === "active");

    // Generate slots for next 7 days
    for (let d = 0; d < 7; d++) {
      const date = new Date(NOW + d * DAY);
      const yyyy = date.toISOString().slice(0, 10);
      const weekday = WEEKDAYS[date.getUTCDay()];
      const isWeekend = weekday === "Sat" || weekday === "Sun";

      if (isWeekend && !includeWeekends) continue;

      // weekday demand multiplier: weekends 70% of weekday
      const dayMult = isWeekend ? 0.7 : 1.0;
      // small seed-based jitter (±1 trip) so "recalculate" produces fresh suggestions
      const jitter = seed ? (((seed * 9301 + d * 49297 + rIdx * 233) % 3) - 1) * 0.15 : 0;
      const tripsToday = Math.max(0, Math.round(tripsPerDay * dayMult + jitter));

      for (let n = 0; n < tripsToday; n++) {
        const vehicle = pool[(d + n + rIdx + seed) % Math.max(1, pool.length)];
        const capacity = vehicle?.capacity_m3 ?? 20;

        // Recommended load: bias up when trending up, down when consolidating
        let recommended = avgVol;
        const reasoning: string[] = [];
        reasoning.push(`Baseline ${(baseline).toFixed(2)} trips/day over last 30d (${last30.length} shipments).`);
        reasoning.push(`Demand trend ${rawTrend >= 0 ? "+" : ""}${Math.round(rawTrend * 100)}% (last 7d vs prior 7d) → multiplier ×${trendMult.toFixed(2)}.`);

        if (trendUp && avgVol / capacity > 0.8) {
          recommended = Math.min(capacity * 0.95, avgVol * 1.15);
          reasoning.push(`Trending up with fill at ${Math.round((avgVol / capacity) * 100)}% → scale shipment size to ${recommended.toFixed(1)} m³.`);
        } else if (trendDown || avgVol / capacity < 0.55) {
          recommended = Math.min(capacity * 0.85, avgVol * 1.3);
          reasoning.push(`Under-utilised (${Math.round((avgVol / capacity) * 100)}% fill) → consolidate into fewer, fuller runs of ${recommended.toFixed(1)} m³.`);
        } else {
          reasoning.push(`Steady demand at ${Math.round((avgVol / capacity) * 100)}% fill — keep current load profile.`);
        }

        // Depart hour: prefer 06, 10, 13, 21 (avoid congestion)
        const safeHours = isWeekend ? [8, 11, 14] : [6, 10, 13, 21];
        const departHour = safeHours[n % safeHours.length];
        reasoning.push(`Depart ${String(departHour).padStart(2, "0")}:00 — avoids 07–09 / 17–19 congestion windows.`);

        if (!eligible.length) {
          reasoning.push(`⚠ No vehicle allocated to this route — picked ${vehicle?.label ?? "n/a"} from general active pool. Allocate in Fleet Configuration.`);
        } else {
          reasoning.push(`Vehicle ${vehicle?.label} (${capacity} m³) chosen from ${eligible.length} allocated active vehicle(s).`);
        }

        const priority: ScheduleSlot["priority"] =
          trendUp && avgVol / capacity > 0.8 ? "high" : trendDown || avgVol / capacity < 0.5 ? "low" : "normal";

        slots.push({
          id: `${route.id}-${yyyy}-${n}`,
          date: yyyy,
          weekday,
          departHour,
          route,
          vehicle,
          recommendedLoadM3: Math.round(recommended * 10) / 10,
          capacityM3: capacity,
          fillPct: Math.round((recommended / capacity) * 100),
          priority,
          reasoning,
        });
      }
    }
  });

  return slots.sort((a, b) => (a.date + a.departHour).localeCompare(b.date + b.departHour));
}
