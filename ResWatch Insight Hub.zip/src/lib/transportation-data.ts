// Typed mock data shaped exactly like the Supabase `transportation_*` schema.
// SWAP POINT: replace the exports at the bottom with Supabase queries once
// Lovable Cloud is enabled. Component code never touches mock arrays directly.

export type FuelType = "petrol" | "diesel" | "hybrid" | "electric";
export type VehicleStatus = "active" | "maintenance" | "inactive";
export type ShipmentStatus =
  | "planned"
  | "in_transit"
  | "delivered"
  | "delayed"
  | "cancelled";

export interface TransportationLocation {
  id: string;
  name: string;
  location_type: string;
  address?: string;
}

export interface Fleet {
  id: string;
  name: string;
  description?: string;
  color: string; // tailwind-friendly hex for chips
}

export interface FleetVehicle {
  id: string;
  registration_no: string;
  label: string;
  make?: string;
  model?: string;
  vehicle_type: string;
  fuel_type: FuelType;
  capacity_kg?: number;
  capacity_m3?: number;
  odometer_km: number;
  status: VehicleStatus;
  assigned_driver?: string;
  fleet_id?: string;
  assigned_route_ids?: string[]; // routes this vehicle is allocated to
  created_at: string;
}

export interface TransportationRoute {
  id: string;
  name: string;
  origin_location_id: string;
  destination_location_id: string;
  planned_distance_km: number;
  estimated_duration_minutes: number;
}

export interface Shipment {
  id: string;
  shipment_ref: string;
  route_id: string;
  vehicle_id: string;
  origin_location_id: string;
  destination_location_id: string;
  status: ShipmentStatus;
  cargo_description?: string;
  cargo_weight_kg?: number;
  cargo_volume_m3?: number;
  scheduled_departure: string;
  scheduled_arrival: string;
  actual_departure?: string;
  actual_arrival?: string;
}

export interface ShipmentLocationEvent {
  id: string;
  shipment_id: string;
  event_type: string;
  notes?: string;
  ts: string;
}

export interface VehicleFuelLog {
  id: string;
  vehicle_id: string;
  shipment_id?: string;
  fuel_type: FuelType;
  volume_liters: number;
  cost_myr?: number;
  odometer_km?: number;
  ts: string;
}

export interface VehicleTelemetry {
  id: string;
  vehicle_id: string;
  shipment_id?: string;
  route_id?: string;
  speed_kmh: number;
  distance_km?: number;
  captured_at: string;
}

export interface VehicleMaintenanceEvent {
  id: string;
  vehicle_id: string;
  event_date: string;
  event_type: string;
  odometer_km?: number;
  cost_myr?: number;
  notes?: string;
}

// ---------- mock store (kept tiny + deterministic) ----------

const LOCATIONS: TransportationLocation[] = [
  { id: "loc-1", name: "KL DC", location_type: "warehouse", address: "Shah Alam" },
  { id: "loc-2", name: "Penang Store", location_type: "store", address: "Georgetown" },
  { id: "loc-3", name: "Ipoh Store", location_type: "store", address: "Ipoh" },
  { id: "loc-4", name: "JB Store", location_type: "store", address: "Johor Bahru" },
  { id: "loc-5", name: "Klang Port", location_type: "port", address: "Klang" },
];

let FLEETS: Fleet[] = [
  { id: "fl-1", name: "Northern Express", description: "Long-haul to Penang & Ipoh", color: "#1E60FF" },
  { id: "fl-2", name: "Southern Line", description: "JB corridor", color: "#a855f7" },
  { id: "fl-3", name: "Port Shuttle", description: "Klang ↔ KL drayage", color: "#10b981" },
];

let VEHICLES: FleetVehicle[] = [
  { id: "v1", registration_no: "WXY 1234", label: "Penguin", make: "BYD", model: "T3", vehicle_type: "van", fuel_type: "electric", capacity_kg: 1200, capacity_m3: 8, odometer_km: 18420, status: "active", assigned_driver: "Aisyah", fleet_id: "fl-3", assigned_route_ids: ["r4"], created_at: "2025-01-12" },
  { id: "v2", registration_no: "VBT 9981", label: "Rhino", make: "Hino", model: "500", vehicle_type: "truck", fuel_type: "diesel", capacity_kg: 8000, capacity_m3: 30, odometer_km: 96210, status: "active", assigned_driver: "Daniel", fleet_id: "fl-1", assigned_route_ids: ["r1", "r2"], created_at: "2023-06-04" },
  { id: "v3", registration_no: "JKR 4420", label: "Otter", make: "Isuzu", model: "ELF", vehicle_type: "truck", fuel_type: "hybrid", capacity_kg: 3500, capacity_m3: 14, odometer_km: 54200, status: "maintenance", assigned_driver: "Priya", fleet_id: "fl-1", assigned_route_ids: ["r2"], created_at: "2024-02-20" },
  { id: "v4", registration_no: "PNG 7711", label: "Falcon", make: "Toyota", model: "Hilux", vehicle_type: "pickup", fuel_type: "petrol", capacity_kg: 1000, capacity_m3: 5, odometer_km: 31980, status: "active", assigned_driver: "Hakim", fleet_id: "fl-2", assigned_route_ids: ["r3"], created_at: "2024-09-01" },
];

let ROUTES: TransportationRoute[] = [
  { id: "r1", name: "KL → Penang", origin_location_id: "loc-1", destination_location_id: "loc-2", planned_distance_km: 360, estimated_duration_minutes: 270 },
  { id: "r2", name: "KL → Ipoh", origin_location_id: "loc-1", destination_location_id: "loc-3", planned_distance_km: 200, estimated_duration_minutes: 160 },
  { id: "r3", name: "KL → JB", origin_location_id: "loc-1", destination_location_id: "loc-4", planned_distance_km: 330, estimated_duration_minutes: 240 },
  { id: "r4", name: "Klang Port → KL", origin_location_id: "loc-5", destination_location_id: "loc-1", planned_distance_km: 45, estimated_duration_minutes: 60 },
];

// Build deterministic shipments across last 60 days per route
const today = new Date("2026-06-20T08:00:00Z").getTime();
const DAY = 86_400_000;

function iso(t: number) {
  return new Date(t).toISOString();
}

const SHIPMENTS: Shipment[] = [];
const TELEMETRY: VehicleTelemetry[] = [];
const FUEL_LOGS: VehicleFuelLog[] = [];
const EVENTS: ShipmentLocationEvent[] = [];

ROUTES.forEach((route, rIdx) => {
  const baseDuration = route.estimated_duration_minutes;
  for (let i = 0; i < 24; i++) {
    const vehicle = VEHICLES[(rIdx + i) % VEHICLES.length];
    const departed = today - (i * 2 + rIdx) * DAY;
    const variancePct = Math.sin((i + rIdx) / 2) * 0.18 + (i % 5 === 0 ? 0.25 : 0);
    const actualDuration = Math.round(baseDuration * (1 + variancePct));
    const arrived = departed + actualDuration * 60_000;
    const status: ShipmentStatus =
      i === 0 ? "in_transit" : variancePct > 0.2 ? "delayed" : "delivered";
    const id = `s-${route.id}-${i}`;
    SHIPMENTS.push({
      id,
      shipment_ref: `SHP-${2000 + rIdx * 100 + i}`,
      route_id: route.id,
      vehicle_id: vehicle.id,
      origin_location_id: route.origin_location_id,
      destination_location_id: route.destination_location_id,
      status,
      cargo_description: ["Apparel", "FMCG", "Electronics", "Grocery"][i % 4],
      cargo_weight_kg: 400 + ((i * 137) % 2200),
      cargo_volume_m3: 2 + ((i * 7) % 18),
      scheduled_departure: iso(departed),
      scheduled_arrival: iso(departed + baseDuration * 60_000),
      actual_departure: iso(departed),
      actual_arrival: status === "delivered" || status === "delayed" ? iso(arrived) : undefined,
    });

    const points = 30;
    for (let p = 0; p < points; p++) {
      const t = departed + (actualDuration * 60_000 * p) / points;
      const baseSpeed = 78;
      const speed = Math.max(
        0,
        baseSpeed +
          Math.sin((p + i) / 2) * 18 +
          Math.cos((p * 3 + rIdx) / 4) * 12 +
          (p === 7 || p === 22 ? -45 : 0) +
          (p === 14 ? 18 : 0),
      );
      TELEMETRY.push({
        id: `t-${id}-${p}`,
        vehicle_id: vehicle.id,
        shipment_id: id,
        route_id: route.id,
        speed_kmh: Math.round(speed),
        distance_km: Math.round((route.planned_distance_km * p) / points),
        captured_at: iso(t),
      });
    }

    FUEL_LOGS.push({
      id: `f-${id}`,
      vehicle_id: vehicle.id,
      shipment_id: id,
      fuel_type: vehicle.fuel_type,
      volume_liters: Math.round((route.planned_distance_km / 3.4) * (1 + variancePct * 0.3)),
      cost_myr: Math.round((route.planned_distance_km / 3.4) * 2.05),
      odometer_km: vehicle.odometer_km - i * 80,
      ts: iso(departed),
    });

    EVENTS.push(
      { id: `e-${id}-1`, shipment_id: id, event_type: "departed", ts: iso(departed) },
      { id: `e-${id}-2`, shipment_id: id, event_type: "checkpoint", notes: "Highway toll", ts: iso(departed + actualDuration * 30_000) },
      ...(status === "delivered" || status === "delayed"
        ? [{ id: `e-${id}-3`, shipment_id: id, event_type: "delivered", ts: iso(arrived) } as ShipmentLocationEvent]
        : []),
    );
  }
});

const MAINTENANCE: VehicleMaintenanceEvent[] = [
  { id: "m1", vehicle_id: "v2", event_date: "2026-05-12", event_type: "Tyre rotation", odometer_km: 94800, cost_myr: 320 },
  { id: "m2", vehicle_id: "v3", event_date: "2026-06-15", event_type: "Brake pads + hybrid battery check", odometer_km: 53980, cost_myr: 1850, notes: "In workshop" },
  { id: "m3", vehicle_id: "v1", event_date: "2026-04-02", event_type: "Software OTA", odometer_km: 17200, cost_myr: 0 },
  { id: "m4", vehicle_id: "v4", event_date: "2026-03-20", event_type: "Oil + filter", odometer_km: 30100, cost_myr: 410 },
];

// ---------- API (swap implementations for Supabase later) ----------

export const tx = {
  locations: () => LOCATIONS.slice(),
  fleets: () => FLEETS.slice(),
  vehicles: () => VEHICLES.slice(),
  routes: () => ROUTES.slice(),
  shipments: () => SHIPMENTS.slice(),
  telemetry: () => TELEMETRY.slice(),
  fuelLogs: () => FUEL_LOGS.slice(),
  events: () => EVENTS.slice(),
  maintenance: () => MAINTENANCE.slice(),

  locationName: (id?: string) =>
    LOCATIONS.find((l) => l.id === id)?.name ?? "—",
  vehicle: (id?: string) => VEHICLES.find((v) => v.id === id),
  route: (id?: string) => ROUTES.find((r) => r.id === id),
  fleet: (id?: string) => FLEETS.find((f) => f.id === id),

  addVehicle: (
    input: Omit<FleetVehicle, "id" | "created_at" | "odometer_km" | "status"> &
      Partial<Pick<FleetVehicle, "odometer_km" | "status">>,
  ) => {
    const v: FleetVehicle = {
      id: `v-${Date.now()}`,
      created_at: new Date().toISOString(),
      odometer_km: input.odometer_km ?? 0,
      status: input.status ?? "active",
      assigned_route_ids: input.assigned_route_ids ?? [],
      ...input,
    };
    VEHICLES = [v, ...VEHICLES];
    return v;
  },

  removeVehicle: (id: string) => {
    VEHICLES = VEHICLES.filter((v) => v.id !== id);
  },

  updateVehicle: (id: string, patch: Partial<FleetVehicle>) => {
    VEHICLES = VEHICLES.map((v) => (v.id === id ? { ...v, ...patch } : v));
  },

  assignVehicleToFleet: (vehicleId: string, fleetId: string | undefined) => {
    VEHICLES = VEHICLES.map((v) => (v.id === vehicleId ? { ...v, fleet_id: fleetId } : v));
  },

  setVehicleRoutes: (vehicleId: string, routeIds: string[]) => {
    VEHICLES = VEHICLES.map((v) => (v.id === vehicleId ? { ...v, assigned_route_ids: routeIds } : v));
  },

  toggleVehicleRoute: (vehicleId: string, routeId: string) => {
    VEHICLES = VEHICLES.map((v) => {
      if (v.id !== vehicleId) return v;
      const cur = v.assigned_route_ids ?? [];
      return { ...v, assigned_route_ids: cur.includes(routeId) ? cur.filter((r) => r !== routeId) : [...cur, routeId] };
    });
  },

  addFleet: (input: Omit<Fleet, "id">) => {
    const f: Fleet = { id: `fl-${Date.now()}`, ...input };
    FLEETS = [...FLEETS, f];
    return f;
  },

  removeFleet: (id: string) => {
    FLEETS = FLEETS.filter((f) => f.id !== id);
    VEHICLES = VEHICLES.map((v) => (v.fleet_id === id ? { ...v, fleet_id: undefined } : v));
  },

  addRoute: (input: Omit<TransportationRoute, "id">) => {
    const r: TransportationRoute = { id: `r-${Date.now()}`, ...input };
    ROUTES = [...ROUTES, r];
    return r;
  },

  removeRoute: (id: string) => {
    ROUTES = ROUTES.filter((r) => r.id !== id);
    VEHICLES = VEHICLES.map((v) => ({
      ...v,
      assigned_route_ids: (v.assigned_route_ids ?? []).filter((rid) => rid !== id),
    }));
  },
};
