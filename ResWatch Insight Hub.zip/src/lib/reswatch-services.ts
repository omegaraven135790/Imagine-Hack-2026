/**
 * Ported algorithmic services from ResWatch backend (Python → TS).
 *
 *   - forecasting:        seasonal-naive + linear-trend with confidence band
 *   - anomaly_detection:  z-score + IQR
 *   - waste_engine:       energy_idle, water_leak, stock_spoilage, overstock
 *   - scheduler:          greedy demand-driven roster (CP-SAT path omitted)
 *   - tariff_service:     constant fallback (TNB / Air Selangor)
 *
 * The Python service used Holt-Winters from statsmodels; we keep the same
 * model-selection ladder (seasonal-naive when ≥7 points, else linear) so
 * the UI/UX matches without depending on a Python runtime.
 */

import {
  MeterReading, footfallReadings, meterReadings, salesRecords, inventoryItems,
  stockMovements, daysAgo, isoDay, mean, pct, round, sum, STAFF, ZONES, ZONE_LABEL,
  STORE, TARIFF, Resource, Zone,
} from "./reswatch-data";

// ─── forecasting ────────────────────────────────────────────────────────────
export interface ForecastPoint { ts: string; predicted: number; lower: number; upper: number }
export interface ForecastResult { model: "seasonal_naive" | "linear"; points: ForecastPoint[] }

export function forecast(series: Array<{ ts: Date; value: number }>, horizonDays = 7): ForecastResult {
  if (series.length === 0) return { model: "linear", points: [] };
  const values = series.map((s) => s.value);
  const lastTs = series[series.length - 1].ts;
  const horizon = Array.from({ length: horizonDays }, (_, i) => {
    const d = new Date(lastTs); d.setDate(d.getDate() + i + 1); return d;
  });

  if (values.length >= 7) return seasonalNaive(values, horizon);
  return linearTrend(values, horizon);
}

function seasonalNaive(values: number[], horizon: Date[]): ForecastResult {
  const period = 7;
  const points = horizon.map((ts, i) => {
    const lookBack = period - (i % period);
    const base = Math.max(values[values.length - lookBack] ?? 0, 0);
    const band = base * 0.15;
    return { ts: ts.toISOString(), predicted: round(base, 3), lower: round(Math.max(base - band, 0), 3), upper: round(base + band, 3) };
  });
  return { model: "seasonal_naive", points };
}

function linearTrend(values: number[], horizon: Date[]): ForecastResult {
  const n = values.length;
  const xs = Array.from({ length: n }, (_, i) => i);
  const xm = mean(xs), ym = mean(values);
  const num = xs.reduce((a, x, i) => a + (x - xm) * (values[i] - ym), 0);
  const den = xs.reduce((a, x) => a + (x - xm) ** 2, 0) || 1;
  const slope = num / den;
  const intercept = ym - slope * xm;
  const points = horizon.map((ts, i) => {
    const p = Math.max(intercept + slope * (n + i), 0);
    const band = p * 0.2;
    return { ts: ts.toISOString(), predicted: round(p, 3), lower: round(Math.max(p - band, 0), 3), upper: round(p + band, 3) };
  });
  return { model: "linear", points };
}

// ─── anomaly detection ──────────────────────────────────────────────────────
export type Severity = "LOW" | "MEDIUM" | "HIGH";
export interface AnomalyEvent {
  ts: string;
  metric: "electricity" | "water" | "footfall" | "sales";
  zone: Zone | null;
  value: number;
  z: number;
  severity: Severity;
  description: string;
}

const Z_HIGH = 3.5, Z_MED = 2.5, Z_LOW = 2.0;

function severity(az: number): Severity {
  if (az >= Z_HIGH) return "HIGH";
  if (az >= Z_MED) return "MEDIUM";
  return "LOW";
}

function iqrOutlier(values: number[], v: number): boolean {
  if (values.length < 4) return false;
  const sorted = [...values].sort((a, b) => a - b);
  const q = (p: number) => sorted[Math.min(sorted.length - 1, Math.floor(p * sorted.length))];
  const q1 = q(0.25), q3 = q(0.75); const iqr = q3 - q1;
  if (iqr === 0) return false;
  return v < q1 - 1.5 * iqr || v > q3 + 1.5 * iqr;
}

/** Scans the last 30 days of daily aggregates for each metric and returns triggered anomalies. */
export function detectAnomalies(limit = 25): AnomalyEvent[] {
  const out: AnomalyEvent[] = [];
  const dailyByMetric = buildDailySeriesByMetric();
  for (const [metric, byZone] of Object.entries(dailyByMetric)) {
    for (const [zoneKey, daily] of Object.entries(byZone)) {
      const zone = zoneKey === "_all" ? null : (zoneKey as Zone);
      // walk last 30 readings, baseline = previous 7
      for (let i = 14; i < daily.length; i++) {
        const window = daily.slice(Math.max(0, i - 7), i).map((d) => d.value);
        const m = mean(window);
        const sd = Math.sqrt(mean(window.map((v) => (v - m) ** 2))) || 1e-9;
        const v = daily[i].value;
        const z = (v - m) / sd; const az = Math.abs(z);
        const iqrWindow = daily.slice(Math.max(0, i - 30), i).map((d) => d.value);
        const iqrHit = iqrOutlier(iqrWindow, v);
        if (!(az >= Z_HIGH || (az >= Z_LOW && iqrHit))) continue;
        const sev = severity(az);
        const dir = z > 0 ? "above" : "below";
        const unit = metric === "electricity" ? "kWh" : metric === "water" ? "m³" : metric === "footfall" ? "visitors" : "RM";
        const label = metric.charAt(0).toUpperCase() + metric.slice(1);
        const zoneStr = zone ? ` (${ZONE_LABEL[zone]})` : "";
        out.push({
          ts: daily[i].day,
          metric: metric as AnomalyEvent["metric"],
          zone,
          value: round(v, 2),
          z: round(z, 2),
          severity: sev,
          description: `${label}${zoneStr} recorded ${v.toLocaleString(undefined, { maximumFractionDigits: 2 })} ${unit} — ${az.toFixed(1)}σ ${dir} the 7-day mean. ${sev === "HIGH" ? "Investigate immediately." : "Monitor closely."}`,
        });
      }
    }
  }
  return out.sort((a, b) => b.ts.localeCompare(a.ts) || Math.abs(b.z) - Math.abs(a.z)).slice(0, limit);
}

function buildDailySeriesByMetric() {
  const out: Record<string, Record<string, Array<{ day: string; value: number }>>> = {
    electricity: {}, water: {}, footfall: { _all: [] }, sales: { _all: [] },
  };
  // meter
  const buckets: Record<string, Record<string, Record<string, number>>> = { electricity: {}, water: {} };
  for (const r of meterReadings()) {
    const day = isoDay(r.ts);
    const bResource = buckets[r.resource];
    if (!bResource[r.zone]) bResource[r.zone] = {};
    bResource[r.zone][day] = (bResource[r.zone][day] ?? 0) + r.value;
  }
  for (const resource of ["electricity", "water"] as const) {
    for (const zone of ZONES) {
      const byDay = buckets[resource][zone] || {};
      out[resource][zone] = Object.keys(byDay).sort().map((day) => ({ day, value: byDay[day] }));
    }
  }
  const dailyAgg = (rows: Array<{ ts: Date; v: number }>) => {
    const m: Record<string, number> = {};
    for (const r of rows) { const d = isoDay(r.ts); m[d] = (m[d] ?? 0) + r.v; }
    return Object.keys(m).sort().map((day) => ({ day, value: m[day] }));
  };
  out.footfall._all = dailyAgg(footfallReadings().map((f) => ({ ts: f.ts, v: f.count })));
  out.sales._all = dailyAgg(salesRecords().map((s) => ({ ts: s.ts, v: s.revenue_myr })));
  return out;
}

// ─── tariff ─────────────────────────────────────────────────────────────────
export function elecRate() { return TARIFF.elec_myr_per_kwh; }
export function waterRate() { return TARIFF.water_myr_per_m3; }
export function co2eFactor() { return TARIFF.co2e_kg_per_kwh; }

// ─── waste engine ───────────────────────────────────────────────────────────
export type WasteCategory = "energy_idle" | "water_leak" | "stock_spoilage" | "overstock";
export interface WasteStory {
  category: WasteCategory;
  zone: string | null;
  start_time: string;
  end_time: string;
  duration_hours: number;
  quantity: number;
  cost_myr: number;
  co2e_kg: number | null;
  description: string;
  action: string;
}

export function wasteStories(): WasteStory[] {
  const out: WasteStory[] = [];
  const since = daysAgo(7); const now = new Date();

  // energy_idle: closed-hour kWh by zone (last 7d)
  const byZoneElec: Record<string, number> = {};
  for (const r of meterReadings()) {
    if (r.resource !== "electricity" || r.ts < since) continue;
    const h = r.ts.getHours();
    const closed = h < STORE.open_hour || h >= STORE.close_hour;
    if (!closed) continue;
    byZoneElec[r.zone] = (byZoneElec[r.zone] ?? 0) + r.value;
  }
  for (const [zone, kwh] of Object.entries(byZoneElec).sort((a, b) => b[1] - a[1])) {
    if (kwh < 0.5) continue;
    const cost = round(kwh * elecRate(), 2);
    const co2e = round(kwh * co2eFactor(), 2);
    out.push({
      category: "energy_idle", zone, start_time: since.toISOString(), end_time: now.toISOString(),
      duration_hours: 12 * 7, quantity: round(kwh, 2), cost_myr: cost, co2e_kg: co2e,
      description: `${ZONE_LABEL[zone as Zone] ?? zone}: ${round(kwh, 1)} kWh consumed during closed hours over the past 7 days — RM ${cost.toFixed(2)} wasted, ${co2e.toFixed(1)} kg CO₂e.`,
      action: `Audit ${ZONE_LABEL[zone as Zone] ?? zone} after-hours load. Install timers / motion sensors and ensure displays, signage and HVAC switch off at ${STORE.close_hour}:00.`,
    });
  }

  // water_leak: off-hours m³
  const byZoneWater: Record<string, number> = {};
  for (const r of meterReadings()) {
    if (r.resource !== "water" || r.ts < since) continue;
    const h = r.ts.getHours();
    const closed = h < STORE.open_hour || h >= STORE.close_hour;
    if (!closed) continue;
    byZoneWater[r.zone] = (byZoneWater[r.zone] ?? 0) + r.value;
  }
  for (const [zone, m3] of Object.entries(byZoneWater).sort((a, b) => b[1] - a[1])) {
    if (m3 < 0.2) continue;
    const cost = round(m3 * waterRate(), 2);
    out.push({
      category: "water_leak", zone, start_time: since.toISOString(), end_time: now.toISOString(),
      duration_hours: 12 * 7, quantity: round(m3, 2), cost_myr: cost, co2e_kg: null,
      description: `${ZONE_LABEL[zone as Zone] ?? zone}: ${round(m3, 2)} m³ flowed during closed hours — suspected leak or running fixture. RM ${cost.toFixed(2)} lost in 7 days.`,
      action: `Inspect ${ZONE_LABEL[zone as Zone] ?? zone} plumbing tonight after close. Check tap washers, urinal flush sensors and any cold-line valves.`,
    });
  }

  // stock_spoilage: last 30 days
  const spoilageByItem: Record<string, { qty: number; cost: number }> = {};
  const items = Object.fromEntries(inventoryItems().map((i) => [i.id, i]));
  const since30 = daysAgo(30);
  for (const m of stockMovements()) {
    if (m.ts < since30) continue;
    if (m.type !== "spoiled" && m.type !== "discarded") continue;
    const it = items[m.item_id]; if (!it) continue;
    if (!spoilageByItem[m.item_id]) spoilageByItem[m.item_id] = { qty: 0, cost: 0 };
    spoilageByItem[m.item_id].qty += m.qty;
    spoilageByItem[m.item_id].cost += Math.abs(m.cost_impact_myr);
  }
  for (const [id, agg] of Object.entries(spoilageByItem).sort((a, b) => b[1].cost - a[1].cost).slice(0, 5)) {
    const it = items[id];
    out.push({
      category: "stock_spoilage", zone: it.storage_zone, start_time: since30.toISOString(), end_time: now.toISOString(),
      duration_hours: 30 * 24, quantity: agg.qty, cost_myr: round(agg.cost, 2), co2e_kg: null,
      description: `${it.name} (${it.category}): ${agg.qty} units spoiled or discarded in 30 days — RM ${agg.cost.toFixed(2)} lost.`,
      action: `Switch ${it.name} to smaller, more frequent deliveries aligned to daily demand, or shorten supplier lead time. Adjust reorder point if turnover is slow.`,
    });
  }

  // overstock: non-perishable carrying many days of cover
  const recentSold: Record<string, number> = {};
  for (const m of stockMovements()) {
    if (m.ts < since30 || m.type !== "sold") continue;
    recentSold[m.item_id] = (recentSold[m.item_id] ?? 0) + m.qty;
  }
  for (const it of inventoryItems()) {
    if (it.perishable) continue;
    const sold = recentSold[it.id] ?? 0;
    const daily = sold / 30;
    if (daily <= 0) continue;
    const daysCover = it.current_stock / daily;
    if (daysCover < 60) continue;
    const tied = round(it.current_stock * it.unit_cost_myr, 2);
    out.push({
      category: "overstock", zone: it.storage_zone, start_time: since30.toISOString(), end_time: now.toISOString(),
      duration_hours: 30 * 24, quantity: it.current_stock, cost_myr: tied, co2e_kg: null,
      description: `${it.name}: ${it.current_stock} units in stock vs ${daily.toFixed(1)}/day demand → ${Math.round(daysCover)} days of cover. RM ${tied.toFixed(2)} of working capital tied up.`,
      action: `Pause ordering for ${it.name} until cover drops below 30 days, or negotiate consignment / return-unsold terms with the supplier.`,
    });
  }

  return out.sort((a, b) => b.cost_myr - a.cost_myr);
}

// ─── scheduler (greedy demand-driven roster) ────────────────────────────────
export interface ScheduleAssignment {
  staff_id: string; staff_name: string; role: string;
  date: string; day_index: number; shift: "morning" | "afternoon" | "evening";
  hours: number; cost_myr: number;
}
export type ScheduleMethod = "greedy" | "balanced" | "cost_min" | "seniority" | "random";

export const SCHEDULE_METHODS: { id: ScheduleMethod; label: string; description: string }[] = [
  { id: "greedy",    label: "Greedy demand-driven", description: "Fills each shift with the least-loaded staff first. Fast, predictable." },
  { id: "balanced",  label: "Fair rotation",        description: "Balances total hours across the roster — minimizes max/min hour gap." },
  { id: "cost_min",  label: "Cost-minimising",      description: "Prefers lowest hourly rate first, subject to coverage & off-days." },
  { id: "seniority", label: "Seniority-weighted",   description: "Supervisors first on peak shifts; associates first on off-peak to save cost." },
  { id: "random",    label: "Randomised (seeded)",  description: "Shuffles assignment order — useful for exploring alternative rosters." },
];

export interface ScheduleResult {
  method: ScheduleMethod;
  week_start: string;
  assignments: ScheduleAssignment[];
  total_cost_myr: number;
  demand: Record<string, { footfall: number; required: { morning: number; afternoon: number; evening: number } }>;
}

const SHIFT_FRACTIONS = { morning: 0.30, afternoon: 0.45, evening: 0.25 } as const;
const SHIFT_HOURS = { morning: 5, afternoon: 5, evening: 4 } as const;
const SHIFTS: Array<keyof typeof SHIFT_HOURS> = ["morning", "afternoon", "evening"];
const VISITORS_PER_STAFF = 120;
const ROLE_WEIGHT: Record<string, number> = { supervisor: 0, cashier: 1, associate: 2 };

function mulberry32(seed: number) {
  let t = (seed >>> 0) || 1;
  return () => { t = (t + 0x6D2B79F5) >>> 0; let x = Math.imul(t ^ (t >>> 15), 1 | t); x = (x + Math.imul(x ^ (x >>> 7), 61 | x)) ^ x; return ((x ^ (x >>> 14)) >>> 0) / 4294967296; };
}

export interface ScheduleOptions { method?: ScheduleMethod; seed?: number }

export function generateSchedule(
  weekStart: Date = nextMonday(),
  horizonDays = 7,
  opts: ScheduleOptions = {},
): ScheduleResult {
  const method = opts.method ?? "greedy";
  const rand = mulberry32(opts.seed ?? 1);

  const days: Date[] = Array.from({ length: horizonDays }, (_, i) => {
    const d = new Date(weekStart); d.setDate(d.getDate() + i); return d;
  });

  const footByDay: Record<string, number> = {};
  for (const f of footfallReadings()) { const d = isoDay(f.ts); footByDay[d] = (footByDay[d] ?? 0) + f.count; }
  const sortedDays = Object.keys(footByDay).sort();
  const series = sortedDays.map((d) => ({ ts: new Date(d), value: footByDay[d] }));
  const fc = forecast(series, horizonDays);

  const demand: ScheduleResult["demand"] = {};
  const required: Record<number, Record<keyof typeof SHIFT_HOURS, number>> = {};
  days.forEach((d, i) => {
    const predicted = fc.points[i]?.predicted ?? footByDay[isoDay(d)] ?? 200;
    const req = {
      morning: Math.max(1, Math.ceil(predicted * SHIFT_FRACTIONS.morning / VISITORS_PER_STAFF)),
      afternoon: Math.max(1, Math.ceil(predicted * SHIFT_FRACTIONS.afternoon / VISITORS_PER_STAFF)),
      evening: Math.max(1, Math.ceil(predicted * SHIFT_FRACTIONS.evening / VISITORS_PER_STAFF)),
    };
    required[i] = req;
    demand[isoDay(d)] = { footfall: Math.round(predicted), required: req };
  });

  const hoursWorked: Record<string, number> = Object.fromEntries(STAFF.map((s) => [s.id, 0]));
  const assignments: ScheduleAssignment[] = [];
  let total = 0;

  for (let i = 0; i < days.length; i++) {
    const d = days[i];
    const dowMon0 = (d.getDay() + 6) % 7;
    for (const shift of SHIFTS) {
      const need = required[i][shift];
      let pool = STAFF
        .filter((s) => !s.off_days.includes(dowMon0))
        .filter((s) => hoursWorked[s.id] + SHIFT_HOURS[shift] <= s.max_hours_week);

      const jitter = () => (rand() - 0.5) * 0.001;
      switch (method) {
        case "greedy":
          pool = pool.sort((a, b) => (hoursWorked[a.id] - hoursWorked[b.id]) + jitter());
          break;
        case "balanced":
          pool = pool.sort((a, b) => (hoursWorked[a.id] - hoursWorked[b.id]) || (a.hourly_rate_myr - b.hourly_rate_myr) + jitter());
          break;
        case "cost_min":
          pool = pool.sort((a, b) => (a.hourly_rate_myr - b.hourly_rate_myr) || (hoursWorked[a.id] - hoursWorked[b.id]) + jitter());
          break;
        case "seniority": {
          const peak = shift === "afternoon";
          pool = pool.sort((a, b) => {
            const wa = ROLE_WEIGHT[a.role] ?? 2, wb = ROLE_WEIGHT[b.role] ?? 2;
            const rolePref = peak ? wa - wb : wb - wa;
            return rolePref || (hoursWorked[a.id] - hoursWorked[b.id]) + jitter();
          });
          break;
        }
        case "random":
          pool = pool.map((s) => ({ s, k: rand() })).sort((a, b) => a.k - b.k).map((x) => x.s);
          break;
      }

      const chosen = pool.slice(0, need);
      for (const s of chosen) {
        const h = SHIFT_HOURS[shift];
        const cost = round(h * s.hourly_rate_myr, 2);
        hoursWorked[s.id] += h;
        total += cost;
        assignments.push({ staff_id: s.id, staff_name: s.name, role: s.role, date: isoDay(d), day_index: i, shift, hours: h, cost_myr: cost });
      }
    }
  }

  return { method, week_start: isoDay(weekStart), assignments, total_cost_myr: round(total, 2), demand };
}

function nextMonday(): Date {
  const d = new Date(); const day = d.getDay(); const add = ((8 - day) % 7) || 7;
  d.setDate(d.getDate() + add); d.setHours(0, 0, 0, 0); return d;
}

// ─── summaries used by KPI cards ────────────────────────────────────────────

export function energySummary(days: number) {
  const since = daysAgo(days); const prior = daysAgo(days * 2);
  const periodElec = sumMeter("electricity", since, new Date());
  const priorElec = sumMeter("electricity", prior, since);
  const periodWater = sumMeter("water", since, new Date());
  const priorWater = sumMeter("water", prior, since);
  return {
    electricity: {
      kwh: round(periodElec, 1), cost_myr: round(periodElec * elecRate(), 2),
      co2e_kg: round(periodElec * co2eFactor(), 1), delta_pct: round(pct(periodElec, priorElec), 1),
    },
    water: {
      m3: round(periodWater, 2), cost_myr: round(periodWater * waterRate(), 2),
      delta_pct: round(pct(periodWater, priorWater), 1),
    },
  };
}
function sumMeter(res: Resource, from: Date, to: Date): number {
  let s = 0; for (const r of meterReadings()) if (r.resource === res && r.ts >= from && r.ts < to) s += r.value; return s;
}

export function dailyEnergyTrend(resource: Resource, days: number): Array<{ date: string; value: number }> {
  const since = daysAgo(days); const m: Record<string, number> = {};
  for (const r of meterReadings()) {
    if (r.resource !== resource || r.ts < since) continue;
    const d = isoDay(r.ts); m[d] = (m[d] ?? 0) + r.value;
  }
  return Object.keys(m).sort().map((d) => ({ date: d, value: round(m[d], 2) }));
}

export function energyByZone(resource: Resource, days: number): Array<{ zone: string; value: number; label: string }> {
  const since = daysAgo(days); const m: Record<string, number> = {};
  for (const r of meterReadings()) {
    if (r.resource !== resource || r.ts < since) continue;
    m[r.zone] = (m[r.zone] ?? 0) + r.value;
  }
  return Object.entries(m).map(([zone, value]) => ({ zone, value: round(value, 2), label: ZONE_LABEL[zone as Zone] ?? zone })).sort((a, b) => b.value - a.value);
}

export function footfallSummary(days: number) {
  const since = daysAgo(days); const prior = daysAgo(days * 2);
  const period = footfallReadings().filter((f) => f.ts >= since);
  const priorRows = footfallReadings().filter((f) => f.ts >= prior && f.ts < since);
  const periodTotal = sum(period.map((p) => p.count));
  const priorTotal = sum(priorRows.map((p) => p.count));
  const salesPeriod = salesRecords().filter((s) => s.ts >= since);
  const salesPrior = salesRecords().filter((s) => s.ts >= prior && s.ts < since);
  const rev = sum(salesPeriod.map((s) => s.revenue_myr));
  const priorRev = sum(salesPrior.map((s) => s.revenue_myr));
  const txns = sum(salesPeriod.map((s) => s.items));
  const convCurr = periodTotal ? (txns / periodTotal) * 100 : 0;
  const priorTxns = sum(salesPrior.map((s) => s.items));
  const convPrior = priorTotal ? (priorTxns / priorTotal) * 100 : 0;
  return {
    footfall: { total: periodTotal, avg_daily: Math.round(periodTotal / days), delta_pct: round(pct(periodTotal, priorTotal), 1) },
    sales: {
      revenue_myr: round(rev, 2), transactions: txns,
      avg_transaction_myr: txns ? round(rev / txns, 2) : 0,
      delta_pct: round(pct(rev, priorRev), 1),
    },
    conversion: { rate_pct: round(convCurr, 1), delta_pp: round(convCurr - convPrior, 1) },
  };
}

export function dailyFootfallTrend(days: number): Array<{ date: string; footfall: number; revenue: number }> {
  const since = daysAgo(days);
  const f: Record<string, number> = {}; const r: Record<string, number> = {};
  for (const x of footfallReadings()) if (x.ts >= since) { const d = isoDay(x.ts); f[d] = (f[d] ?? 0) + x.count; }
  for (const x of salesRecords()) if (x.ts >= since) { const d = isoDay(x.ts); r[d] = (r[d] ?? 0) + x.revenue_myr; }
  const keys = Array.from(new Set([...Object.keys(f), ...Object.keys(r)])).sort();
  return keys.map((d) => ({ date: d, footfall: f[d] ?? 0, revenue: round(r[d] ?? 0, 2) }));
}

export function hourlyHeatmap(): Array<{ dow: number; hour: number; avg: number }> {
  // last 28 days, avg footfall per (dow, hour)
  const since = daysAgo(28);
  const acc: Record<string, { sum: number; n: number }> = {};
  for (const x of footfallReadings()) {
    if (x.ts < since) continue;
    const key = `${x.ts.getDay()}-${x.ts.getHours()}`;
    if (!acc[key]) acc[key] = { sum: 0, n: 0 };
    acc[key].sum += x.count; acc[key].n += 1;
  }
  return Object.entries(acc).map(([k, v]) => {
    const [dow, hour] = k.split("-").map(Number);
    return { dow, hour, avg: round(v.sum / Math.max(1, v.n), 1) };
  });
}

// daily aggregate for forecasting any metric
export function dailyAggregate(metric: "electricity" | "water" | "footfall" | "sales"): Array<{ ts: Date; value: number }> {
  const m: Record<string, number> = {};
  if (metric === "electricity" || metric === "water") {
    for (const r of meterReadings()) { if (r.resource !== metric) continue; const d = isoDay(r.ts); m[d] = (m[d] ?? 0) + r.value; }
  } else if (metric === "footfall") {
    for (const r of footfallReadings()) { const d = isoDay(r.ts); m[d] = (m[d] ?? 0) + r.count; }
  } else {
    for (const r of salesRecords()) { const d = isoDay(r.ts); m[d] = (m[d] ?? 0) + r.revenue_myr; }
  }
  return Object.keys(m).sort().map((d) => ({ ts: new Date(d), value: round(m[d], 2) }));
}

// ─── inventory enrichment ──────────────────────────────────────────────────
export type InventoryStatus = "ok" | "low_stock" | "at_risk" | "out_of_stock" | "overstock";

export interface EnrichedInventoryItem {
  id: string; name: string; category: string;
  unit_cost_myr: number; perishable: boolean;
  reorder_point: number; reorder_qty: number | null;
  current_stock: number; storage_zone: "cold" | "ambient" | "dry";
  daily_sold: number; days_of_cover: number | null;
  status: InventoryStatus; spoilage_cost_30d: number;
}

export function inventoryEnriched(): EnrichedInventoryItem[] {
  const items = inventoryItems();
  const since = daysAgo(30);
  const sold: Record<string, number> = {};
  const spoilCost: Record<string, number> = {};
  for (const m of stockMovements()) {
    if (m.ts < since) continue;
    if (m.type === "sold") sold[m.item_id] = (sold[m.item_id] ?? 0) + m.qty;
    if (m.type === "spoiled" || m.type === "discarded") spoilCost[m.item_id] = (spoilCost[m.item_id] ?? 0) + Math.abs(m.cost_impact_myr);
  }
  return items.map((it) => {
    const s = sold[it.id] ?? 0;
    const daily = s / 30;
    const cover = daily > 0 ? Math.round(it.current_stock / daily) : null;
    let status: InventoryStatus = "ok";
    if (it.current_stock <= 0) status = "out_of_stock";
    else if (it.current_stock <= it.reorder_point) status = "low_stock";
    else if (it.perishable && cover != null && it.shelf_life_days != null && cover > it.shelf_life_days) status = "at_risk";
    else if (!it.perishable && cover != null && cover > 90) status = "overstock";
    const reorder_qty = status === "low_stock" || status === "out_of_stock" ? Math.max(it.reorder_point * 2 - it.current_stock, it.reorder_point) : null;
    return {
      id: it.id, name: it.name, category: it.category, unit_cost_myr: it.unit_cost_myr,
      perishable: it.perishable, reorder_point: it.reorder_point, reorder_qty,
      current_stock: it.current_stock, storage_zone: it.storage_zone,
      daily_sold: round(daily, 2), days_of_cover: cover,
      status, spoilage_cost_30d: round(spoilCost[it.id] ?? 0, 2),
    };
  });
}

export function inventorySummary() {
  const rows = inventoryEnriched();
  return {
    total_items: rows.length,
    at_risk: rows.filter((r) => r.status === "at_risk").length,
    low_stock: rows.filter((r) => r.status === "low_stock" || r.status === "out_of_stock").length,
    overstock: rows.filter((r) => r.status === "overstock").length,
    spoilage_cost_myr: round(rows.reduce((a, r) => a + r.spoilage_cost_30d, 0), 2),
  };
}

export function topSpoilers(limit = 7): { items: Array<{ id: string; name: string; category: string; spoiled_qty: number; spoilage_cost_myr: number }>; total_spoilage_myr: number } {
  const since = daysAgo(30);
  const items = Object.fromEntries(inventoryItems().map((i) => [i.id, i]));
  const agg: Record<string, { qty: number; cost: number }> = {};
  for (const m of stockMovements()) {
    if (m.ts < since) continue;
    if (m.type !== "spoiled" && m.type !== "discarded") continue;
    if (!agg[m.item_id]) agg[m.item_id] = { qty: 0, cost: 0 };
    agg[m.item_id].qty += m.qty;
    agg[m.item_id].cost += Math.abs(m.cost_impact_myr);
  }
  const all = Object.entries(agg).map(([id, v]) => ({
    id, name: items[id].name, category: items[id].category,
    spoiled_qty: v.qty, spoilage_cost_myr: round(v.cost, 2),
  })).sort((a, b) => b.spoilage_cost_myr - a.spoilage_cost_myr);
  return { items: all.slice(0, limit), total_spoilage_myr: round(all.reduce((a, x) => a + x.spoilage_cost_myr, 0), 2) };
}

// ─── peak hours ────────────────────────────────────────────────────────────
export function peakHours(topN = 5): Array<{ dow: number; hour: number; avg_count: number; label: string }> {
  const DOW = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  return hourlyHeatmap()
    .map((c) => ({
      dow: c.dow, hour: c.hour, avg_count: c.avg,
      label: `${DOW[c.dow]} ${c.hour === 12 ? "12pm" : c.hour < 12 ? `${c.hour}am` : `${c.hour - 12}pm`}`,
    }))
    .sort((a, b) => b.avg_count - a.avg_count).slice(0, topN);
}

// ─── waste summary with CO2 ────────────────────────────────────────────────
export function wasteSummary() {
  const stories = wasteStories();
  let total = 0, co2 = 0;
  const categories: Record<string, { cost_myr: number; co2e_kg: number; count: number }> = {};
  for (const s of stories) {
    total += s.cost_myr; co2 += s.co2e_kg ?? 0;
    if (!categories[s.category]) categories[s.category] = { cost_myr: 0, co2e_kg: 0, count: 0 };
    categories[s.category].cost_myr += s.cost_myr;
    categories[s.category].co2e_kg += s.co2e_kg ?? 0;
    categories[s.category].count += 1;
  }
  return { total_cost_myr: round(total, 2), total_co2e_kg: round(co2, 1), categories };
}
