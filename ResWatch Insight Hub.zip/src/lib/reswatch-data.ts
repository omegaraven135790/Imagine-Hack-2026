/**
 * ResWatch synthetic data layer.
 *
 * Mirrors the Postgres schema and seed.py from the original ResWatch backend
 * (Imagine-Hack-2026). Generates deterministic 90-day datasets so the ported
 * services (forecasting, anomaly detection, waste, scheduling) have something
 * realistic to chew on without needing a live database.
 */

export const TARIFF = {
  elec_myr_per_kwh: 0.5443, // TNB peninsular blended
  water_myr_per_m3: 3.51,   // Air Selangor
  co2e_kg_per_kwh: 0.574,
};

export type Resource = "electricity" | "water";
export type Zone = "shop_floor" | "storage_room" | "office" | "kitchen" | "restroom";

export const ZONES: Zone[] = ["shop_floor", "storage_room", "office", "kitchen", "restroom"];
export const ZONE_LABEL: Record<Zone, string> = {
  shop_floor: "Shop Floor",
  storage_room: "Storage Room",
  office: "Office",
  kitchen: "Kitchen",
  restroom: "Restroom",
};

export const STORE = {
  id: "store-1",
  name: "The Grand Bazaar",
  location: "Lot G-12, Taylor's Lakeside City Mall, Subang Jaya",
  org: "Grand Bazaar Holdings Sdn Bhd",
  floor_area_sqm: 320,
  max_occupancy: 80,
  open_hour: 10,
  close_hour: 22,
};

// ── deterministic PRNG (mulberry32) ──────────────────────────────────────────
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rng = mulberry32(42);
function gauss(mean = 0, sd = 1) {
  // Box-Muller
  const u = Math.max(1e-9, rng());
  const v = rng();
  return mean + sd * Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

// ── time helpers ─────────────────────────────────────────────────────────────
export const NOW = new Date();
const DAYS_HISTORY = 90;

export function daysAgo(n: number): Date {
  return new Date(NOW.getTime() - n * 86_400_000);
}
export function isoDay(d: Date): string {
  return d.toISOString().slice(0, 10);
}

// ── hourly meter readings (electricity + water by zone, 90 days) ────────────
export interface MeterReading {
  ts: Date;
  resource: Resource;
  zone: Zone;
  value: number;
}

const ZONE_ELEC_KWH_BASE: Record<Zone, number> = {
  shop_floor: 4.2, storage_room: 1.6, office: 1.1, kitchen: 3.4, restroom: 0.6,
};
const ZONE_WATER_M3_BASE: Record<Zone, number> = {
  shop_floor: 0.02, storage_room: 0.01, office: 0.015, kitchen: 0.08, restroom: 0.06,
};

let _meter: MeterReading[] | null = null;
export function meterReadings(): MeterReading[] {
  if (_meter) return _meter;
  const out: MeterReading[] = [];
  for (let d = DAYS_HISTORY; d >= 0; d--) {
    const day = daysAgo(d);
    const dow = day.getDay();
    const isWeekend = dow === 0 || dow === 6;
    for (let h = 0; h < 24; h++) {
      const ts = new Date(day);
      ts.setHours(h, 0, 0, 0);
      const open = h >= STORE.open_hour && h < STORE.close_hour;
      for (const zone of ZONES) {
        // electricity
        let kwh = ZONE_ELEC_KWH_BASE[zone];
        if (!open) kwh *= zone === "storage_room" ? 0.6 : 0.18; // closed-hour bleed (intentional waste seed)
        if (open) {
          const peak = h >= 12 && h <= 14 ? 1.3 : h >= 18 && h <= 21 ? 1.5 : 1.0;
          kwh *= peak * (isWeekend ? 1.15 : 1.0);
        }
        kwh *= 1 + gauss(0, 0.07);
        if (kwh < 0) kwh = 0;
        // anomaly injection: rare spikes
        if (rng() < 0.0015) kwh *= 3.2;
        out.push({ ts, resource: "electricity", zone, value: round(kwh, 3) });

        // water
        let m3 = ZONE_WATER_M3_BASE[zone];
        if (!open) m3 *= zone === "restroom" ? 0.35 : zone === "kitchen" ? 0.12 : 0.05;
        else m3 *= isWeekend ? 1.1 : 1.0;
        m3 *= 1 + gauss(0, 0.1);
        if (m3 < 0) m3 = 0;
        // leak injection (after-hours bleed for kitchen 5 days ago)
        if (zone === "kitchen" && d <= 6 && !open) m3 *= 4.5;
        out.push({ ts, resource: "water", zone, value: round(m3, 4) });
      }
    }
  }
  _meter = out;
  return out;
}

// ── footfall (hourly readings) + sales records ──────────────────────────────
export interface FootfallReading { ts: Date; count: number }
export interface SalesRecord { ts: Date; revenue_myr: number; items: number }

let _foot: FootfallReading[] | null = null;
let _sales: SalesRecord[] | null = null;
function buildFootfallAndSales() {
  if (_foot && _sales) return;
  const foot: FootfallReading[] = [];
  const sales: SalesRecord[] = [];
  for (let d = DAYS_HISTORY; d >= 0; d--) {
    const day = daysAgo(d);
    const dow = day.getDay();
    const weekendBoost = dow === 0 || dow === 6 ? 1.45 : dow === 5 ? 1.18 : 1.0;
    const trend = 1 + (DAYS_HISTORY - d) * 0.001; // slow growth
    for (let h = STORE.open_hour; h < STORE.close_hour; h++) {
      const ts = new Date(day);
      ts.setHours(h, 0, 0, 0);
      // U-shape: midday + evening peaks
      const hourShape = h <= 11 ? 0.45 : h <= 13 ? 1.0 : h <= 16 ? 0.7 : h <= 19 ? 1.3 : 0.85;
      const visitors = Math.max(0, Math.round(28 * hourShape * weekendBoost * trend * (1 + gauss(0, 0.18))));
      foot.push({ ts, count: visitors });
      // conversion ~ 26-32% w/ avg ticket RM 22-38
      const conv = 0.27 + gauss(0, 0.03);
      const txns = Math.max(0, Math.round(visitors * conv));
      const avg = 24 + gauss(0, 4) + (h >= 18 ? 6 : 0);
      const rev = round(txns * Math.max(8, avg), 2);
      if (txns > 0) sales.push({ ts, revenue_myr: rev, items: txns });
    }
  }
  _foot = foot;
  _sales = sales;
}
export function footfallReadings() { buildFootfallAndSales(); return _foot!; }
export function salesRecords() { buildFootfallAndSales(); return _sales!; }

// ── inventory + stock movements (spoilage / overstock seed) ─────────────────
export interface InventoryItem {
  id: string;
  name: string;
  category: string;
  unit_cost_myr: number;
  perishable: boolean;
  shelf_life_days: number | null;
  reorder_point: number;
  current_stock: number;
  storage_zone: "cold" | "ambient" | "dry";
}
export interface StockMovement {
  ts: Date;
  item_id: string;
  type: "received" | "sold" | "spoiled" | "discarded";
  qty: number;
  cost_impact_myr: number;
}

const INVENTORY_SEED: Array<[string, string, string, number, boolean, number | null, number, number, InventoryItem["storage_zone"]]> = [
  ["SKU-001", "Nasi Lemak Set", "F&B", 3.5, true, 2, 20, 45, "cold"],
  ["SKU-002", "Teh Tarik Pack (6)", "F&B", 8.0, true, 7, 10, 8, "cold"],
  ["SKU-003", "Roti Canai Frozen", "F&B", 5.2, true, 30, 15, 6, "cold"],
  ["SKU-004", "Mineral Water 500ml", "Beverages", 0.8, false, null, 50, 120, "ambient"],
  ["SKU-005", "100Plus 330ml", "Beverages", 1.5, false, null, 40, 95, "ambient"],
  ["SKU-006", "Milo Packet 200ml", "Beverages", 1.2, true, 90, 30, 22, "ambient"],
  ["SKU-007", "Disposable Cups (50)", "Packaging", 4.5, false, null, 10, 8, "dry"],
  ["SKU-008", "Paper Bags (100)", "Packaging", 6.0, false, null, 5, 4, "dry"],
  ["SKU-009", "Hand Sanitiser 500ml", "Hygiene", 9.9, false, null, 10, 18, "ambient"],
  ["SKU-010", "Face Masks (50pcs)", "Hygiene", 12.0, false, null, 5, 11, "dry"],
  ["SKU-011", "Cashier Receipt Roll", "Stationery", 3.8, false, null, 8, 14, "dry"],
  ["SKU-012", "Price Tag Stickers", "Stationery", 2.5, false, null, 5, 9, "dry"],
  ["SKU-013", "Curry Puff (12pcs)", "F&B", 9.0, true, 1, 30, 10, "cold"],
  ["SKU-014", "Iced Coffee Sachet", "Beverages", 0.9, false, null, 60, 180, "ambient"],
  ["SKU-015", "Coconut Water 330ml", "Beverages", 2.5, true, 21, 20, 5, "cold"],
  ["SKU-016", "Tissue Box 3-ply", "Hygiene", 5.5, false, null, 10, 24, "ambient"],
  ["SKU-017", "Cleaning Liquid 1L", "Hygiene", 11.0, false, null, 5, 7, "dry"],
  ["SKU-018", "Eco Bag (Reusable)", "Packaging", 3.0, false, null, 20, 35, "dry"],
  ["SKU-019", "Bubble Tea Cups (50)", "Packaging", 7.5, false, null, 8, 3, "dry"],
  ["SKU-020", "Ice Cream Bar", "F&B", 2.8, true, 14, 15, 2, "cold"],
];

let _inv: InventoryItem[] | null = null;
let _moves: StockMovement[] | null = null;

export function inventoryItems(): InventoryItem[] {
  if (_inv) return _inv;
  _inv = INVENTORY_SEED.map((r) => ({
    id: r[0], name: r[1], category: r[2], unit_cost_myr: r[3], perishable: r[4],
    shelf_life_days: r[5], reorder_point: r[6], current_stock: r[7], storage_zone: r[8],
  }));
  return _inv;
}

export function stockMovements(): StockMovement[] {
  if (_moves) return _moves;
  const moves: StockMovement[] = [];
  const items = inventoryItems();
  for (const it of items) {
    // ~30 days of activity
    for (let d = 30; d >= 0; d--) {
      const day = daysAgo(d);
      const sold = Math.max(0, Math.round(it.current_stock * (0.08 + rng() * 0.18)));
      if (sold > 0) moves.push({ ts: day, item_id: it.id, type: "sold", qty: sold, cost_impact_myr: round(sold * it.unit_cost_myr * 1.4, 2) });
      // perishables spoil
      if (it.perishable && rng() < 0.35) {
        const sp = Math.max(1, Math.round(sold * (0.08 + rng() * 0.22)));
        moves.push({ ts: day, item_id: it.id, type: "spoiled", qty: sp, cost_impact_myr: -round(sp * it.unit_cost_myr, 2) });
      }
      if (rng() < 0.18) {
        const rec = Math.max(5, Math.round(it.reorder_point * (0.5 + rng())));
        moves.push({ ts: day, item_id: it.id, type: "received", qty: rec, cost_impact_myr: -round(rec * it.unit_cost_myr, 2) });
      }
    }
  }
  _moves = moves;
  return moves;
}

// ── staff roster ─────────────────────────────────────────────────────────────
export interface StaffMember {
  id: string;
  name: string;
  role: "supervisor" | "associate" | "cashier";
  hourly_rate_myr: number;
  max_hours_week: number;
  off_days: number[]; // 0=Mon..6=Sun
}

export const STAFF: StaffMember[] = [
  { id: "stf-1", name: "Aisha Binti Rahman",   role: "supervisor", hourly_rate_myr: 12.0, max_hours_week: 44, off_days: [6] },
  { id: "stf-2", name: "Rahul Nair",           role: "supervisor", hourly_rate_myr: 12.0, max_hours_week: 40, off_days: [5] },
  { id: "stf-3", name: "Farid Bin Ismail",     role: "associate",  hourly_rate_myr: 8.5,  max_hours_week: 40, off_days: [] },
  { id: "stf-4", name: "Mei Ling Tan",         role: "associate",  hourly_rate_myr: 8.5,  max_hours_week: 40, off_days: [0] },
  { id: "stf-5", name: "Karthik Subramaniam",  role: "associate",  hourly_rate_myr: 8.5,  max_hours_week: 44, off_days: [] },
  { id: "stf-6", name: "Wei Jun Lim",          role: "cashier",    hourly_rate_myr: 9.0,  max_hours_week: 40, off_days: [5, 6] },
  { id: "stf-7", name: "Nurul Ain Binti Aziz", role: "associate",  hourly_rate_myr: 8.5,  max_hours_week: 44, off_days: [6] },
];

// ── tiny utils ───────────────────────────────────────────────────────────────
export function round(n: number, p = 2): number {
  const f = 10 ** p;
  return Math.round(n * f) / f;
}
export function sum(xs: number[]): number { return xs.reduce((a, b) => a + b, 0); }
export function mean(xs: number[]): number { return xs.length ? sum(xs) / xs.length : 0; }
export function pct(curr: number, prior: number): number {
  if (prior === 0) return curr === 0 ? 0 : 100;
  return ((curr - prior) / prior) * 100;
}
