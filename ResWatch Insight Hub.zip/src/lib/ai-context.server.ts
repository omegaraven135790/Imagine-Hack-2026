// Builds a compact JSON snapshot of the app's live data so the AI chat
// has the same view as the dashboards. Pure functions, deterministic data.
import {
  energySummary, footfallSummary, wasteSummary, inventorySummary,
  detectAnomalies, dailyEnergyTrend, dailyFootfallTrend, energyByZone,
  topSpoilers, peakHours,
} from "@/lib/reswatch-services";
import { STORE } from "@/lib/reswatch-data";
import { tx } from "@/lib/transportation-data";

export function buildAppContext(days = 30) {
  const energy = energySummary(days);
  const foot = footfallSummary(days);
  const waste = wasteSummary();
  const inv = inventorySummary();
  const anomalies = detectAnomalies(15);
  const spoilers = topSpoilers(5);
  const peaks = peakHours(5);

  const vehicles = tx.vehicles();
  const shipments = tx.shipments();
  const fleets = tx.fleets();
  const routes = tx.routes();
  const fuelLogs = tx.fuelLogs();

  const shipmentsByStatus = shipments.reduce<Record<string, number>>((acc, s) => {
    acc[s.status] = (acc[s.status] ?? 0) + 1;
    return acc;
  }, {});
  const vehiclesByStatus = vehicles.reduce<Record<string, number>>((acc, v) => {
    acc[v.status] = (acc[v.status] ?? 0) + 1;
    return acc;
  }, {});
  const totalFuelCost = fuelLogs.reduce((a, f) => a + (f.cost_myr ?? 0), 0);
  const totalFuelLiters = fuelLogs.reduce((a, f) => a + (f.volume_liters ?? 0), 0);

  return {
    generated_at: new Date().toISOString(),
    window_days: days,
    store: STORE,
    energy,
    footfall_sales: foot,
    waste,
    inventory: { ...inv, top_spoilers: spoilers },
    peak_hours: peaks,
    recent_anomalies: anomalies.slice(0, 10),
    trends: {
      electricity_daily: dailyEnergyTrend("electricity", days),
      water_daily: dailyEnergyTrend("water", days),
      footfall_daily: dailyFootfallTrend(days),
      electricity_by_zone: energyByZone("electricity", days),
    },
    transportation: {
      fleet_count: fleets.length,
      route_count: routes.length,
      vehicle_count: vehicles.length,
      vehicles_by_status: vehiclesByStatus,
      shipments_total: shipments.length,
      shipments_by_status: shipmentsByStatus,
      fuel: { total_cost_myr: totalFuelCost, total_liters: totalFuelLiters },
      vehicles: vehicles.map(v => ({
        id: v.id, label: v.label, registration_no: v.registration_no, status: v.status, fuel_type: v.fuel_type,
        odometer_km: v.odometer_km, fleet_id: v.fleet_id,
        assigned_route_ids: v.assigned_route_ids,
      })),
      recent_shipments: shipments.slice(0, 15),
    },
  };
}

export function buildContextSystemPrompt(days = 30): string {
  const ctx = buildAppContext(days);
  return [
    "You are an operations analyst assistant for ResWatch, a retail intelligence dashboard",
    "covering transportation, inventory, energy, footfall, and forecasts.",
    "Be concise, data-aware, and practical. Use MYR (RM) for currency.",
    "",
    "Below is a live JSON snapshot of the SAME data the user sees in the app.",
    "Use it as the source of truth. If asked about something not in the snapshot,",
    "say so plainly rather than inventing numbers.",
    "",
    "<APP_DATA>",
    JSON.stringify(ctx),
    "</APP_DATA>",
  ].join("\n");
}
