// Client-side helper for "bring your own" AI provider configuration.
// Stored in localStorage and sent as headers to /api/chat per request.

export type AiProvider = "lovable" | "openai" | "google" | "anthropic" | "openrouter" | "custom";

export type AiOverride = {
  provider: AiProvider;
  apiKey: string;
  model: string;
  baseUrl: string; // only used for "custom"
};

export const AI_STORAGE_KEY = "reswatch.ai.key.v1";

export const DEFAULT_MODELS: Record<AiProvider, string> = {
  lovable: "google/gemini-3-flash-preview",
  openai: "gpt-4o-mini",
  google: "gemini-2.5-flash",
  anthropic: "claude-3-5-haiku-latest",
  openrouter: "openai/gpt-4o-mini",
  custom: "",
};

export const PROVIDER_LABELS: Record<AiProvider, string> = {
  lovable: "Lovable AI Gateway (default)",
  openai: "OpenAI",
  google: "Google Gemini",
  anthropic: "Anthropic",
  openrouter: "OpenRouter",
  custom: "Custom (OpenAI-compatible)",
};

export const DEFAULT_OVERRIDE: AiOverride = {
  provider: "lovable",
  apiKey: "",
  model: DEFAULT_MODELS.lovable,
  baseUrl: "",
};

export function loadAiOverride(): AiOverride {
  if (typeof window === "undefined") return DEFAULT_OVERRIDE;
  try {
    const raw = localStorage.getItem(AI_STORAGE_KEY);
    if (!raw) return DEFAULT_OVERRIDE;
    return { ...DEFAULT_OVERRIDE, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_OVERRIDE;
  }
}

export function saveAiOverride(o: AiOverride) {
  localStorage.setItem(AI_STORAGE_KEY, JSON.stringify(o));
}

export function clearAiOverride() {
  localStorage.removeItem(AI_STORAGE_KEY);
}

/** Headers to attach to /api/chat requests. Empty when default provider is in use. */
export function getAiOverrideHeaders(): Record<string, string> {
  const o = loadAiOverride();
  if (o.provider === "lovable" || !o.apiKey.trim()) return {};
  const h: Record<string, string> = {
    "x-user-ai-provider": o.provider,
    "x-user-ai-key": o.apiKey,
  };
  if (o.model.trim()) h["x-user-ai-model"] = o.model.trim();
  if (o.provider === "custom" && o.baseUrl.trim()) h["x-user-ai-base-url"] = o.baseUrl.trim();
  return h;
}
