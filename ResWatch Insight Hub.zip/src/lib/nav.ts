export type NavItem = { label: string; to: string };

export const NAV_ITEMS: NavItem[] = [
  { label: "Dashboard", to: "/" },
  { label: "Energy & Water", to: "/energy-water" },
  { label: "Inventory", to: "/inventory" },
  { label: "Footfall & Sales", to: "/footfall-sales" },
  { label: "Forecast", to: "/forecast" },
  { label: "Anomalies", to: "/anomalies" },
  { label: "Waste & Savings", to: "/waste-savings" },
  { label: "Schedule", to: "/schedule" },
  { label: "Transportation", to: "/transportation" },
  { label: "AI Chat", to: "/ai-chat" },
  { label: "Insights", to: "/insights" },
  { label: "Settings", to: "/settings" },
];
