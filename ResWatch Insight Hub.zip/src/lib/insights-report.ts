import * as XLSX from "xlsx";
import {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType,
} from "docx";
import { saveAs } from "file-saver";
import {
  energySummary, footfallSummary, wasteSummary, inventorySummary,
  detectAnomalies, dailyEnergyTrend, dailyFootfallTrend, energyByZone,
  topSpoilers, peakHours, co2eFactor,
} from "@/lib/reswatch-services";
import { STORE, ZONE_LABEL, type Zone } from "@/lib/reswatch-data";

function fmtRM(n: number) {
  return `RM ${n.toLocaleString("en-MY", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function gatherReport(days: number) {
  const energy = energySummary(days);
  const foot = footfallSummary(days);
  const waste = wasteSummary();
  const inv = inventorySummary();
  const anomalies = detectAnomalies(50);
  const elecTrend = dailyEnergyTrend("electricity", days);
  const waterTrend = dailyEnergyTrend("water", days);
  const footTrend = dailyFootfallTrend(days);
  const zoneBreak = energyByZone("electricity", days);
  const spoilers = topSpoilers(8);
  const peaks = peakHours(8);

  const priorElecKwh = energy.electricity.delta_pct === 0
    ? energy.electricity.kwh
    : energy.electricity.kwh / (1 + energy.electricity.delta_pct / 100);
  const co2e = energy.electricity.co2e_kg;
  const priorCo2e = priorElecKwh * co2eFactor();
  const totalUtilities = energy.electricity.cost_myr + energy.water.cost_myr;
  const grossMargin = foot.sales.revenue_myr - totalUtilities - waste.total_cost_myr;

  return {
    days, energy, foot, waste, inv, anomalies,
    elecTrend, waterTrend, footTrend, zoneBreak, spoilers, peaks,
    co2e, priorCo2e, totalUtilities, grossMargin,
  };
}

type Report = ReturnType<typeof gatherReport>;

// ─── XLSX ─────────────────────────────────────────────────────────────────────
export function downloadXlsx(r: Report) {
  const wb = XLSX.utils.book_new();
  const now = new Date().toLocaleString();

  // Summary sheet
  const summary: (string | number)[][] = [
    ["ResWatch — Insights Report"],
    ["Store", STORE.name],
    ["Period", `Last ${r.days} days`],
    ["Generated", now],
    [],
    ["HEADLINE KPIs"],
    ["Metric", "Value", "Unit", "Delta vs prior period"],
    ["Total CO₂ Emissions", Math.round(r.co2e), "kg CO₂e", `${r.energy.electricity.delta_pct.toFixed(1)}%`],
    ["Prior period CO₂", Math.round(r.priorCo2e), "kg CO₂e", ""],
    ["Grid emission factor", co2eFactor(), "kg CO₂e / kWh", ""],
    ["Revenue", r.foot.sales.revenue_myr, "MYR", `${r.foot.sales.delta_pct.toFixed(1)}%`],
    ["Transactions", r.foot.sales.transactions, "count", ""],
    ["Avg basket size", r.foot.sales.transactions ? r.foot.sales.revenue_myr / r.foot.sales.transactions : 0, "MYR/txn", ""],
    ["Footfall (total)", r.foot.footfall.total, "visitors", `${r.foot.footfall.delta_pct.toFixed(1)}%`],
    ["Footfall (daily avg)", r.foot.footfall.avg_daily, "visitors/day", ""],
    ["Walk-in → paying conversion", r.foot.conversion.rate_pct, "%", `${r.foot.conversion.delta_pp}pp`],
    ["Electricity", r.energy.electricity.kwh, "kWh", `${r.energy.electricity.delta_pct.toFixed(1)}%`],
    ["Electricity cost", r.energy.electricity.cost_myr, "MYR", ""],
    ["Water", r.energy.water.m3, "m³", `${r.energy.water.delta_pct.toFixed(1)}%`],
    ["Water cost", r.energy.water.cost_myr, "MYR", ""],
    ["Recoverable waste (30d)", r.waste.total_cost_myr, "MYR", ""],
    ["Avoidable CO₂e from waste", r.waste.total_co2e_kg, "kg CO₂e", ""],
    ["At-risk products", r.inv.at_risk, "items", ""],
    ["Low-stock products", r.inv.low_stock, "items", ""],
    ["Open anomalies", r.anomalies.length, "events", ""],
    ["High-severity anomalies", r.anomalies.filter(a => a.severity === "HIGH").length, "events", ""],
    [],
    ["OPERATING CONTRIBUTION"],
    ["Revenue", r.foot.sales.revenue_myr],
    ["− Utilities (electricity + water)", -r.totalUtilities],
    ["− Recoverable waste", -r.waste.total_cost_myr],
    ["= Operating contribution", r.grossMargin],
  ];
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(summary), "Summary");

  // Daily trend
  const trend: (string | number)[][] = [["Date", "Electricity (kWh)", "Water (m³)", "Footfall", "Revenue (MYR)", "CO₂e (kg)"]];
  r.elecTrend.forEach((e, i) => trend.push([
    e.date, e.value, r.waterTrend[i]?.value ?? 0,
    r.footTrend[i]?.footfall ?? 0, r.footTrend[i]?.revenue ?? 0,
    +(e.value * co2eFactor()).toFixed(2),
  ]));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(trend), "Daily Trend");

  // Zone breakdown
  const zones: (string | number)[][] = [["Zone", "Electricity (kWh)", "CO₂e (kg)", "Est. cost (MYR)"]];
  const rate = r.energy.electricity.cost_myr / Math.max(r.energy.electricity.kwh, 1);
  r.zoneBreak.forEach(z => zones.push([z.label, z.value, +(z.value * co2eFactor()).toFixed(2), +(z.value * rate).toFixed(2)]));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(zones), "Electricity by Zone");

  // Peak hours
  const ph: (string | number)[][] = [["Window", "Avg visitors"]];
  r.peaks.forEach(p => ph.push([p.label, p.avg_count]));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(ph), "Peak Hours");

  // Top spoilers
  const sp: (string | number)[][] = [["Product", "Spoilage cost (MYR)"]];
  r.spoilers.items.forEach(s => sp.push([s.name, s.spoilage_cost_myr]));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(sp), "Top Spoiling Products");

  // Anomalies
  const an: (string | number)[][] = [["Metric", "Zone", "Severity", "Sigma (σ)", "Value", "Description", "Timestamp"]];
  r.anomalies.forEach(a => an.push([
    a.metric, a.zone ? (ZONE_LABEL[a.zone as Zone] ?? a.zone) : "—",
    a.severity, +a.z.toFixed(2), a.value, a.description, a.ts,
  ]));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(an), "Anomalies");

  // Waste categories
  const ws: (string | number)[][] = [["Category", "Count", "Cost (MYR)", "CO₂e (kg)"]];
  Object.entries(r.waste.categories).forEach(([cat, v]) =>
    ws.push([cat.replace("_", " "), v.count, v.cost_myr, v.co2e_kg]));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(ws), "Waste Breakdown");

  const buf = XLSX.write(wb, { bookType: "xlsx", type: "array" });
  saveAs(new Blob([buf], { type: "application/octet-stream" }),
    `reswatch-insights-${r.days}d-${new Date().toISOString().slice(0, 10)}.xlsx`);
}

// ─── DOCX ─────────────────────────────────────────────────────────────────────
const border = { style: BorderStyle.SINGLE, size: 4, color: "CCCCCC" };
const cellBorders = { top: border, bottom: border, left: border, right: border };

function p(text: string, opts: { bold?: boolean; size?: number; color?: string } = {}) {
  return new Paragraph({ children: [new TextRun({ text, bold: opts.bold, size: opts.size, color: opts.color })] });
}

function row(cells: string[], header = false, widths?: number[]) {
  return new TableRow({
    children: cells.map((c, i) => new TableCell({
      borders: cellBorders,
      width: widths ? { size: widths[i], type: WidthType.DXA } : undefined,
      shading: header ? { fill: "1E40AF", type: ShadingType.CLEAR, color: "auto" } : undefined,
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [new TextRun({ text: c, bold: header, color: header ? "FFFFFF" : "000000", size: 20 })] })],
    })),
  });
}

function kvTable(rows: [string, string][]) {
  const widths = [3600, 5760];
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: widths,
    rows: [row(["Metric", "Value"], true, widths), ...rows.map(r => row(r, false, widths))],
  });
}

export async function downloadDocx(r: Report) {
  const now = new Date().toLocaleString();
  const txnAvg = r.foot.sales.transactions ? r.foot.sales.revenue_myr / r.foot.sales.transactions : 0;
  const rate = r.energy.electricity.cost_myr / Math.max(r.energy.electricity.kwh, 1);
  const trees = (r.co2e / 21).toFixed(1);
  const highSev = r.anomalies.filter(a => a.severity === "HIGH").length;

  const trendWidths = [1400, 1592, 1592, 1592, 1592, 1592];
  const trendHeader = row(["Date", "Electricity (kWh)", "Water (m³)", "Footfall", "Revenue (RM)", "CO₂e (kg)"], true, trendWidths);
  const trendRows = r.elecTrend.map((e, i) => row([
    e.date, e.value.toLocaleString(), (r.waterTrend[i]?.value ?? 0).toLocaleString(),
    String(r.footTrend[i]?.footfall ?? 0), (r.footTrend[i]?.revenue ?? 0).toFixed(2),
    (e.value * co2eFactor()).toFixed(1),
  ], false, trendWidths));

  const zoneWidths = [3120, 2080, 2080, 2080];
  const zoneHeader = row(["Zone", "Electricity (kWh)", "CO₂e (kg)", "Est. cost (RM)"], true, zoneWidths);
  const zoneRows = r.zoneBreak.map(z => row([
    z.label, z.value.toLocaleString(),
    (z.value * co2eFactor()).toFixed(1), (z.value * rate).toFixed(2),
  ], false, zoneWidths));

  const peakWidths = [4680, 4680];
  const peakHeader = row(["Window", "Avg visitors"], true, peakWidths);
  const peakRows = r.peaks.map(pk => row([pk.label, String(pk.avg_count)], false, peakWidths));

  const spoilWidths = [6240, 3120];
  const spoilHeader = row(["Product", "Spoilage cost (RM)"], true, spoilWidths);
  const spoilRows = r.spoilers.items.map(s => row([s.name, s.spoilage_cost_myr.toFixed(2)], false, spoilWidths));

  const anWidths = [1440, 1800, 1440, 1080, 1200, 2400];
  const anHeader = row(["Metric", "Zone", "Severity", "σ", "Value", "Description"], true, anWidths);
  const anRows = r.anomalies.slice(0, 25).map(a => row([
    a.metric, a.zone ? (ZONE_LABEL[a.zone as Zone] ?? a.zone) : "—",
    a.severity, a.z.toFixed(1), String(a.value), a.description,
  ], false, anWidths));

  const doc = new Document({
    styles: {
      default: { document: { run: { font: "Arial", size: 22 } } },
      paragraphStyles: [
        { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
          run: { size: 36, bold: true, font: "Arial", color: "1E40AF" },
          paragraph: { spacing: { before: 360, after: 180 }, outlineLevel: 0 } },
        { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
          run: { size: 26, bold: true, font: "Arial", color: "0F172A" },
          paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 1 } },
      ],
    },
    sections: [{
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1080, right: 1080, bottom: 1080, left: 1080 },
        },
      },
      children: [
        new Paragraph({ alignment: AlignmentType.LEFT, children: [new TextRun({ text: "ResWatch", bold: true, size: 28, color: "1E40AF" })] }),
        new Paragraph({ heading: HeadingLevel.HEADING_1, children: [new TextRun("Operational Insights Report")] }),
        p(`${STORE.name} · Last ${r.days} days vs prior ${r.days} days`, { color: "555555" }),
        p(`Generated ${now}`, { color: "888888", size: 18 }),

        new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("Executive summary")] }),
        p(`Total CO₂ emissions reached ${Math.round(r.co2e).toLocaleString()} kg CO₂e (${r.energy.electricity.delta_pct >= 0 ? "+" : ""}${r.energy.electricity.delta_pct.toFixed(1)}% vs prior period), equivalent to ~${trees} trees needed to offset for a year. Electricity drove ${r.energy.electricity.kwh.toLocaleString()} kWh at ${fmtRM(r.energy.electricity.cost_myr)}; water consumption was ${r.energy.water.m3.toLocaleString()} m³ at ${fmtRM(r.energy.water.cost_myr)}.`),
        p(`Revenue totalled ${fmtRM(r.foot.sales.revenue_myr)} across ${r.foot.sales.transactions} transactions (avg basket ${fmtRM(txnAvg)}). Footfall was ${r.foot.footfall.total.toLocaleString()} visitors (${r.foot.footfall.avg_daily}/day). Walk-in to paying-customer conversion was ${r.foot.conversion.rate_pct}% (${r.foot.conversion.delta_pp >= 0 ? "+" : ""}${r.foot.conversion.delta_pp}pp).`),
        p(`Recoverable waste this month is ${fmtRM(r.waste.total_cost_myr)}, avoiding ${r.waste.total_co2e_kg} kg CO₂e. Inventory shows ${r.inv.at_risk} at-risk and ${r.inv.low_stock} low-stock products. ${r.anomalies.length} open anomalies (${highSev} high severity).`),

        new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("Operating contribution")] }),
        kvTable([
          ["Revenue", fmtRM(r.foot.sales.revenue_myr)],
          ["− Utilities (electricity + water)", `− ${fmtRM(r.totalUtilities)}`],
          ["− Recoverable waste", `− ${fmtRM(r.waste.total_cost_myr)}`],
          ["= Operating contribution", fmtRM(r.grossMargin)],
        ]),

        new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("Headline KPIs")] }),
        kvTable([
          ["Total CO₂ emissions", `${Math.round(r.co2e).toLocaleString()} kg CO₂e`],
          ["Prior-period CO₂", `${Math.round(r.priorCo2e).toLocaleString()} kg CO₂e`],
          ["Grid factor", `${co2eFactor()} kg CO₂e / kWh`],
          ["Revenue", `${fmtRM(r.foot.sales.revenue_myr)} (${r.foot.sales.transactions} txns)`],
          ["Avg basket", fmtRM(txnAvg)],
          ["Footfall", `${r.foot.footfall.total.toLocaleString()} (${r.foot.footfall.avg_daily}/day)`],
          ["Walk-in → paying conversion", `${r.foot.conversion.rate_pct}%`],
          ["Electricity", `${r.energy.electricity.kwh.toLocaleString()} kWh · ${fmtRM(r.energy.electricity.cost_myr)}`],
          ["Water", `${r.energy.water.m3.toLocaleString()} m³ · ${fmtRM(r.energy.water.cost_myr)}`],
          ["At-risk / low-stock products", `${r.inv.at_risk} / ${r.inv.low_stock}`],
          ["Open anomalies (high sev.)", `${r.anomalies.length} (${highSev})`],
        ]),

        new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("Daily cross-domain trend")] }),
        new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: trendWidths, rows: [trendHeader, ...trendRows] }),

        new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("Electricity by zone")] }),
        new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: zoneWidths, rows: [zoneHeader, ...zoneRows] }),

        new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("Peak demand windows")] }),
        new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: peakWidths, rows: [peakHeader, ...peakRows] }),

        new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("Top spoiling products")] }),
        new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: spoilWidths, rows: [spoilHeader, ...spoilRows] }),

        new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun("Open anomalies (top 25)")] }),
        new Table({ width: { size: 9360, type: WidthType.DXA }, columnWidths: anWidths, rows: [anHeader, ...anRows] }),

        p(""),
        p("Generated by ResWatch · Insights module", { color: "888888", size: 18 }),
      ],
    }],
  });

  const blob = await Packer.toBlob(doc);
  saveAs(blob, `reswatch-insights-${r.days}d-${new Date().toISOString().slice(0, 10)}.docx`);
}
