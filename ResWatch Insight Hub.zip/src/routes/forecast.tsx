import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import {
  ComposedChart, Area, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine,
} from "recharts";
import { TrendingUp, Zap, Droplets, Users, ShoppingBag, Cpu } from "lucide-react";
import { format, parseISO } from "date-fns";
import { dailyAggregate, forecast } from "@/lib/reswatch-services";

export const Route = createFileRoute("/forecast")({
  head: () => ({ meta: [{ title: "Forecasts — ResWatch" }] }),
  component: ForecastPage,
});

type ForecastMetric = "electricity" | "water" | "footfall" | "sales";

const METRIC_CFG: Record<ForecastMetric, {
  label: string; unit: string; color: string; icon: React.ReactNode;
  fmt: (v: number) => string;
}> = {
  electricity: { label: "Electricity", unit: "kWh", color: "var(--chart-1)", icon: <Zap className="h-4 w-4 text-chart-1" />, fmt: (v) => `${v.toLocaleString(undefined, { maximumFractionDigits: 0 })} kWh` },
  water:       { label: "Water",       unit: "m³",  color: "var(--chart-2)", icon: <Droplets className="h-4 w-4 text-chart-2" />, fmt: (v) => `${v.toLocaleString(undefined, { maximumFractionDigits: 1 })} m³` },
  footfall:    { label: "Footfall",    unit: "visitors", color: "var(--chart-4)", icon: <Users className="h-4 w-4 text-chart-4" />, fmt: (v) => `${Math.round(v).toLocaleString()} visitors` },
  sales:       { label: "Sales",       unit: "RM",  color: "var(--chart-3)", icon: <ShoppingBag className="h-4 w-4 text-chart-3" />, fmt: (v) => `RM ${v.toLocaleString("en-MY", { minimumFractionDigits: 2 })}` },
};

const MODEL_LABELS: Record<string, string> = {
  seasonal_naive: "Seasonal Naive",
  linear: "Linear Trend",
};

const METRICS: ForecastMetric[] = ["electricity", "water", "footfall", "sales"];
const HORIZON_OPTIONS = [
  { label: "7 Days", value: 7 },
  { label: "1 Month", value: 30 },
  { label: "3 Months", value: 90 },
] as const;
type HorizonValue = typeof HORIZON_OPTIONS[number]["value"];

const TODAY = new Date().toISOString().slice(0, 10);

function histDaysFor(h: number) { return h <= 7 ? 30 : h <= 30 ? 60 : 90; }
function dateTick(h: number) {
  return (v: string) => h <= 30 ? format(parseISO(v), "d MMM") : format(parseISO(v), "MMM");
}

function ForecastPage() {
  const [metric, setMetric] = useState<ForecastMetric>("footfall");
  const [horizon, setHorizon] = useState<HorizonValue>(7);
  const cfg = METRIC_CFG[metric];
  const histDays = histDaysFor(horizon);

  const history = useMemo(() => dailyAggregate(metric).slice(-histDays), [metric, histDays]);
  const fc = useMemo(() => forecast(dailyAggregate(metric), horizon), [metric, horizon]);

  const chartData = useMemo(() => {
    const hist = history.map((h, i) => ({
      date: h.ts.toISOString().slice(0, 10),
      historical: h.value,
      ...(i === history.length - 1 ? { predicted: h.value, lower: h.value, upper: h.value } : {}),
    }));
    const f = fc.points.map((p) => ({
      date: p.ts.slice(0, 10), predicted: p.predicted, lower: p.lower, upper: p.upper,
    }));
    return [...hist, ...f];
  }, [history, fc]);

  const fcTotal = fc.points.reduce((s, p) => s + p.predicted, 0);
  const fcAvgDay = fc.points.length ? fcTotal / fc.points.length : 0;

  return (
    <div className="space-y-6 p-8">
      <div className="flex items-center gap-3">
        <TrendingUp className="h-6 w-6 text-accent-blue" />
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Forecasts</h1>
          <p className="text-sm text-muted-foreground">Predictions with confidence bands</p>
        </div>
      </div>

      {/* Metric tabs */}
      <div className="flex flex-wrap gap-2">
        {METRICS.map((m) => {
          const c = METRIC_CFG[m];
          return (
            <button key={m} onClick={() => setMetric(m)}
              className={`flex items-center gap-2 rounded-lg border px-4 py-2 text-sm font-medium transition-colors ${metric === m ? "border-accent-blue/50 bg-accent-blue/10 text-accent-blue" : "border-border bg-surface text-muted-foreground hover:text-foreground"}`}>
              {c.icon}{c.label}
            </button>
          );
        })}
      </div>

      <div className="rounded-xl border border-border bg-surface p-5 space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="space-y-1">
            <h2 className="text-sm font-semibold">
              {cfg.label} — Last {histDays}d history + next {HORIZON_OPTIONS.find((o) => o.value === horizon)?.label}
            </h2>
            <p className="text-xs text-muted-foreground">Dashed line = forecast · shaded area = confidence band</p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-0.5 rounded-lg border border-border bg-surface-elevated p-0.5">
              {HORIZON_OPTIONS.map((opt) => (
                <button key={opt.value} onClick={() => setHorizon(opt.value)}
                  className={`rounded px-3 py-1 text-xs font-medium transition-colors ${horizon === opt.value ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>
                  {opt.label}
                </button>
              ))}
            </div>
            <span className={`rounded-full border px-3 py-1 text-xs font-medium border-accent-blue/30 bg-accent-blue/10 text-accent-blue`}>
              {MODEL_LABELS[fc.model] ?? fc.model}
            </span>
          </div>
        </div>

        <ResponsiveContainer width="100%" height={320}>
          <ComposedChart data={chartData} margin={{ top: 8, right: 12, bottom: 0, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="date" tickFormatter={dateTick(horizon)} tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
            <YAxis tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} axisLine={false} tickLine={false} width={56}
              tickFormatter={(v: number) => metric === "sales" ? `RM${(v / 1000).toFixed(0)}k` : v.toLocaleString()} />
            <Tooltip
              contentStyle={{ background: "var(--surface-elevated)", border: "1px solid var(--border)", borderRadius: 8 }}
              labelFormatter={(v) => format(parseISO(v as string), "EEEE, d MMM yyyy")}
              formatter={(val: number, name: string) => {
                if (name === "historical") return [cfg.fmt(val), "Actual"];
                if (name === "predicted") return [cfg.fmt(val), "Predicted"];
                return null;
              }}
            />
            <ReferenceLine x={TODAY} stroke="var(--border)" strokeDasharray="4 4" label={{ value: "Today", position: "top", fill: "var(--muted-foreground)", fontSize: 10 }} />
            <Area type="monotone" dataKey="upper" stroke="none" fill={cfg.color} fillOpacity={0.14} legendType="none" isAnimationActive={false} />
            <Area type="monotone" dataKey="lower" stroke="none" fill="var(--background)" fillOpacity={1} legendType="none" isAnimationActive={false} />
            <Line type="monotone" dataKey="historical" stroke={cfg.color} strokeWidth={2} dot={false} connectNulls={false} />
            <Line type="monotone" dataKey="predicted" stroke={cfg.color} strokeWidth={2} strokeDasharray="6 4" dot={false} opacity={0.85} connectNulls={false} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-xl border border-border bg-surface p-5 space-y-2">
          <p className="text-xs uppercase tracking-wide text-muted-foreground">{HORIZON_OPTIONS.find((o) => o.value === horizon)?.label} Total · predicted</p>
          <p className="text-2xl font-semibold">{cfg.fmt(fcTotal)}</p>
          <p className="text-xs text-muted-foreground">sum of forecast horizon</p>
        </div>
        <div className="rounded-xl border border-border bg-surface p-5 space-y-2">
          <p className="text-xs uppercase tracking-wide text-muted-foreground">Daily Average · predicted</p>
          <p className="text-2xl font-semibold">{cfg.fmt(fcAvgDay)}</p>
          <p className="text-xs text-muted-foreground">mean over horizon</p>
        </div>
        <div className="rounded-xl border border-border bg-surface p-5 space-y-2">
          <div className="flex items-center gap-2 text-xs uppercase tracking-wide text-muted-foreground"><Cpu className="h-3.5 w-3.5" /> Model</div>
          <p className="text-lg font-semibold">{MODEL_LABELS[fc.model] ?? fc.model}</p>
          <p className="text-xs text-muted-foreground">
            {fc.model === "seasonal_naive" ? "Same weekday last week ± 15%" : "Linear trend extrapolation ± 20%"}
          </p>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-surface p-5 space-y-4">
        <h2 className="text-sm font-semibold">Outlook — All Metrics</h2>
        <p className="text-xs text-muted-foreground">Click a metric above for the full chart</p>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {METRICS.map((m) => (
            <button key={m} onClick={() => setMetric(m)} className="rounded-lg border border-border bg-surface-elevated/40 p-4 text-left transition-colors hover:border-accent-blue/40">
              <div className="flex items-center gap-2 mb-2">{METRIC_CFG[m].icon}<span className="text-xs text-muted-foreground">{METRIC_CFG[m].label}</span></div>
              <p className="text-sm font-semibold">Next {horizon}d</p>
              <p className="text-xs text-muted-foreground mt-1">unit: {METRIC_CFG[m].unit}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
