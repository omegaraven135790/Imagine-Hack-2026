import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";
import { createFileRoute } from "@tanstack/react-router";
import { createOpenAICompatible } from "@ai-sdk/openai-compatible";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { buildContextSystemPrompt } from "@/lib/ai-context.server";

type ChatRequestBody = { messages?: unknown };

// Maps a user-selected provider to an OpenAI-compatible base URL.
function baseUrlFor(provider: string, customBase?: string | null) {
  switch (provider) {
    case "openai":
      return "https://api.openai.com/v1";
    case "google":
      return "https://generativelanguage.googleapis.com/v1beta/openai";
    case "anthropic":
      return "https://api.anthropic.com/v1";
    case "openrouter":
      return "https://openrouter.ai/api/v1";
    case "custom":
      return (customBase ?? "").replace(/\/+$/, "");
    default:
      return "";
  }
}

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { messages } = (await request.json()) as ChatRequestBody;
        if (!Array.isArray(messages)) {
          return new Response("Messages are required", { status: 400 });
        }

        const userProvider = request.headers.get("x-user-ai-provider");
        const userKey = request.headers.get("x-user-ai-key");
        const userModel = request.headers.get("x-user-ai-model");
        const userBaseUrl = request.headers.get("x-user-ai-base-url");

        const useOverride = !!(userProvider && userKey && userProvider !== "lovable");

        // Default: use the project's own Google Gemini API key with
        // gemini-2.5-flash. Override path still supported via headers.
        let model;
        try {
          if (useOverride) {
            const baseURL = baseUrlFor(userProvider!, userBaseUrl);
            if (!baseURL) {
              return new Response(
                "Missing base URL for custom AI provider",
                { status: 400 },
              );
            }
            const provider = createOpenAICompatible({
              name: userProvider!,
              baseURL,
              headers: { Authorization: `Bearer ${userKey}` },
            });
            const modelId = userModel?.trim() || "gpt-4o-mini";
            model = provider(modelId);
          } else {
            const geminiKey =
              process.env.GEMINI_API_KEY ||
              process.env.gemini_key ||
              process.env.VITE_GEMINI_API_KEY;
            if (!geminiKey) {
              return new Response(
                "Missing GEMINI_API_KEY. Set it in .env or project secrets.",
                { status: 500 },
              );
            }
            const provider = createOpenAICompatible({
              name: "google",
              baseURL: "https://generativelanguage.googleapis.com/v1beta/openai",
              headers: { Authorization: `Bearer ${geminiKey}` },
            });
            model = provider("gemini-2.5-flash");
          }
        } catch (e) {
          return new Response(
            `Failed to initialize AI provider: ${(e as Error).message}`,
            { status: 500 },
          );
        }

        const result = streamText({
          model,
          system: buildContextSystemPrompt(30),
          messages: await convertToModelMessages(messages as UIMessage[]),
        });

        return result.toUIMessageStreamResponse({
          originalMessages: messages as UIMessage[],
        });
      },
    },
  },
});
