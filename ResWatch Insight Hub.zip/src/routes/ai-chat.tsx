import { createFileRoute } from "@tanstack/react-router";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { useEffect, useMemo, useRef, useState } from "react";
import { Send, Bot, User, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { getAiOverrideHeaders, loadAiOverride, PROVIDER_LABELS } from "@/lib/ai-override";

export const Route = createFileRoute("/ai-chat")({
  component: AiChatPage,
});

function AiChatPage() {
  const transport = useMemo(
    () =>
      new DefaultChatTransport({
        api: "/api/chat",
        headers: () => getAiOverrideHeaders(),
      }),
    [],
  );
  const { messages, sendMessage, status, error } = useChat({
    id: "reswatch-chat",
    messages: [] as UIMessage[],
    transport,
  });
  const activeProvider =
    typeof window !== "undefined" ? loadAiOverride().provider : "lovable";
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);
  const busy = status === "submitted" || status === "streaming";

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, status]);

  useEffect(() => {
    taRef.current?.focus();
  }, [status]);

  const submit = async () => {
    const text = input.trim();
    if (!text || busy) return;
    setInput("");
    await sendMessage({ text });
  };

  return (
    <div className="flex h-screen flex-col px-8 py-6">
      <header className="mb-4">
        <h1 className="text-2xl font-semibold tracking-tight">AI Assistant</h1>
        <p className="text-sm text-muted-foreground">
          Ask about operations, transportation, inventory, or forecasts.
        </p>
        <p className="mt-1 text-xs text-muted-foreground">
          Provider: {PROVIDER_LABELS[activeProvider]} · change in Settings → AI
        </p>
      </header>

      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto rounded-xl bg-surface/40 p-6"
      >
        {messages.length === 0 && (
          <div className="grid h-full place-items-center text-center text-muted-foreground">
            <div>
              <Bot className="mx-auto mb-3 h-10 w-10 opacity-60" />
              <p className="text-sm">Start a conversation — try "Summarize last week's transport KPIs"</p>
            </div>
          </div>
        )}

        <div className="mx-auto flex max-w-3xl flex-col gap-5">
          {messages.map((m) => {
            const text = m.parts
              .map((p) => (p.type === "text" ? p.text : ""))
              .join("");
            const isUser = m.role === "user";
            return (
              <div
                key={m.id}
                className={`flex gap-3 ${isUser ? "justify-end" : "justify-start"}`}
              >
                {!isUser && (
                  <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-accent-blue text-accent-blue-foreground">
                    <Bot className="h-4 w-4" />
                  </div>
                )}
                <div
                  className={
                    isUser
                      ? "max-w-[75%] rounded-2xl bg-primary px-4 py-2.5 text-sm text-primary-foreground"
                      : "max-w-[75%] whitespace-pre-wrap text-sm leading-relaxed text-foreground"
                  }
                >
                  {text || (busy && !isUser ? "…" : "")}
                </div>
                {isUser && (
                  <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-surface-elevated text-foreground">
                    <User className="h-4 w-4" />
                  </div>
                )}
              </div>
            );
          })}
          {status === "submitted" && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" /> Thinking…
            </div>
          )}
          {error && (
            <div className="rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
              {error.message || "Something went wrong."}
            </div>
          )}
        </div>
      </div>

      <div className="mt-4 flex items-end gap-2">
        <Textarea
          ref={taRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              submit();
            }
          }}
          placeholder="Ask the assistant…"
          rows={2}
          className="resize-none"
        />
        <Button onClick={submit} disabled={busy || !input.trim()} size="lg">
          <Send className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
