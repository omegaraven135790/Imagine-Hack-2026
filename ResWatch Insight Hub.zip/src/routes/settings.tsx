import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { PageShell } from "@/components/page-shell";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Database, Plug, Bell, Building2, Target, SlidersHorizontal, Shield, Download, Trash2, CheckCircle2, AlertCircle, Sparkles, Cloud } from "lucide-react";
import {
  AI_STORAGE_KEY,
  DEFAULT_MODELS,
  DEFAULT_OVERRIDE,
  PROVIDER_LABELS,
  loadAiOverride,
  type AiOverride,
  type AiProvider,
} from "@/lib/ai-override";

export const Route = createFileRoute("/settings")({
  head: () => ({ meta: [{ title: "Settings — ResWatch" }] }),
  component: SettingsPage,
});

type Settings = {
  business: {
    name: string;
    location: string;
    timezone: string;
    currency: string;
    sqft: number;
    seats: number;
    openHour: number;
    closeHour: number;
  };
  connection: {
    provider: "rest" | "postgres" | "mysql" | "csv" | "supabase";
    endpoint: string;
    apiKey: string;
    database: string;
    refreshMinutes: number;
    enabled: boolean;
  };
  supabaseOverride: {
    enabled: boolean;
    url: string;
    anonKey: string;
  };
  ingestion: {
    timestampField: string;
    electricityKwhField: string;
    waterLitersField: string;
    gasField: string;
    salesField: string;
    transactionsField: string;
    footfallField: string;
    wasteKgField: string;
    zoneField: string;
    skuField: string;
    skuQtyField: string;
  };
  units: {
    energy: "kWh" | "MJ";
    water: "L" | "gal";
    weight: "kg" | "lb";
    distance: "km" | "mi";
    temperature: "C" | "F";
  };
  targets: {
    co2ReductionPct: number;
    energyReductionPct: number;
    waterReductionPct: number;
    wasteReductionPct: number;
    salesGrowthPct: number;
  };
  notifications: {
    emailDigest: boolean;
    digestFrequency: "daily" | "weekly" | "monthly";
    anomalyAlerts: boolean;
    forecastAlerts: boolean;
    alertEmail: string;
    threshold: number;
  };
};

const DEFAULTS: Settings = {
  business: {
    name: "My Restaurant",
    location: "",
    timezone: "America/New_York",
    currency: "USD",
    sqft: 2500,
    seats: 60,
    openHour: 11,
    closeHour: 22,
  },
  connection: {
    provider: "rest",
    endpoint: "",
    apiKey: "",
    database: "",
    refreshMinutes: 15,
    enabled: false,
  },
  supabaseOverride: {
    enabled: false,
    url: "",
    anonKey: "",
  },
  ingestion: {
    timestampField: "timestamp",
    electricityKwhField: "electricity_kwh",
    waterLitersField: "water_liters",
    gasField: "gas_m3",
    salesField: "sales_amount",
    transactionsField: "transactions",
    footfallField: "footfall",
    wasteKgField: "waste_kg",
    zoneField: "zone",
    skuField: "product_id",
    skuQtyField: "quantity",
  },
  units: { energy: "kWh", water: "L", weight: "kg", distance: "km", temperature: "C" },
  targets: {
    co2ReductionPct: 15,
    energyReductionPct: 10,
    waterReductionPct: 12,
    wasteReductionPct: 20,
    salesGrowthPct: 8,
  },
  notifications: {
    emailDigest: true,
    digestFrequency: "weekly",
    anomalyAlerts: true,
    forecastAlerts: false,
    alertEmail: "",
    threshold: 15,
  },
};

const STORAGE_KEY = "reswatch.settings.v1";

/** Normalize anything a user might paste into a canonical https://<host> URL.
 * Returns null when the input clearly isn't a Supabase project URL. */
function normalizeSupabaseUrl(input: string): string | null {
  const trimmed = (input ?? "").trim();
  if (!trimmed) return null;
  let url: URL;
  try {
    url = new URL(trimmed.startsWith("http") ? trimmed : `https://${trimmed}`);
  } catch {
    return null;
  }
  if (url.protocol !== "https:") return null;
  // Dashboard URL → project ref → API URL.
  const dash = url.pathname.match(/\/dashboard\/project\/([a-z0-9]+)/i);
  if (url.hostname === "supabase.com" && dash) {
    return `https://${dash[1]}.supabase.co`;
  }
  // Strip /rest/v1, /auth/v1, trailing slashes, any path.
  return `https://${url.host}`;
}

/** Block obvious mis-pastes (service-role keys) before they hit the network. */
function describeKeyProblem(key: string): string | null {
  const k = key.trim();
  if (k.startsWith("sb_secret_")) return "That looks like a service-role key. Use the publishable / anon key instead.";
  if (k.startsWith("eyJ")) {
    // Legacy JWT keys — decode the middle segment to inspect the role.
    try {
      const payload = JSON.parse(atob(k.split(".")[1].replace(/-/g, "+").replace(/_/g, "/")));
      if (payload?.role === "service_role") {
        return "That's a service-role key. Use the anon key instead — never paste service-role keys here.";
      }
    } catch {
      /* not a JWT we can decode; allow it through */
    }
  }
  return null;
}


function loadSettings(): Settings {
  if (typeof window === "undefined") return DEFAULTS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULTS;
    const parsed = JSON.parse(raw);
    return {
      business: { ...DEFAULTS.business, ...parsed.business },
      connection: { ...DEFAULTS.connection, ...parsed.connection },
      supabaseOverride: { ...DEFAULTS.supabaseOverride, ...parsed.supabaseOverride },
      ingestion: { ...DEFAULTS.ingestion, ...parsed.ingestion },
      units: { ...DEFAULTS.units, ...parsed.units },
      targets: { ...DEFAULTS.targets, ...parsed.targets },
      notifications: { ...DEFAULTS.notifications, ...parsed.notifications },
    };
  } catch {
    return DEFAULTS;
  }
}

function SettingsPage() {
  const [settings, setSettings] = useState<Settings>(DEFAULTS);
  const [dirty, setDirty] = useState(false);
  const [testStatus, setTestStatus] = useState<null | "ok" | "fail" | "testing">(null);
  const [supaTestStatus, setSupaTestStatus] = useState<null | "ok" | "fail" | "testing">(null);
  const [ai, setAi] = useState<AiOverride>(DEFAULT_OVERRIDE);
  const [aiDirty, setAiDirty] = useState(false);
  const [aiTestStatus, setAiTestStatus] = useState<null | "ok" | "fail" | "testing">(null);

  const cloudUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
  const cloudConnected = !!cloudUrl;

  useEffect(() => {
    setSettings(loadSettings());
    setAi(loadAiOverride());
  }, []);

  const update = <K extends keyof Settings>(key: K, patch: Partial<Settings[K]>) => {
    setSettings((s) => ({ ...s, [key]: { ...s[key], ...patch } }));
    setDirty(true);
  };

  const updateAi = (patch: Partial<AiOverride>) => {
    setAi((a) => {
      const next = { ...a, ...patch };
      // when provider changes, swap to its default model
      if (patch.provider && patch.provider !== a.provider) {
        next.model = DEFAULT_MODELS[patch.provider];
      }
      return next;
    });
    setAiDirty(true);
  };

  const save = () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    if (aiDirty) {
      localStorage.setItem(AI_STORAGE_KEY, JSON.stringify(ai));
      setAiDirty(false);
    }
    setDirty(false);
    toast.success("Settings saved");
  };

  const reset = () => {
    setSettings(DEFAULTS);
    setAi(DEFAULT_OVERRIDE);
    setDirty(true);
    setAiDirty(true);
    toast("Reset to defaults — click Save to apply");
  };

  const exportConfig = () => {
    const blob = new Blob(
      [JSON.stringify({ ...settings, ai }, null, 2)],
      { type: "application/json" },
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "reswatch-settings.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const testConnection = async () => {
    setTestStatus("testing");
    await new Promise((r) => setTimeout(r, 900));
    const ok = settings.connection.provider === "csv" ||
      (settings.connection.endpoint.length > 4 && settings.connection.apiKey.length > 0);
    setTestStatus(ok ? "ok" : "fail");
    if (ok) toast.success("Connection looks valid");
    else toast.error("Endpoint or API key missing");
  };

  const testSupabaseOverride = async () => {
    const rawUrl = settings.supabaseOverride.url;
    const anonKey = settings.supabaseOverride.anonKey.trim();
    const normalized = normalizeSupabaseUrl(rawUrl);

    if (!normalized) {
      toast.error("Enter a valid Supabase URL, e.g. https://<ref>.supabase.co");
      setSupaTestStatus("fail");
      return;
    }
    if (!anonKey) {
      toast.error("Anon / publishable key is required");
      setSupaTestStatus("fail");
      return;
    }
    const keyProblem = describeKeyProblem(anonKey);
    if (keyProblem) {
      toast.error(keyProblem);
      setSupaTestStatus("fail");
      return;
    }

    if (normalized !== rawUrl) {
      update("supabaseOverride", { url: normalized });
    }

    setSupaTestStatus("testing");
    try {
      // /auth/v1/settings returns 200 JSON for any reachable project with a
      // valid publishable/anon key — including the new `sb_publishable_*`
      // format, which 401s against `/rest/v1/`.
      const r = await fetch(`${normalized}/auth/v1/settings`, {
        headers: { apikey: anonKey },
      });
      if (r.ok) {
        setSupaTestStatus("ok");
        toast.success("Supabase reachable — reload to start using this project");
      } else if (r.status === 401 || r.status === 403) {
        setSupaTestStatus("fail");
        toast.error("Invalid anon / publishable key for this project");
      } else {
        setSupaTestStatus("fail");
        toast.error(`Supabase replied ${r.status}`);
      }
    } catch (e) {
      setSupaTestStatus("fail");
      toast.error(`Could not reach Supabase: ${(e as Error).message}`);
    }
  };

  const testAi = async () => {
    if (ai.provider === "lovable") {
      toast.success("Lovable AI Gateway is always available");
      setAiTestStatus("ok");
      return;
    }
    if (!ai.apiKey.trim()) {
      toast.error("API key is required");
      setAiTestStatus("fail");
      return;
    }
    setAiTestStatus("testing");
    try {
      // Send a 1-message ping via our chat route with the override headers set.
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
        "x-user-ai-provider": ai.provider,
        "x-user-ai-key": ai.apiKey,
      };
      if (ai.model.trim()) headers["x-user-ai-model"] = ai.model.trim();
      if (ai.provider === "custom" && ai.baseUrl.trim()) {
        headers["x-user-ai-base-url"] = ai.baseUrl.trim();
      }
      const r = await fetch("/api/chat", {
        method: "POST",
        headers,
        body: JSON.stringify({
          messages: [
            { id: "ping", role: "user", parts: [{ type: "text", text: "ping" }] },
          ],
        }),
      });
      if (r.ok) {
        setAiTestStatus("ok");
        toast.success("AI provider responded");
      } else {
        const text = await r.text();
        setAiTestStatus("fail");
        toast.error(`AI test failed (${r.status}): ${text.slice(0, 120)}`);
      }
    } catch (e) {
      setAiTestStatus("fail");
      toast.error(`AI test failed: ${(e as Error).message}`);
    }
  };

  const maskedKey = useMemo(
    () => (settings.connection.apiKey ? "•".repeat(Math.min(settings.connection.apiKey.length, 24)) : ""),
    [settings.connection.apiKey],
  );

  const anyDirty = dirty || aiDirty;

  return (
    <PageShell title="Settings" description="Configure data sources, ingestion mappings, units, targets and alerts.">
      <div className="mb-4 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          {anyDirty ? (
            <Badge variant="outline" className="text-amber-600 border-amber-400/40">Unsaved changes</Badge>
          ) : (
            <Badge variant="outline" className="text-emerald-600 border-emerald-400/40">All changes saved</Badge>
          )}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={exportConfig}><Download className="mr-2 h-4 w-4" />Export</Button>
          <Button variant="outline" size="sm" onClick={reset}><Trash2 className="mr-2 h-4 w-4" />Reset</Button>
          <Button size="sm" onClick={save} disabled={!anyDirty}>Save changes</Button>
        </div>
      </div>

      <Tabs defaultValue="connection" className="w-full">
        <TabsList className="grid grid-cols-4 md:grid-cols-7 w-full">
          <TabsTrigger value="connection"><Plug className="mr-2 h-4 w-4" />Data Source</TabsTrigger>
          <TabsTrigger value="ai"><Sparkles className="mr-2 h-4 w-4" />AI</TabsTrigger>
          <TabsTrigger value="ingestion"><Database className="mr-2 h-4 w-4" />Ingestion</TabsTrigger>
          <TabsTrigger value="business"><Building2 className="mr-2 h-4 w-4" />Business</TabsTrigger>
          <TabsTrigger value="units"><SlidersHorizontal className="mr-2 h-4 w-4" />Units</TabsTrigger>
          <TabsTrigger value="targets"><Target className="mr-2 h-4 w-4" />Targets</TabsTrigger>
          <TabsTrigger value="alerts"><Bell className="mr-2 h-4 w-4" />Alerts</TabsTrigger>
        </TabsList>

        {/* CONNECTION */}
        <TabsContent forceMount value="connection" className="mt-4 space-y-4 data-[state=inactive]:hidden">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Cloud className="h-4 w-4" />Lovable Cloud backend</CardTitle>
              <CardDescription>
                Managed Postgres + auth + storage, provisioned for this project. No keys to configure.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between rounded-md border p-3">
                <div>
                  <div className="text-sm font-medium flex items-center gap-2">
                    {cloudConnected ? (
                      <><CheckCircle2 className="h-4 w-4 text-emerald-500" /> Connected</>
                    ) : (
                      <><AlertCircle className="h-4 w-4 text-amber-500" /> Not connected</>
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground break-all">
                    {cloudUrl ?? "Cloud not yet enabled for this project."}
                  </div>
                </div>
                <Badge variant="outline">Default</Badge>
              </div>

              <div className="flex items-center justify-between rounded-md border p-3">
                <div>
                  <div className="text-sm font-medium">Use my own Supabase project instead</div>
                  <div className="text-xs text-muted-foreground">
                    Useful when exporting to GitHub or self-hosting.
                  </div>
                </div>
                <Switch
                  checked={settings.supabaseOverride.enabled}
                  onCheckedChange={(v) => update("supabaseOverride", { enabled: v })}
                />
              </div>

              {settings.supabaseOverride.enabled && (
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2 md:col-span-2">
                    <Label>Supabase URL</Label>
                    <Input
                      placeholder="https://xxxx.supabase.co"
                      value={settings.supabaseOverride.url}
                      onChange={(e) => update("supabaseOverride", { url: e.target.value })}
                      onBlur={(e) => {
                        const n = normalizeSupabaseUrl(e.target.value);
                        if (n && n !== e.target.value) update("supabaseOverride", { url: n });
                      }}
                    />
                    {settings.supabaseOverride.url && (() => {
                      const n = normalizeSupabaseUrl(settings.supabaseOverride.url);
                      return n && n !== settings.supabaseOverride.url ? (
                        <p className="text-xs text-muted-foreground">Will call: <span className="font-mono">{n}</span></p>
                      ) : null;
                    })()}
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label>Anon / publishable key</Label>
                    <Input
                      type="password"
                      placeholder="sb_publishable_..."
                      value={settings.supabaseOverride.anonKey}
                      onChange={(e) => update("supabaseOverride", { anonKey: e.target.value })}
                    />
                    <p className="text-xs text-muted-foreground">
                      Stored locally in your browser. Never paste your service-role key here.
                    </p>
                  </div>
                  <div className="md:col-span-2 flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm">
                      {supaTestStatus === "ok" && (<><CheckCircle2 className="h-4 w-4 text-emerald-500" /> Reachable</>)}
                      {supaTestStatus === "fail" && (<><AlertCircle className="h-4 w-4 text-red-500" /> Unreachable</>)}
                      {supaTestStatus === "testing" && <span className="text-muted-foreground">Testing…</span>}
                      {supaTestStatus === null && <span className="text-muted-foreground">Not tested yet</span>}
                    </div>
                    <div className="flex items-center gap-2">
                      {supaTestStatus === "ok" && (
                        <Button variant="outline" onClick={() => window.location.reload()}>Reload to apply</Button>
                      )}
                      <Button variant="outline" onClick={testSupabaseOverride} disabled={supaTestStatus === "testing"}>
                        Test connection
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>External data source (optional)</CardTitle>
              <CardDescription>POS, IoT meters, or warehouse for ingestion. Not yet wired to the dashboard.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between rounded-md border p-3">
                <div>
                  <div className="font-medium text-sm">Live ingestion</div>
                  <div className="text-xs text-muted-foreground">When off, the app uses sample data.</div>
                </div>
                <Switch checked={settings.connection.enabled} onCheckedChange={(v) => update("connection", { enabled: v })} />
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>Provider</Label>
                  <Select value={settings.connection.provider} onValueChange={(v) => update("connection", { provider: v as Settings["connection"]["provider"] })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="rest">REST API</SelectItem>
                      <SelectItem value="supabase">Supabase</SelectItem>
                      <SelectItem value="postgres">PostgreSQL</SelectItem>
                      <SelectItem value="mysql">MySQL</SelectItem>
                      <SelectItem value="csv">CSV Upload</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Refresh interval (minutes)</Label>
                  <Input type="number" min={1} max={1440} value={settings.connection.refreshMinutes}
                    onChange={(e) => update("connection", { refreshMinutes: Number(e.target.value) })} />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Endpoint / Host URL</Label>
                  <Input placeholder="https://api.yourcompany.com/v1 or db.example.com:5432"
                    value={settings.connection.endpoint}
                    onChange={(e) => update("connection", { endpoint: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label>Database / Schema</Label>
                  <Input placeholder="public" value={settings.connection.database}
                    onChange={(e) => update("connection", { database: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label>API Key / Token</Label>
                  <Input type="password" placeholder={maskedKey || "Paste secret"}
                    value={settings.connection.apiKey}
                    onChange={(e) => update("connection", { apiKey: e.target.value })} />
                  <p className="text-xs text-muted-foreground">Stored locally in your browser. Never sent to third parties.</p>
                </div>
              </div>

              <Separator />
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm">
                  {testStatus === "ok" && (<><CheckCircle2 className="h-4 w-4 text-emerald-500" /> Connection verified</>)}
                  {testStatus === "fail" && (<><AlertCircle className="h-4 w-4 text-red-500" /> Connection failed</>)}
                  {testStatus === "testing" && <span className="text-muted-foreground">Testing…</span>}
                  {testStatus === null && <span className="text-muted-foreground">Not tested yet</span>}
                </div>
                <Button variant="outline" onClick={testConnection}>Test connection</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* AI */}
        <TabsContent forceMount value="ai" className="mt-4 space-y-4 data-[state=inactive]:hidden">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Sparkles className="h-4 w-4" />AI provider</CardTitle>
              <CardDescription>
                The assistant uses Lovable AI Gateway by default. Paste your own key to use OpenAI,
                Gemini, Anthropic, OpenRouter, or any OpenAI-compatible endpoint.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>Provider</Label>
                  <Select value={ai.provider} onValueChange={(v) => updateAi({ provider: v as AiProvider })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {(Object.keys(PROVIDER_LABELS) as AiProvider[]).map((p) => (
                        <SelectItem key={p} value={p}>{PROVIDER_LABELS[p]}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Model</Label>
                  <Input
                    placeholder={DEFAULT_MODELS[ai.provider] || "model name"}
                    value={ai.model}
                    onChange={(e) => updateAi({ model: e.target.value })}
                    disabled={ai.provider === "lovable"}
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>API key</Label>
                  <Input
                    type="password"
                    placeholder={ai.provider === "lovable" ? "Auto-provisioned by Lovable" : "sk-..."}
                    value={ai.apiKey}
                    onChange={(e) => updateAi({ apiKey: e.target.value })}
                    disabled={ai.provider === "lovable"}
                  />
                  <p className="text-xs text-muted-foreground">
                    Stored in your browser's localStorage and sent to <code>/api/chat</code> per request as a header.
                    Fine for single-user/self-hosted use; not safe for multi-user deployments.
                  </p>
                </div>
                {ai.provider === "custom" && (
                  <div className="space-y-2 md:col-span-2">
                    <Label>Base URL</Label>
                    <Input
                      placeholder="https://api.example.com/v1"
                      value={ai.baseUrl}
                      onChange={(e) => updateAi({ baseUrl: e.target.value })}
                    />
                  </div>
                )}
              </div>

              <Separator />
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm">
                  {aiTestStatus === "ok" && (<><CheckCircle2 className="h-4 w-4 text-emerald-500" /> Working</>)}
                  {aiTestStatus === "fail" && (<><AlertCircle className="h-4 w-4 text-red-500" /> Failed</>)}
                  {aiTestStatus === "testing" && <span className="text-muted-foreground">Testing…</span>}
                  {aiTestStatus === null && <span className="text-muted-foreground">Not tested yet</span>}
                </div>
                <div className="flex gap-2">
                  <Button variant="ghost" onClick={() => updateAi(DEFAULT_OVERRIDE)}>Reset to Lovable AI</Button>
                  <Button variant="outline" onClick={testAi}>Test</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>


        {/* INGESTION */}
        <TabsContent forceMount value="ingestion" className="mt-4 space-y-4 data-[state=inactive]:hidden">
          <Card>
            <CardHeader>
              <CardTitle>Field Mapping</CardTitle>
              <CardDescription>Map your column names so ResWatch knows where each metric lives.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              {([
                ["timestampField", "Timestamp column"],
                ["electricityKwhField", "Electricity (kWh)"],
                ["waterLitersField", "Water (liters)"],
                ["gasField", "Gas (m³)"],
                ["salesField", "Sales amount"],
                ["transactionsField", "Transactions / orders"],
                ["footfallField", "Footfall / visitors"],
                ["wasteKgField", "Waste (kg)"],
                ["zoneField", "Zone / area label"],
                ["skuField", "Product / menu item ID"],
                ["skuQtyField", "Item quantity"],
              ] as const).map(([key, label]) => (
                <div className="space-y-2" key={key}>
                  <Label>{label}</Label>
                  <Input value={settings.ingestion[key]}
                    onChange={(e) => update("ingestion", { [key]: e.target.value } as Partial<Settings["ingestion"]>)} />
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Sample payload</CardTitle>
              <CardDescription>Send rows shaped like this to your endpoint.</CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea readOnly className="font-mono text-xs h-44"
                value={JSON.stringify(
                  Object.fromEntries(Object.entries(settings.ingestion).map(([, v]) => [v, "<value>"])),
                  null, 2,
                )} />
            </CardContent>
          </Card>
        </TabsContent>

        {/* BUSINESS */}
        <TabsContent forceMount value="business" className="mt-4 space-y-4 data-[state=inactive]:hidden">
          <Card>
            <CardHeader><CardTitle>Business profile</CardTitle><CardDescription>Used for benchmarks and per-seat metrics.</CardDescription></CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2"><Label>Business name</Label>
                <Input value={settings.business.name} onChange={(e) => update("business", { name: e.target.value })} /></div>
              <div className="space-y-2"><Label>Location</Label>
                <Input placeholder="City, Country" value={settings.business.location} onChange={(e) => update("business", { location: e.target.value })} /></div>
              <div className="space-y-2"><Label>Timezone</Label>
                <Input value={settings.business.timezone} onChange={(e) => update("business", { timezone: e.target.value })} /></div>
              <div className="space-y-2"><Label>Currency</Label>
                <Select value={settings.business.currency} onValueChange={(v) => update("business", { currency: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["USD","EUR","GBP","CAD","AUD","JPY","INR"].map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select></div>
              <div className="space-y-2"><Label>Floor area (sq ft)</Label>
                <Input type="number" value={settings.business.sqft} onChange={(e) => update("business", { sqft: Number(e.target.value) })} /></div>
              <div className="space-y-2"><Label>Seats</Label>
                <Input type="number" value={settings.business.seats} onChange={(e) => update("business", { seats: Number(e.target.value) })} /></div>
              <div className="space-y-2"><Label>Open hour (0–23)</Label>
                <Input type="number" min={0} max={23} value={settings.business.openHour} onChange={(e) => update("business", { openHour: Number(e.target.value) })} /></div>
              <div className="space-y-2"><Label>Close hour (0–23)</Label>
                <Input type="number" min={0} max={23} value={settings.business.closeHour} onChange={(e) => update("business", { closeHour: Number(e.target.value) })} /></div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* UNITS */}
        <TabsContent forceMount value="units" className="mt-4 space-y-4 data-[state=inactive]:hidden">
          <Card>
            <CardHeader><CardTitle>Display units</CardTitle><CardDescription>Choose how metrics are rendered throughout the app.</CardDescription></CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              {([
                ["energy", "Energy", ["kWh","MJ"]],
                ["water", "Water", ["L","gal"]],
                ["weight", "Weight", ["kg","lb"]],
                ["distance", "Distance", ["km","mi"]],
                ["temperature", "Temperature", ["C","F"]],
              ] as const).map(([key, label, opts]) => (
                <div key={key} className="space-y-2">
                  <Label>{label}</Label>
                  <Select value={settings.units[key]} onValueChange={(v) => update("units", { [key]: v } as Partial<Settings["units"]>)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{opts.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* TARGETS */}
        <TabsContent forceMount value="targets" className="mt-4 space-y-4 data-[state=inactive]:hidden">
          <Card>
            <CardHeader><CardTitle>Sustainability & growth targets</CardTitle><CardDescription>Year-over-year goals used in Insights and Forecast.</CardDescription></CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              {([
                ["co2ReductionPct", "CO₂ reduction (%)"],
                ["energyReductionPct", "Energy reduction (%)"],
                ["waterReductionPct", "Water reduction (%)"],
                ["wasteReductionPct", "Waste reduction (%)"],
                ["salesGrowthPct", "Sales growth (%)"],
              ] as const).map(([key, label]) => (
                <div key={key} className="space-y-2">
                  <Label>{label}</Label>
                  <Input type="number" value={settings.targets[key]}
                    onChange={(e) => update("targets", { [key]: Number(e.target.value) } as Partial<Settings["targets"]>)} />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ALERTS */}
        <TabsContent forceMount value="alerts" className="mt-4 space-y-4 data-[state=inactive]:hidden">
          <Card>
            <CardHeader><CardTitle>Notifications</CardTitle><CardDescription>Choose when ResWatch should reach out.</CardDescription></CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between rounded-md border p-3">
                <div><div className="text-sm font-medium">Email digest</div><div className="text-xs text-muted-foreground">Summary of KPIs sent on a schedule.</div></div>
                <Switch checked={settings.notifications.emailDigest} onCheckedChange={(v) => update("notifications", { emailDigest: v })} />
              </div>
              <div className="flex items-center justify-between rounded-md border p-3">
                <div><div className="text-sm font-medium">Anomaly alerts</div><div className="text-xs text-muted-foreground">Notify when usage spikes beyond threshold.</div></div>
                <Switch checked={settings.notifications.anomalyAlerts} onCheckedChange={(v) => update("notifications", { anomalyAlerts: v })} />
              </div>
              <div className="flex items-center justify-between rounded-md border p-3">
                <div><div className="text-sm font-medium">Forecast alerts</div><div className="text-xs text-muted-foreground">Notify when forecast crosses goal lines.</div></div>
                <Switch checked={settings.notifications.forecastAlerts} onCheckedChange={(v) => update("notifications", { forecastAlerts: v })} />
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2"><Label>Digest frequency</Label>
                  <Select value={settings.notifications.digestFrequency}
                    onValueChange={(v) => update("notifications", { digestFrequency: v as Settings["notifications"]["digestFrequency"] })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2"><Label>Anomaly threshold (% above baseline)</Label>
                  <Input type="number" value={settings.notifications.threshold}
                    onChange={(e) => update("notifications", { threshold: Number(e.target.value) })} /></div>
                <div className="space-y-2 md:col-span-2"><Label>Alert email</Label>
                  <Input type="email" placeholder="ops@yourcompany.com" value={settings.notifications.alertEmail}
                    onChange={(e) => update("notifications", { alertEmail: e.target.value })} /></div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="flex items-center gap-2"><Shield className="h-4 w-4" />Privacy</CardTitle></CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              All settings, including API credentials, are stored locally in your browser only. Use Export to back them up, or Reset to wipe them.
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </PageShell>
  );
}
