import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Trash2, Zap, Droplets, Package, Archive, ChevronRight, Leaf } from "lucide-react";
import { wasteStories, wasteSummary, type WasteCategory } from "@/lib/reswatch-services";

export const Route = createFileRoute("/waste-savings")({
  head: () => ({ meta: [{ title: "Waste & Savings — ResWatch" }] }),
  component: WastePage,
});

const CAT_META: Record<WasteCategory, { label: string; icon: typeof Zap; color: string }> = {
  energy_idle:    { label: "Energy Idle",    icon: Zap,     color: "var(--chart-1)" },
  water_leak:     { label: "Water Leak",     icon: Droplets,color: "var(--chart-2)" },
  stock_spoilage: { label: "Stock Spoilage", icon: Package, color: "var(--chart-4)" },
  overstock:      { label: "Overstock",      icon: Archive, color: "var(--chart-3)" },
};

function WastePage() {
  const stories = useMemo(() => wasteStories(), []);
  const summary = useMemo(() => wasteSummary(), []);
  const [cat, setCat] = useState<"all" | WasteCategory>("all");
  const [open, setOpen] = useState<number | null>(0);

  const filtered = cat === "all" ? stories : stories.filter((s) => s.category === cat);

  return (
    <div className="space-y-6 p-8">
      <header className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3">
          <Trash2 className="h-6 w-6 text-accent-blue" />
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Waste & Savings</h1>
            <p className="text-sm text-muted-foreground">Ranked opportunities — each story shows what to do tonight</p>
          </div>
        </div>
        <div className="rounded-xl border border-border bg-surface px-5 py-3 text-right">
          <p className="text-xs text-muted-foreground">Recoverable in 30 days</p>
          <p className="text-2xl font-semibold text-accent-blue">RM {summary.total_cost_myr.toLocaleString("en-MY", { minimumFractionDigits: 2 })}</p>
          {summary.total_co2e_kg > 0 && (
            <p className="flex items-center justify-end gap-1 text-xs text-chart-2 mt-0.5">
              <Leaf className="h-3 w-3" />
              {summary.total_co2e_kg.toFixed(1)} kg CO₂e avoidable
            </p>
          )}
        </div>
      </header>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {(Object.keys(CAT_META) as WasteCategory[]).map((c) => {
          const m = CAT_META[c]; const Icon = m.icon;
          const active = cat === c;
          const catInfo = summary.categories[c] ?? { cost_myr: 0, co2e_kg: 0, count: 0 };
          return (
            <button key={c} onClick={() => setCat(active ? "all" : c)}
              className={`rounded-xl border p-4 text-left transition-all ${active ? "border-accent-blue/60 bg-accent-blue/5" : "border-border bg-surface hover:border-accent-blue/40"}`}>
              <div className="flex items-center justify-between">
                <Icon className="h-4 w-4" style={{ color: m.color }} />
                <span className="text-xs text-muted-foreground">{catInfo.count}</span>
              </div>
              <p className="mt-3 text-sm text-muted-foreground">{m.label}</p>
              <p className="text-lg font-semibold mt-1">RM {catInfo.cost_myr.toLocaleString("en-MY", { minimumFractionDigits: 2 })}</p>
            </button>
          );
        })}
      </div>

      <div className="space-y-2">
        {filtered.length === 0 && <div className="rounded-xl border border-border bg-surface p-8 text-center text-sm text-muted-foreground">No waste stories in this category — your operation looks clean.</div>}
        {filtered.map((s, i) => {
          const meta = CAT_META[s.category]; const Icon = meta.icon;
          const isOpen = open === i;
          return (
            <div key={i} className="rounded-xl border border-border bg-surface overflow-hidden">
              <button onClick={() => setOpen(isOpen ? null : i)} className="w-full p-4 flex items-center gap-4 text-left">
                <div className="grid h-9 w-9 place-items-center rounded-lg border border-border" style={{ background: `color-mix(in oklab, ${meta.color} 12%, transparent)` }}>
                  <Icon className="h-4 w-4" style={{ color: meta.color }} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm text-foreground">{s.description}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-semibold text-accent-blue">RM {s.cost_myr.toLocaleString("en-MY", { minimumFractionDigits: 2 })}</p>
                  {s.co2e_kg !== null && <p className="text-xs text-muted-foreground">{s.co2e_kg} kg CO₂e</p>}
                </div>
                <ChevronRight className={`h-4 w-4 text-muted-foreground transition-transform ${isOpen ? "rotate-90" : ""}`} />
              </button>
              {isOpen && (
                <div className="border-t border-border bg-surface-elevated/50 p-4">
                  <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Recommended action</p>
                  <p className="mt-1.5 text-sm text-foreground">{s.action}</p>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
