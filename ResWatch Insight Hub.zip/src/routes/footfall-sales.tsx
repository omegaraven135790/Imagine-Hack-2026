import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import {
  ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";
import { Users, ShoppingBag, ArrowRightLeft, Flame } from "lucide-react";
import { format, parseISO } from "date-fns";

import { KpiCard, PeriodSelector } from "@/components/reswatch/kpi-card";
import {
  footfallSummary, dailyFootfallTrend, hourlyHeatmap, peakHours,
} from "@/lib/reswatch-services";
import { daysAgo, isoDay } from "@/lib/reswatch-data";

export const Route = createFileRoute("/footfall-sales")({
  head: () => ({ meta: [{ title: "Footfall & Sales — ResWatch" }] }),
  component: FootfallPage,
});

const DOW_LABELS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const HOURS_SHOWN = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21];

function heatColor(value: number, max: number): string {
  if (max <= 0) return "var(--surface-elevated)";
  const t = Math.max(0, Math.min(1, value / max));
  // interpolate surface → accent-blue using color-mix
  return `color-mix(in oklab, var(--accent-blue) ${Math.round(t * 85)}%, var(--surface-elevated))`;
}

function FootfallPage() {
  const [days, setDays] = useState(14);
  const summary = useMemo(() => footfallSummary(days), [days]);
  const trend = useMemo(() => dailyFootfallTrend(days), [days]);
  const heatmap = useMemo(() => hourlyHeatmap(), []);
  const peaks = useMemo(() => peakHours(5), []);

  // heatmap window: last 7 days dates (display range)
  const heatStart = useMemo(() => isoDay(daysAgo(28)), []);
  const heatEnd = useMemo(() => isoDay(daysAgo(0)), []);

  const heatMap: Record<string, number> = {};
  let heatMax = 1;
  for (const c of heatmap) {
    heatMap[`${c.dow}-${c.hour}`] = c.avg;
    if (c.avg > heatMax) heatMax = c.avg;
  }

  // daily averages by DOW (for hover detail)
  const dayAvg = useMemo(() => {
    const sums: Record<number, { s: number; n: number }> = {};
    for (const c of heatmap) {
      if (!sums[c.dow]) sums[c.dow] = { s: 0, n: 0 };
      sums[c.dow].s += c.avg; sums[c.dow].n += 1;
    }
    const r: Record<number, number> = {};
    for (const [k, v] of Object.entries(sums)) r[Number(k)] = v.n ? v.s / v.n : 0;
    return r;
  }, [heatmap]);

  return (
    <div className="space-y-6 p-8">
      <header className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3">
          <Users className="h-6 w-6 text-accent-blue" />
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Footfall & Sales</h1>
            <p className="text-sm text-muted-foreground">Visitor traffic, revenue & conversion</p>
          </div>
        </div>
        <PeriodSelector value={days} onChange={setDays} />
      </header>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <KpiCard icon={<Users className="h-4 w-4 text-chart-2" />} label="Footfall"
          primary={summary.footfall.total.toLocaleString()}
          secondary={`${summary.footfall.avg_daily.toLocaleString()} visitors/day`}
          delta={summary.footfall.delta_pct} />
        <KpiCard icon={<ShoppingBag className="h-4 w-4 text-chart-1" />} label="Sales Revenue"
          primary={`RM ${summary.sales.revenue_myr.toLocaleString("en-MY", { minimumFractionDigits: 2 })}`}
          secondary={`${summary.sales.transactions.toLocaleString()} txns · avg RM ${summary.sales.avg_transaction_myr.toFixed(2)}`}
          delta={summary.sales.delta_pct} />
        <KpiCard icon={<ArrowRightLeft className="h-4 w-4 text-chart-4" />} label="Conversion Rate"
          primary={`${summary.conversion.rate_pct.toFixed(1)}%`}
          secondary="visitors who made a purchase"
          delta={summary.conversion.delta_pp} deltaSuffix=" pp" />
      </div>

      <div className="rounded-xl border border-border bg-surface p-5 space-y-4">
        <h2 className="text-sm font-semibold">Daily Footfall vs Revenue</h2>
        <ResponsiveContainer width="100%" height={280}>
          <ComposedChart data={trend} margin={{ top: 8, right: 16, bottom: 8, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="date" tickFormatter={(v) => format(parseISO(v), "d MMM")} tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis yAxisId="left" tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} axisLine={false} tickLine={false} width={50} label={{ value: "Visitors", angle: -90, position: "insideLeft", fill: "var(--muted-foreground)", fontSize: 10 }} />
            <YAxis yAxisId="right" orientation="right" tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} axisLine={false} tickLine={false} width={60} tickFormatter={(v) => `RM${(v / 1000).toFixed(0)}k`} />
            <Tooltip contentStyle={{ background: "var(--surface-elevated)", border: "1px solid var(--border)", borderRadius: 8 }}
              labelFormatter={(v) => format(parseISO(v as string), "EEEE, d MMM yyyy")} />
            <Legend wrapperStyle={{ fontSize: 12, paddingTop: 8 }} />
            <Bar yAxisId="left" dataKey="footfall" fill="var(--chart-2)" fillOpacity={0.7} radius={[3, 3, 0, 0]} maxBarSize={24} name="Visitors" />
            <Line yAxisId="right" type="monotone" dataKey="revenue" stroke="var(--chart-3)" strokeWidth={2} dot={false} name="Revenue (RM)" />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 rounded-xl border border-border bg-surface p-5 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <Flame className="h-4 w-4 text-accent-blue" />
              <h2 className="text-sm font-semibold">Busyness Heatmap</h2>
            </div>
            <span className="text-xs text-muted-foreground">avg visitors/hr · {format(parseISO(heatStart), "d MMM")} – {format(parseISO(heatEnd), "d MMM")}</span>
          </div>
          <p className="text-xs text-muted-foreground">Brighter cells = more visitors during that hour, averaged across all matching weekdays in the window.</p>

          <div className="overflow-x-auto no-scrollbar">
            <div className="min-w-[480px]">
              <div className="grid grid-cols-[44px_repeat(7,1fr)] gap-0.5 mb-1">
                <div />
                {DOW_LABELS.map((d, i) => (
                  <div key={d} title={`${d} · daily avg ${(dayAvg[i] ?? 0).toFixed(0)} visitors/hr`} className="text-center text-xs text-muted-foreground pb-1 cursor-help">{d}</div>
                ))}
              </div>
              {HOURS_SHOWN.map((hour) => (
                <div key={hour} className="grid grid-cols-[44px_repeat(7,1fr)] gap-0.5 mb-0.5">
                  <div className="text-right pr-2 text-xs text-muted-foreground/70 leading-6">
                    {hour === 12 ? "12pm" : hour < 12 ? `${hour}am` : `${hour - 12}pm`}
                  </div>
                  {DOW_LABELS.map((_, dow) => {
                    const v = heatMap[`${dow}-${hour}`] ?? 0;
                    return (
                      <div key={dow} title={`${DOW_LABELS[dow]} ${hour}:00 — avg ${v.toFixed(0)} visitors/hr · ${DOW_LABELS[dow]} daily avg ${(dayAvg[dow] ?? 0).toFixed(0)}/hr`}
                        className="rounded-sm h-6 transition-transform hover:scale-110"
                        style={{ background: heatColor(v, heatMax) }} />
                    );
                  })}
                </div>
              ))}

              <div className="flex items-center gap-2 mt-3 justify-end">
                <span className="text-xs text-muted-foreground">Low</span>
                <div className="flex gap-0.5">
                  {[0, 0.2, 0.4, 0.6, 0.8, 1.0].map((t) => (
                    <div key={t} className="h-3 w-5 rounded-sm" style={{ background: heatColor(t * heatMax, heatMax) }} />
                  ))}
                </div>
                <span className="text-xs text-muted-foreground">High</span>
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-xl border border-border bg-surface p-5 space-y-4">
          <div className="flex items-center gap-2">
            <Flame className="h-4 w-4 text-chart-4" />
            <h2 className="text-sm font-semibold">Peak Hours</h2>
          </div>
          <p className="text-xs text-muted-foreground">Top time slots by average footfall (last 28 days)</p>
          {peaks.length === 0 ? (
            <p className="text-sm text-muted-foreground">No data available</p>
          ) : (
            <ol className="space-y-2.5">
              {peaks.map((p, i) => (
                <li key={`${p.dow}-${p.hour}`} className="flex items-center gap-3">
                  <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded text-xs font-bold ${i === 0 ? "bg-chart-4 text-white" : i === 1 ? "bg-chart-4/60 text-white" : "bg-surface-elevated text-muted-foreground"}`}>{i + 1}</span>
                  <span className="flex-1 text-sm text-foreground">{p.label}</span>
                  <span className="text-sm font-medium tabular-nums">{p.avg_count.toFixed(0)}<span className="text-xs text-muted-foreground ml-1">avg</span></span>
                </li>
              ))}
            </ol>
          )}
        </div>
      </div>
    </div>
  );
}
