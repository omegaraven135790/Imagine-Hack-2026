import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Truck,
  Fuel,
  Route as RouteIcon,
  PackageCheck,
  MapPin,
  Gauge,
  Sparkles,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Wrench,
  ArrowRight,
} from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { PageShell } from "@/components/page-shell";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { Toaster } from "@/components/ui/sonner";
import { AddVehicleDialog } from "@/components/transportation/add-vehicle-dialog";
import { ScheduleTab } from "@/components/transportation/schedule-tab";
import { FleetConfigTab } from "@/components/transportation/fleet-config-tab";
import {
  tx,
  type FleetVehicle,
  type Shipment,
  type ShipmentStatus,
  type TransportationRoute,
  type VehicleStatus,
} from "@/lib/transportation-data";

export const Route = createFileRoute("/transportation")({
  head: () => ({
    meta: [
      { title: "Transportation — ResWatch" },
      { name: "description", content: "Fleet, shipments, routes and fuel insights." },
    ],
  }),
  component: TransportationPage,
});

const STATUS_STYLES: Record<ShipmentStatus, string> = {
  planned: "bg-muted text-muted-foreground",
  in_transit: "bg-accent-blue text-accent-blue-foreground",
  delivered: "bg-emerald-500/20 text-emerald-300",
  delayed: "bg-amber-500/20 text-amber-300",
  cancelled: "bg-rose-500/20 text-rose-300",
};

const FUEL_EMOJI: Record<FleetVehicle["fuel_type"], string> = {
  electric: "⚡",
  hybrid: "🌱",
  diesel: "🛢️",
  petrol: "⛽",
};

function TransportationPage() {
  const [tick, setTick] = useState(0);
  const refresh = () => setTick((t) => t + 1);

  const vehicles = useMemo(() => tx.vehicles(), [tick]);
  const shipments = useMemo(() => tx.shipments(), [tick]);
  const routes = useMemo(() => tx.routes(), [tick]);

  const [vehicleOpen, setVehicleOpen] = useState<string | null>(null);
  const [shipmentOpen, setShipmentOpen] = useState<string | null>(null);
  const [routeOpen, setRouteOpen] = useState<string | null>(null);

  const stats = useMemo(() => {
    const todayMs = new Date("2026-06-20T00:00:00Z").getTime();
    return {
      active: vehicles.filter((v) => v.status === "active").length,
      inTransit: shipments.filter((s) => s.status === "in_transit").length,
      deliveredToday: shipments.filter(
        (s) => s.status === "delivered" && new Date(s.actual_arrival ?? 0).getTime() >= todayMs - 86_400_000,
      ).length,
      fuel30d: tx
        .fuelLogs()
        .filter((f) => Date.now() - new Date(f.ts).getTime() < 30 * 86_400_000)
        .reduce((a, b) => a + b.volume_liters, 0),
    };
  }, [vehicles, shipments]);

  return (
    <PageShell title="Transportation 🚚" description="Fleet, shipments, routes — live and historical.">
      <Toaster richColors theme="dark" position="top-right" />
      <Tabs defaultValue="overview" className="flex flex-col gap-6">
        <TabsList className="bg-surface w-fit flex-wrap h-auto">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="schedule">Schedule</TabsTrigger>
          <TabsTrigger value="fleet">Fleet</TabsTrigger>
          <TabsTrigger value="shipments">Shipments</TabsTrigger>
          <TabsTrigger value="routes">Routes</TabsTrigger>
          <TabsTrigger value="config">Fleet Configuration</TabsTrigger>
        </TabsList>

        {/* OVERVIEW */}
        <TabsContent value="overview" className="flex flex-col gap-6">
          <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatTile icon={<Truck className="h-5 w-5" />} label="Active vehicles" value={String(stats.active)} accent />
            <StatTile icon={<PackageCheck className="h-5 w-5" />} label="In transit" value={String(stats.inTransit)} />
            <StatTile icon={<Sparkles className="h-5 w-5" />} label="Delivered today" value={String(stats.deliveredToday)} />
            <StatTile icon={<Fuel className="h-5 w-5" />} label="Fuel · last 30 days" value={`${stats.fuel30d.toLocaleString()} L`} />
          </section>
          <FuelTrendCard />
          <RouteHealthSummary onOpen={setRouteOpen} />
        </TabsContent>

        {/* FLEET */}
        <TabsContent value="fleet" className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Fleet · {vehicles.length} vehicles</h2>
            <AddVehicleDialog onAdded={refresh} />
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {vehicles.map((v) => (
              <button
                key={v.id}
                onClick={() => setVehicleOpen(v.id)}
                className="rounded-xl border-2 border-transparent bg-primary/30 p-4 text-left transition-all hover:-translate-y-0.5 hover:border-accent-blue/60"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-xs text-muted-foreground">{v.registration_no}</div>
                    <div className="mt-0.5 text-base font-semibold">
                      {v.label} <span>{FUEL_EMOJI[v.fuel_type]}</span>
                    </div>
                    <div className="text-xs text-muted-foreground">{v.make} {v.model}</div>
                  </div>
                  <StatusDot status={v.status} />
                </div>
                <div className="mt-3 flex items-center gap-3 text-xs text-muted-foreground">
                  <Gauge className="h-3.5 w-3.5" /> {v.odometer_km.toLocaleString()} km
                  <span>•</span>
                  <span>{v.assigned_driver ?? "—"}</span>
                </div>
              </button>
            ))}
          </div>
        </TabsContent>

        {/* SHIPMENTS */}
        <TabsContent value="shipments">
          <ShipmentsTable shipments={shipments} onOpen={setShipmentOpen} />
        </TabsContent>

        {/* ROUTES */}
        <TabsContent value="routes" className="flex flex-col gap-4">
          <h2 className="text-lg font-semibold">Routes · {routes.length}</h2>
          <div className="grid gap-3 lg:grid-cols-2">
            {routes.map((r) => (
              <RouteSummaryCard key={r.id} route={r} onOpen={() => setRouteOpen(r.id)} />
            ))}
          </div>
        </TabsContent>

        {/* SCHEDULE */}
        <TabsContent value="schedule">
          <ScheduleTab tick={tick} />
        </TabsContent>

        {/* FLEET CONFIGURATION */}
        <TabsContent value="config">
          <FleetConfigTab onChange={refresh} />
        </TabsContent>
      </Tabs>

      <VehicleDrawer id={vehicleOpen} onClose={() => setVehicleOpen(null)} />
      <ShipmentDrawer id={shipmentOpen} onClose={() => setShipmentOpen(null)} />
      <RouteDrawer id={routeOpen} onClose={() => setRouteOpen(null)} />
    </PageShell>
  );
}

// ============== Reusable bits ==============

function StatTile({ icon, label, value, accent }: { icon: React.ReactNode; label: string; value: string; accent?: boolean }) {
  return (
    <div className={["rounded-2xl p-5 transition-transform hover:-translate-y-0.5", accent ? "bg-accent-blue text-accent-blue-foreground shadow-glow-blue" : "border border-border bg-surface"].join(" ")}>
      <div className="flex items-center gap-2 text-xs font-medium opacity-80">{icon}{label}</div>
      <div className="mt-3 text-2xl font-bold">{value}</div>
    </div>
  );
}

function StatusDot({ status }: { status: VehicleStatus }) {
  const map: Record<VehicleStatus, string> = {
    active: "bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.8)]",
    maintenance: "bg-amber-400",
    inactive: "bg-zinc-500",
  };
  return (
    <span className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-muted-foreground">
      <span className={["h-2 w-2 rounded-full", map[status]].join(" ")} />
      {status}
    </span>
  );
}

function StatusBadge({ status }: { status: ShipmentStatus }) {
  return (
    <span className={["inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium capitalize", STATUS_STYLES[status]].join(" ")}>
      {status.replace("_", " ")}
    </span>
  );
}

// ============== Cards ==============

function FuelTrendCard() {
  const data = useMemo(() => {
    const days: Record<string, number> = {};
    tx.fuelLogs().forEach((f) => {
      const d = f.ts.slice(0, 10);
      days[d] = (days[d] ?? 0) + f.volume_liters;
    });
    return Object.entries(days)
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-30)
      .map(([day, liters]) => ({ day: day.slice(5), liters }));
  }, []);

  return (
    <div className="rounded-2xl border border-border bg-surface p-6">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Fuel burn · last 30 days</h2>
        <Badge className="bg-accent-blue/20 text-accent-blue">aggregated from fuel logs</Badge>
      </div>
      <div className="mt-3 h-56">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 10, right: 6, left: -16, bottom: 0 }}>
            <defs>
              <linearGradient id="fuelGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#1E60FF" stopOpacity={0.7} />
                <stop offset="100%" stopColor="#1E60FF" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
            <XAxis dataKey="day" tick={{ fontSize: 10, fill: "#8b95b8" }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 10, fill: "#8b95b8" }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ borderRadius: 8, background: "#1a2240", border: "1px solid #2a3360", fontSize: 12, color: "#fff" }} />
            <Area type="monotone" dataKey="liters" stroke="#1E60FF" strokeWidth={2} fill="url(#fuelGrad)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function RouteHealthSummary({ onOpen }: { onOpen: (id: string) => void }) {
  const rows = useMemo(() => tx.routes().map((r) => analyzeRoute(r)), []);
  return (
    <div className="rounded-2xl border border-border bg-surface p-6">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-lg font-semibold flex items-center gap-2"><RouteIcon className="h-5 w-5 text-accent-blue" />Route health</h2>
        <span className="text-xs text-muted-foreground">click a route for deep-dive</span>
      </div>
      <div className="grid gap-3 lg:grid-cols-2">
        {rows.map((a) => (
          <button
            key={a.route.id}
            onClick={() => onOpen(a.route.id)}
            className="rounded-xl border border-border bg-primary/20 p-4 text-left transition-colors hover:bg-primary/40"
          >
            <div className="flex items-center justify-between">
              <div className="font-medium">{a.route.name}</div>
              <RecommendationBadge kind={a.recommendation.kind} />
            </div>
            <div className="mt-2 grid grid-cols-3 gap-2 text-xs">
              <Metric label="Avg transit" value={fmtDuration(a.avgMinutes)} hint={a.delayPct > 0 ? `+${a.delayPct}% vs plan` : "on plan"} bad={a.delayPct > 10} />
              <Metric label="Shipments 30d" value={String(a.shipments30d)} />
              <Metric
                label="Cargo fill"
                value={`${a.loadPct}%`}
                hint="avg cargo vs truck capacity"
                bad={a.loadPct < 55 || a.loadPct > 92}
              />
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function fmtDuration(min: number) {
  if (min < 60) return `${min} min`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  return m === 0 ? `${h}h` : `${h}h ${m}m`;
}

function Metric({ label, value, hint, bad }: { label: string; value: string; hint?: string; bad?: boolean }) {
  return (
    <div className="rounded-lg bg-background/40 p-2">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={["mt-0.5 text-sm font-semibold", bad ? "text-amber-300" : ""].join(" ")}>{value}</div>
      {hint && <div className="text-[10px] text-muted-foreground">{hint}</div>}
    </div>
  );
}

function ShipmentsTable({ shipments, onOpen }: { shipments: Shipment[]; onOpen: (id: string) => void }) {
  const recent = useMemo(() => shipments.slice(0, 40), [shipments]);
  return (
    <div className="rounded-2xl border border-border bg-surface p-6">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-lg font-semibold">Shipments · last 40</h2>
        <span className="text-xs text-muted-foreground">{shipments.length} total</span>
      </div>
      <div className="overflow-hidden rounded-xl border border-border">
        <table className="w-full text-sm">
          <thead className="bg-primary/40 text-left text-xs uppercase tracking-wider text-muted-foreground">
            <tr>
              <th className="px-4 py-3">Ref</th>
              <th className="px-4 py-3">Route</th>
              <th className="px-4 py-3">Vehicle</th>
              <th className="px-4 py-3">Cargo</th>
              <th className="px-4 py-3">Departed</th>
              <th className="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {recent.map((s, i) => {
              const v = tx.vehicle(s.vehicle_id);
              return (
                <tr
                  key={s.id}
                  onClick={() => onOpen(s.id)}
                  className={["cursor-pointer transition-colors hover:bg-primary/40", i % 2 ? "bg-background/30" : ""].join(" ")}
                >
                  <td className="px-4 py-3 font-mono text-accent-blue">{s.shipment_ref}</td>
                  <td className="px-4 py-3">
                    <span className="flex items-center gap-1.5">
                      <MapPin className="h-3.5 w-3.5 text-muted-foreground" />
                      {tx.locationName(s.origin_location_id)}
                      <ArrowRight className="h-3 w-3 text-muted-foreground" />
                      {tx.locationName(s.destination_location_id)}
                    </span>
                  </td>
                  <td className="px-4 py-3">{v?.label ?? "—"}</td>
                  <td className="px-4 py-3 text-muted-foreground">{s.cargo_description} · {s.cargo_weight_kg}kg</td>
                  <td className="px-4 py-3 text-muted-foreground">{new Date(s.scheduled_departure).toLocaleDateString()}</td>
                  <td className="px-4 py-3"><StatusBadge status={s.status} /></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function RouteSummaryCard({ route, onOpen }: { route: TransportationRoute; onOpen: () => void }) {
  const a = useMemo(() => analyzeRoute(route), [route]);
  return (
    <button
      onClick={onOpen}
      className="rounded-2xl border border-border bg-surface p-5 text-left transition-all hover:-translate-y-0.5 hover:border-accent-blue/60"
    >
      <div className="flex items-center justify-between">
        <div>
          <div className="text-base font-semibold">{route.name}</div>
          <div className="text-xs text-muted-foreground">{route.planned_distance_km} km · plan {fmtDuration(route.estimated_duration_minutes)}</div>
        </div>
        <RecommendationBadge kind={a.recommendation.kind} />
      </div>
      <p className="mt-3 text-sm text-muted-foreground">{a.recommendation.headline}</p>
      <div className="mt-3 grid grid-cols-4 gap-2">
        <Metric label="Avg transit" value={fmtDuration(a.avgMinutes)} />
        <Metric label="Delay vs plan" value={`${a.delayPct}%`} bad={a.delayPct > 10} />
        <Metric label="Trips / week" value={String(Math.round(a.shipments30d / 4))} />
        <Metric label="Cargo fill" value={`${a.loadPct}%`} hint="vs capacity" />
      </div>
    </button>
  );
}

function RecommendationBadge({ kind }: { kind: "consolidate" | "split" | "reroute" | "healthy" }) {
  const map = {
    consolidate: { cls: "bg-accent-blue/20 text-accent-blue", icon: <TrendingDown className="h-3 w-3" />, label: "Consolidate" },
    split: { cls: "bg-purple-500/20 text-purple-300", icon: <TrendingUp className="h-3 w-3" />, label: "Split / scale up" },
    reroute: { cls: "bg-amber-500/20 text-amber-300", icon: <AlertTriangle className="h-3 w-3" />, label: "Reroute" },
    healthy: { cls: "bg-emerald-500/20 text-emerald-300", icon: <Sparkles className="h-3 w-3" />, label: "Healthy" },
  }[kind];
  return <Badge className={["gap-1", map.cls].join(" ")}>{map.icon}{map.label}</Badge>;
}

// ============== Drawers ==============

function VehicleDrawer({ id, onClose }: { id: string | null; onClose: () => void }) {
  const v = id ? tx.vehicle(id) : undefined;
  const fuelLogs = useMemo(() => (id ? tx.fuelLogs().filter((f) => f.vehicle_id === id) : []), [id]);
  const maintenance = useMemo(() => (id ? tx.maintenance().filter((m) => m.vehicle_id === id) : []), [id]);

  // Shipments handled by this vehicle (all-time + last-30d)
  const vehicleShipments = useMemo(
    () => (id ? tx.shipments().filter((s) => s.vehicle_id === id) : []),
    [id],
  );
  const ships30d = useMemo(
    () => vehicleShipments.filter((s) => Date.now() - new Date(s.scheduled_departure).getTime() < 30 * 86_400_000),
    [vehicleShipments],
  );

  // Distance traveled = sum of route planned_distance_km per shipment
  const distance30d = useMemo(
    () => ships30d.reduce((a, s) => a + (tx.route(s.route_id)?.planned_distance_km ?? 0), 0),
    [ships30d],
  );
  const distanceAll = useMemo(
    () => vehicleShipments.reduce((a, s) => a + (tx.route(s.route_id)?.planned_distance_km ?? 0), 0),
    [vehicleShipments],
  );

  // Unique drivers (across all shipments — proxy via assigned_driver history)
  const drivers = useMemo(() => {
    const set = new Set<string>();
    if (v?.assigned_driver) set.add(v.assigned_driver);
    // future: pull from shipment.driver_id once schema is wired
    return Array.from(set);
  }, [v]);

  const fuel30dLiters = useMemo(
    () => fuelLogs.filter((f) => Date.now() - new Date(f.ts).getTime() < 30 * 86_400_000).reduce((a, b) => a + b.volume_liters, 0),
    [fuelLogs],
  );
  const kmPerLiter = fuel30dLiters > 0 ? (distance30d / fuel30dLiters).toFixed(2) : "—";

  // Daily distance (last 21 days) — far more useful than raw speed
  const dailyDistance = useMemo(() => {
    if (!id) return [];
    const byDay: Record<string, number> = {};
    vehicleShipments.forEach((s) => {
      const d = s.scheduled_departure.slice(0, 10);
      byDay[d] = (byDay[d] ?? 0) + (tx.route(s.route_id)?.planned_distance_km ?? 0);
    });
    return Object.entries(byDay)
      .sort(([a], [b]) => a.localeCompare(b))
      .slice(-21)
      .map(([day, km]) => ({ day: day.slice(5), km }));
  }, [id, vehicleShipments]);

  return (
    <Sheet open={!!id} onOpenChange={(o) => !o && onClose()}>
      <SheetContent className="w-full bg-background sm:max-w-2xl overflow-y-auto">
        {v && (
          <>
            <SheetHeader>
              <SheetTitle className="flex items-center gap-2 text-xl">
                {v.label} <span>{FUEL_EMOJI[v.fuel_type]}</span>
              </SheetTitle>
              <SheetDescription>
                {v.registration_no} · {v.make} {v.model} · {v.vehicle_type}
              </SheetDescription>
            </SheetHeader>
            <div className="mt-6 grid grid-cols-4 gap-3">
              <Metric label="Lifetime km" value={v.odometer_km.toLocaleString()} hint="total odometer" />
              <Metric label="Capacity" value={v.capacity_kg ? `${v.capacity_kg.toLocaleString()} kg` : "—"} />
              <Metric label="Shipments · 30d" value={String(ships30d.length)} hint={`${vehicleShipments.length} all-time`} />
              <Metric label="Distance · 30d" value={`${distance30d.toLocaleString()} km`} hint={`${distanceAll.toLocaleString()} km all-time`} />
            </div>
            <div className="mt-3 grid grid-cols-2 gap-3">
              <Metric label="Drivers" value={drivers.length ? drivers.join(", ") : "Unassigned"} hint={`${drivers.length} on record`} />
              <Metric label="Efficiency · 30d" value={kmPerLiter === "—" ? "—" : `${kmPerLiter} km/L`} hint={`${fuel30dLiters} L burned`} />
            </div>

            <Section title="Daily distance · last 21 days (km)">
              <div className="h-44">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={dailyDistance} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
                    <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
                    <XAxis dataKey="day" tick={{ fontSize: 10, fill: "#8b95b8" }} axisLine={false} tickLine={false} label={{ value: "Date", position: "insideBottom", offset: -2, fill: "#8b95b8", fontSize: 10 }} />
                    <YAxis tick={{ fontSize: 10, fill: "#8b95b8" }} axisLine={false} tickLine={false} label={{ value: "km", angle: -90, position: "insideLeft", fill: "#8b95b8", fontSize: 10 }} />
                    <Tooltip contentStyle={{ borderRadius: 8, background: "#1a2240", border: "1px solid #2a3360", fontSize: 12, color: "#fff" }} formatter={(v) => [`${v} km`, "Distance"]} />
                    <Bar dataKey="km" fill="#1E60FF" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Section>

            <Section title={`Fuel log · ${fuelLogs.length} entries`}>
              <ul className="divide-y divide-border rounded-xl border border-border max-h-56 overflow-y-auto">
                {fuelLogs.length === 0 && <li className="p-3 text-sm text-muted-foreground">No entries</li>}
                {fuelLogs.slice(0, 20).map((f) => (
                  <li key={f.id} className="flex items-center justify-between p-3 text-sm">
                    <span className="text-muted-foreground">{new Date(f.ts).toLocaleDateString()}</span>
                    <span>{f.volume_liters} L</span>
                    <span className="text-muted-foreground">RM {f.cost_myr}</span>
                  </li>
                ))}
              </ul>
            </Section>

            <Section title="Maintenance">
              <ul className="space-y-2">
                {maintenance.length === 0 && <li className="text-sm text-muted-foreground">No maintenance events</li>}
                {maintenance.map((m) => (
                  <li key={m.id} className="rounded-xl border border-border bg-primary/20 p-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="flex items-center gap-2 font-medium"><Wrench className="h-4 w-4 text-amber-300" />{m.event_type}</span>
                      <span className="text-muted-foreground">{m.event_date}</span>
                    </div>
                    {m.notes && <p className="mt-1 text-xs text-muted-foreground">{m.notes}</p>}
                  </li>
                ))}
              </ul>
            </Section>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}

function ShipmentDrawer({ id, onClose }: { id: string | null; onClose: () => void }) {
  const s = id ? tx.shipments().find((x) => x.id === id) : undefined;
  const events = useMemo(() => (id ? tx.events().filter((e) => e.shipment_id === id) : []), [id]);
  const v = s ? tx.vehicle(s.vehicle_id) : undefined;
  const r = s ? tx.route(s.route_id) : undefined;

  // Speed profile: X axis = hours from departure
  const telemetry = useMemo(() => {
    if (!id || !s) return [];
    const t0 = new Date(s.actual_departure ?? s.scheduled_departure).getTime();
    return tx
      .telemetry()
      .filter((t) => t.shipment_id === id)
      .map((t) => ({
        hour: +((new Date(t.captured_at).getTime() - t0) / 3_600_000).toFixed(2),
        speed: t.speed_kmh,
      }));
  }, [id, s]);

  const transitMin = s?.actual_arrival && s?.actual_departure
    ? Math.round((new Date(s.actual_arrival).getTime() - new Date(s.actual_departure).getTime()) / 60_000)
    : null;
  const planMin = r?.estimated_duration_minutes ?? null;

  return (
    <Sheet open={!!id} onOpenChange={(o) => !o && onClose()}>
      <SheetContent className="w-full bg-background sm:max-w-2xl overflow-y-auto">
        {s && (
          <>
            <SheetHeader>
              <SheetTitle className="font-mono text-accent-blue">{s.shipment_ref}</SheetTitle>
              <SheetDescription>
                {tx.locationName(s.origin_location_id)} → {tx.locationName(s.destination_location_id)} · {v?.label}
              </SheetDescription>
            </SheetHeader>
            <div className="mt-4 flex items-center gap-3">
              <StatusBadge status={s.status} />
              {transitMin && planMin && (
                <span className="text-xs text-muted-foreground">
                  {fmtDuration(transitMin)} actual vs {fmtDuration(planMin)} plan ({Math.round(((transitMin - planMin) / planMin) * 100)}%)
                </span>
              )}
            </div>

            <Section title="Speed profile · vehicle speed over trip duration">
              <div className="h-44">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={telemetry} margin={{ top: 4, right: 8, left: -10, bottom: 16 }}>
                    <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
                    <XAxis
                      dataKey="hour"
                      type="number"
                      domain={[0, "dataMax"]}
                      tick={{ fontSize: 10, fill: "#8b95b8" }}
                      axisLine={false}
                      tickLine={false}
                      tickFormatter={(h) => `${h}h`}
                      label={{ value: "Hours from departure", position: "insideBottom", offset: -4, fill: "#8b95b8", fontSize: 11 }}
                    />
                    <YAxis tick={{ fontSize: 10, fill: "#8b95b8" }} axisLine={false} tickLine={false} label={{ value: "km/h", angle: -90, position: "insideLeft", fill: "#8b95b8", fontSize: 11 }} />
                    <ReferenceLine y={90} stroke="#f59e0b" strokeDasharray="3 3" label={{ value: "speed limit", fill: "#f59e0b", fontSize: 10, position: "insideTopRight" }} />
                    <Tooltip
                      contentStyle={{ borderRadius: 8, background: "#1a2240", border: "1px solid #2a3360", fontSize: 12, color: "#fff" }}
                      labelFormatter={(h) => `${h}h into trip`}
                      formatter={(val) => [`${val} km/h`, "Speed"]}
                    />
                    <Line type="monotone" dataKey="speed" stroke="#1E60FF" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </Section>

            <Section title="Cargo">
              <div className="grid grid-cols-3 gap-3">
                <Metric label="Description" value={s.cargo_description ?? "—"} />
                <Metric label="Weight" value={`${s.cargo_weight_kg ?? 0} kg`} />
                <Metric label="Volume" value={`${s.cargo_volume_m3 ?? 0} m³`} />
              </div>
            </Section>

            <Section title="Event timeline">
              <ol className="relative ml-3 border-l border-border">
                {events.map((e) => (
                  <li key={e.id} className="mb-3 ml-4">
                    <span className="absolute -left-1.5 h-3 w-3 rounded-full bg-accent-blue" />
                    <div className="text-sm font-medium capitalize">{e.event_type.replace("_", " ")}</div>
                    <div className="text-xs text-muted-foreground">{new Date(e.ts).toLocaleString()}</div>
                    {e.notes && <div className="text-xs text-muted-foreground">{e.notes}</div>}
                  </li>
                ))}
              </ol>
            </Section>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}

function RouteDrawer({ id, onClose }: { id: string | null; onClose: () => void }) {
  const route = id ? tx.route(id) : undefined;
  const analysis = useMemo(() => (route ? analyzeRoute(route) : null), [route]);

  return (
    <Sheet open={!!id} onOpenChange={(o) => !o && onClose()}>
      <SheetContent className="w-full bg-background sm:max-w-3xl overflow-y-auto">
        {route && analysis && (
          <>
            <SheetHeader>
              <SheetTitle>{route.name}</SheetTitle>
              <SheetDescription>
                {route.planned_distance_km} km · plan {fmtDuration(route.estimated_duration_minutes)}
              </SheetDescription>
            </SheetHeader>

            <div className="mt-6 grid grid-cols-4 gap-3">
              <Metric label="Avg transit" value={fmtDuration(analysis.avgMinutes)} hint={analysis.delayPct > 0 ? `+${analysis.delayPct}% vs plan` : "on plan"} />
              <Metric label="Median speed" value={`${analysis.medianSpeed} km/h`} />
              <Metric label="Shipments · 30d" value={String(analysis.shipments30d)} />
              <Metric
                label="Cargo fill"
                value={`${analysis.loadPct}%`}
                hint="avg cargo volume vs capacity"
                bad={analysis.loadPct < 55 || analysis.loadPct > 92}
              />
            </div>

            <Section title={`Speed profile · avg km/h vs hours into trip · ${analysis.spikes} spikes, ${analysis.dips} dips`}>
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={analysis.speedSeries} margin={{ top: 4, right: 8, left: -10, bottom: 18 }}>
                    <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
                    <XAxis
                      dataKey="hour"
                      type="number"
                      domain={[0, "dataMax"]}
                      tick={{ fontSize: 10, fill: "#8b95b8" }}
                      axisLine={false}
                      tickLine={false}
                      tickFormatter={(h) => `${h}h`}
                      label={{ value: "Hours from departure", position: "insideBottom", offset: -4, fill: "#8b95b8", fontSize: 11 }}
                    />
                    <YAxis tick={{ fontSize: 10, fill: "#8b95b8" }} axisLine={false} tickLine={false} label={{ value: "km/h", angle: -90, position: "insideLeft", fill: "#8b95b8", fontSize: 11 }} />
                    <ReferenceLine y={analysis.medianSpeed + 25} stroke="#10b981" strokeDasharray="3 3" label={{ value: "spike", fill: "#10b981", fontSize: 10 }} />
                    <ReferenceLine y={Math.max(0, analysis.medianSpeed - 25)} stroke="#f59e0b" strokeDasharray="3 3" label={{ value: "dip", fill: "#f59e0b", fontSize: 10 }} />
                    <Tooltip
                      contentStyle={{ borderRadius: 8, background: "#1a2240", border: "1px solid #2a3360", fontSize: 12, color: "#fff" }}
                      labelFormatter={(h) => `${h}h into trip`}
                      formatter={(val) => [`${val} km/h`, "Avg speed"]}
                    />
                    <Line type="monotone" dataKey="speed" stroke="#1E60FF" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </Section>

            <Section title="Trips per weekday · last 7 days">
              <div className="h-40">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={analysis.weekly} margin={{ top: 4, right: 4, left: -16, bottom: 18 }}>
                    <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
                    <XAxis dataKey="day" tick={{ fontSize: 11, fill: "#8b95b8" }} axisLine={false} tickLine={false} label={{ value: "Day of week", position: "insideBottom", offset: -4, fill: "#8b95b8", fontSize: 11 }} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 10, fill: "#8b95b8" }} axisLine={false} tickLine={false} label={{ value: "Trips", angle: -90, position: "insideLeft", fill: "#8b95b8", fontSize: 11 }} />
                    <Tooltip contentStyle={{ borderRadius: 8, background: "#1a2240", border: "1px solid #2a3360", fontSize: 12, color: "#fff" }} formatter={(v) => [`${v}`, "Trips"]} />
                    <Bar dataKey="trips" fill="#48539B" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Section>

            <Section title="Recommendation">
              <div className="rounded-xl border border-accent-blue/30 bg-accent-blue/10 p-4">
                <div className="flex items-center gap-2">
                  <RecommendationBadge kind={analysis.recommendation.kind} />
                  <span className="text-sm font-semibold">{analysis.recommendation.headline}</span>
                </div>
                <p className="mt-2 text-sm text-muted-foreground">{analysis.recommendation.rationale}</p>
              </div>
            </Section>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-6">
      <h3 className="mb-2 text-sm font-semibold text-muted-foreground">{title}</h3>
      {children}
    </div>
  );
}

// ============== Analytics ==============

function analyzeRoute(route: TransportationRoute) {
  const ships = tx.shipments().filter((s) => s.route_id === route.id);
  const last30 = ships.filter(
    (s) => Date.now() - new Date(s.scheduled_departure).getTime() < 30 * 86_400_000,
  );

  const durations = ships
    .filter((s) => s.actual_arrival && s.actual_departure)
    .map((s) => (new Date(s.actual_arrival!).getTime() - new Date(s.actual_departure!).getTime()) / 60_000);
  const avgMinutes = durations.length ? Math.round(durations.reduce((a, b) => a + b, 0) / durations.length) : route.estimated_duration_minutes;
  const delayPct = Math.round(((avgMinutes - route.estimated_duration_minutes) / route.estimated_duration_minutes) * 100);

  const tele = tx.telemetry().filter((t) => t.route_id === route.id);
  const speeds = tele.map((t) => t.speed_kmh).sort((a, b) => a - b);
  const medianSpeed = speeds.length ? Math.round(speeds[Math.floor(speeds.length / 2)]) : 0;
  const spikes = tele.filter((t) => t.speed_kmh > medianSpeed + 25).length;
  const dips = tele.filter((t) => t.speed_kmh < Math.max(0, medianSpeed - 25)).length;

  // Speed series binned by hour-from-departure, averaged across all trips on this route.
  const shipById: Record<string, Shipment> = {};
  ships.forEach((s) => { shipById[s.id] = s; });
  const hourBuckets: Record<number, { sum: number; n: number }> = {};
  tele.forEach((t) => {
    const ship = t.shipment_id ? shipById[t.shipment_id] : undefined;
    if (!ship) return;
    const t0 = new Date(ship.actual_departure ?? ship.scheduled_departure).getTime();
    const hr = Math.round(((new Date(t.captured_at).getTime() - t0) / 3_600_000) * 2) / 2; // 0.5h bins
    if (hr < 0 || hr > 48) return;
    const b = hourBuckets[hr] ?? { sum: 0, n: 0 };
    b.sum += t.speed_kmh;
    b.n += 1;
    hourBuckets[hr] = b;
  });
  const speedSeries = Object.entries(hourBuckets)
    .map(([h, b]) => ({ hour: Number(h), speed: Math.round(b.sum / b.n) }))
    .sort((a, b) => a.hour - b.hour);

  // Trips per weekday (Mon–Sun) across the last 7 days
  const WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const weekly = WEEKDAYS.map((day) => ({ day, trips: 0 }));
  const last7Start = Date.now() - 7 * 86_400_000;
  ships.forEach((s) => {
    const t = new Date(s.scheduled_departure).getTime();
    if (t < last7Start) return;
    // JS: 0=Sun..6=Sat → map to Mon-first index
    const idx = (new Date(s.scheduled_departure).getUTCDay() + 6) % 7;
    weekly[idx].trips += 1;
  });

  // Cargo fill (renamed from "load factor"): avg cargo_volume_m3 / assumed capacity 20 m³
  const avgVol = last30.length ? last30.reduce((a, b) => a + (b.cargo_volume_m3 ?? 0), 0) / last30.length : 0;
  const loadPct = Math.min(100, Math.round((avgVol / 20) * 100));

  const shipments30d = last30.length;

  // Demand trend: last 7 days vs prior 7 days
  const prior7Start = Date.now() - 14 * 86_400_000;
  const recent = ships.filter((s) => new Date(s.scheduled_departure).getTime() >= last7Start).length;
  const prior = ships.filter((s) => {
    const t = new Date(s.scheduled_departure).getTime();
    return t >= prior7Start && t < last7Start;
  }).length;
  const demandUp = recent > prior * 1.15;
  const demandDown = recent < prior * 0.85;

  let recommendation: { kind: "consolidate" | "split" | "reroute" | "healthy"; headline: string; rationale: string };
  if (delayPct > 15 || dips > spikes * 3) {
    recommendation = {
      kind: "reroute",
      headline: "Consider an alternate route or off-peak windows",
      rationale: `Avg transit is ${delayPct}% over plan with ${dips} speed dips vs ${spikes} spikes — congestion is the dominant pattern. Try a parallel highway or shift departures outside 07–09h / 17–19h.`,
    };
  } else if (demandUp && loadPct > 80) {
    recommendation = {
      kind: "split",
      headline: "Scale up: increase shipment size or add a second daily run",
      rationale: `Weekly trips up ${Math.round(((recent - prior) / Math.max(1, prior)) * 100)}% with load factor at ${loadPct}%. Upsize per-shipment capacity or split into two runs to keep service levels.`,
    };
  } else if (loadPct < 55 || demandDown) {
    recommendation = {
      kind: "consolidate",
      headline: "Consolidate shipments to cut trip count",
      rationale: `Average load is only ${loadPct}% across ${shipments30d} trips/30d. Merging into ~${Math.max(1, Math.round(shipments30d * 0.7))} larger runs would cut fuel and driver hours without service loss.`,
    };
  } else {
    recommendation = {
      kind: "healthy",
      headline: "Route is performing within healthy bands",
      rationale: `Transit within ${Math.abs(delayPct)}% of plan, load at ${loadPct}%. No action needed — keep monitoring weekly.`,
    };
  }

  return { route, avgMinutes, delayPct, medianSpeed, spikes, dips, speedSeries, weekly, loadPct, shipments30d, recommendation };
}
