import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Leaf, Zap, Droplets, Users, DollarSign, Package, AlertTriangle, Trash2,
  TrendingUp, TrendingDown, Minus, ArrowRight, Sparkles, Target,
  FileSpreadsheet, FileText,
} from "lucide-react";
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid,
  BarChart, Bar, Cell,
} from "recharts";
import {
  energySummary, footfallSummary, wasteSummary, inventorySummary,
  detectAnomalies, dailyEnergyTrend, dailyFootfallTrend, energyByZone,
  topSpoilers, peakHours, co2eFactor,
} from "@/lib/reswatch-services";
import { PeriodSelector } from "@/components/reswatch/kpi-card";
import { gatherReport, downloadXlsx, downloadDocx } from "@/lib/insights-report";
import { STORE, ZONE_LABEL, type Zone } from "@/lib/reswatch-data";

export const Route = createFileRoute("/insights")({
  head: () => ({
    meta: [
      { title: "Insights — ResWatch" },
      { name: "description", content: "Cross-domain operational insights: energy, water, footfall, waste, inventory and CO₂e." },
    ],
  }),
  component: InsightsPage,
});

function Delta({ pct, suffix = "%", invert = false }: { pct: number; suffix?: string; invert?: boolean }) {
  const abs = Math.abs(pct);
  if (abs < 0.1) return <span className="flex items-center gap-1 text-xs text-muted-foreground"><Minus className="h-3 w-3" />Flat</span>;
  const isGood = invert ? pct > 0 : pct < 0;
  const cls = isGood ? "text-chart-2" : "text-destructive";
  const Icon = pct < 0 ? TrendingDown : TrendingUp;
  return <span className={`flex items-center gap-1 text-xs font-medium ${cls}`}><Icon className="h-3 w-3" />{pct < 0 ? "−" : "+"}{abs.toFixed(1)}{suffix}</span>;
}

function fmtRM(n: number) {
  return `RM ${n.toLocaleString("en-MY", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function InsightsPage() {
  const [days, setDays] = useState(7);

  const energy = useMemo(() => energySummary(days), [days]);
  const foot = useMemo(() => footfallSummary(days), [days]);
  const waste = useMemo(() => wasteSummary(), []);
  const inv = useMemo(() => inventorySummary(), []);
  const anomalies = useMemo(() => detectAnomalies(50), []);
  const elecTrend = useMemo(() => dailyEnergyTrend("electricity", days), [days]);
  const waterTrend = useMemo(() => dailyEnergyTrend("water", days), [days]);
  const footTrend = useMemo(() => dailyFootfallTrend(days), [days]);
  const zoneBreak = useMemo(() => energyByZone("electricity", days), [days]);
  const spoilers = useMemo(() => topSpoilers(5), []);
  const peaks = useMemo(() => peakHours(5), []);

  // Prior-period CO2 for delta (electricity drives CO2e)
  const priorEnergy = useMemo(() => {
    // synth: use delta_pct to infer prior kWh
    const prior = energy.electricity.delta_pct === 0
      ? energy.electricity.kwh
      : energy.electricity.kwh / (1 + energy.electricity.delta_pct / 100);
    return { kwh: prior, co2e_kg: prior * co2eFactor() };
  }, [energy]);

  const totalCo2 = energy.electricity.co2e_kg;
  const co2Delta = energy.electricity.delta_pct; // same trend as kWh

  const openHigh = anomalies.filter((a) => a.severity === "HIGH").length;
  const totalCost = energy.electricity.cost_myr + energy.water.cost_myr;
  const grossMargin = foot.sales.revenue_myr - totalCost - waste.total_cost_myr;

  const trend = useMemo(() => {
    return elecTrend.map((e, i) => ({
      date: e.date.slice(5),
      elec: e.value,
      water: waterTrend[i]?.value ?? 0,
      foot: footTrend[i]?.footfall ?? 0,
      rev: footTrend[i]?.revenue ?? 0,
      co2: e.value * co2eFactor(),
    }));
  }, [elecTrend, waterTrend, footTrend]);

  const trees = (totalCo2 / 21).toFixed(1); // 1 tree ≈ 21 kg CO2/yr

  return (
    <div className="space-y-6 p-8">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div className="flex items-center gap-3">
          <Sparkles className="h-6 w-6 text-accent-blue" />
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Insights</h1>
            <p className="text-sm text-muted-foreground">{STORE.name} · last {days} days vs prior {days} days</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => downloadXlsx(gatherReport(days))}
            className="flex items-center gap-1.5 rounded-lg border border-border bg-surface px-3 py-2 text-sm font-medium text-foreground hover:border-accent-blue/60 hover:bg-accent-blue/5"
          >
            <FileSpreadsheet className="h-4 w-4 text-chart-2" /> Excel
          </button>
          <button
            onClick={() => downloadDocx(gatherReport(days))}
            className="flex items-center gap-1.5 rounded-lg border border-border bg-surface px-3 py-2 text-sm font-medium text-foreground hover:border-accent-blue/60 hover:bg-accent-blue/5"
          >
            <FileText className="h-4 w-4 text-chart-1" /> Word
          </button>
          <PeriodSelector value={days} onChange={setDays} options={[7, 14, 30]} />
        </div>
      </header>

      {/* HERO: CO2 + headline KPIs */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-1 rounded-2xl border border-chart-2/40 bg-gradient-to-br from-chart-2/15 via-chart-2/5 to-transparent p-6 shadow-sm">
          <div className="flex items-center gap-2 text-sm text-chart-2 font-medium">
            <Leaf className="h-4 w-4" /> Total CO₂ Emissions
          </div>
          <div className="mt-3 flex items-baseline gap-3">
            <p className="text-4xl font-semibold tracking-tight">{totalCo2.toLocaleString(undefined, { maximumFractionDigits: 0 })}</p>
            <p className="text-sm text-muted-foreground">kg CO₂e</p>
            <Delta pct={co2Delta} invert={false} />
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            Prior {days}d: {priorEnergy.co2e_kg.toLocaleString(undefined, { maximumFractionDigits: 0 })} kg ·
            grid factor {co2eFactor()} kg/kWh
          </p>
          <div className="mt-4 grid grid-cols-2 gap-3 border-t border-chart-2/20 pt-4">
            <div>
              <p className="text-xs text-muted-foreground">From electricity</p>
              <p className="text-base font-semibold">{Math.round(energy.electricity.kwh * co2eFactor()).toLocaleString()} kg CO₂e</p>
              <p className="text-[11px] text-muted-foreground">{energy.electricity.kwh.toLocaleString()} kWh × {co2eFactor()}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">≈ trees to offset / yr</p>
              <p className="text-base font-semibold">{trees} 🌳</p>
            </div>
          </div>
          {waste.total_co2e_kg > 0 && (
            <div className="mt-3 rounded-lg border border-chart-2/30 bg-surface/60 px-3 py-2 text-xs">
              <span className="font-medium text-chart-2">{waste.total_co2e_kg} kg</span>{" "}
              <span className="text-muted-foreground">recoverable by fixing the waste flagged this week.</span>
            </div>
          )}
        </div>

        <div className="lg:col-span-2 grid grid-cols-2 sm:grid-cols-4 gap-3">
          <HeadlineTile icon={<DollarSign className="h-4 w-4" />} label="Revenue" value={fmtRM(foot.sales.revenue_myr)} sub={`${foot.sales.transactions} transactions`} delta={foot.sales.delta_pct} invert />
          <HeadlineTile icon={<Users className="h-4 w-4" />} label="Footfall" value={foot.footfall.total.toLocaleString()} sub={`${foot.footfall.avg_daily}/day avg`} delta={foot.footfall.delta_pct} invert />
          <HeadlineTile icon={<Zap className="h-4 w-4" />} label="Electricity" value={`${energy.electricity.kwh.toLocaleString()} kWh`} sub={fmtRM(energy.electricity.cost_myr)} delta={energy.electricity.delta_pct} />
          <HeadlineTile icon={<Droplets className="h-4 w-4" />} label="Water" value={`${energy.water.m3.toLocaleString()} m³`} sub={fmtRM(energy.water.cost_myr)} delta={energy.water.delta_pct} />
          <HeadlineTile icon={<Target className="h-4 w-4" />} label="Walk-in → paying customer" value={`${foot.conversion.rate_pct}%`} sub={`${foot.conversion.delta_pp >= 0 ? "+" : ""}${foot.conversion.delta_pp}pp vs prior`} />
          <HeadlineTile icon={<Trash2 className="h-4 w-4" />} label="Waste (30d)" value={fmtRM(waste.total_cost_myr)} sub="Recoverable" />
          <HeadlineTile icon={<Package className="h-4 w-4" />} label="At-risk products" value={`${inv.at_risk + inv.low_stock}`} sub={`${inv.at_risk} at risk · ${inv.low_stock} low stock`} />
          <HeadlineTile icon={<AlertTriangle className="h-4 w-4" />} label="Open anomalies" value={`${anomalies.length}`} sub={`${openHigh} high severity`} />
        </div>
      </section>

      {/* Bottom-line strip */}
      <section className="rounded-xl border border-border bg-surface p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Operating contribution · last {days} days</p>
            <p className="mt-1 text-2xl font-semibold">{fmtRM(grossMargin)}</p>
            <p className="text-xs text-muted-foreground">Revenue − utility cost − recoverable waste</p>
          </div>
          <div className="grid grid-cols-3 gap-6 text-sm">
            <Stat label="Revenue" value={fmtRM(foot.sales.revenue_myr)} tone="pos" />
            <Stat label="Utilities" value={`− ${fmtRM(totalCost)}`} tone="neg" />
            <Stat label="Waste" value={`− ${fmtRM(waste.total_cost_myr)}`} tone="neg" />
          </div>
        </div>
      </section>

      {/* Trend chart */}
      <section className="rounded-xl border border-border bg-surface p-5">
        <div className="mb-3 flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold">Cross-domain daily trend</h2>
            <p className="text-xs text-muted-foreground">Electricity (kWh), Water (m³), Footfall, Revenue (RM)</p>
          </div>
        </div>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trend} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="ge" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="var(--chart-1)" stopOpacity={0.5} /><stop offset="95%" stopColor="var(--chart-1)" stopOpacity={0} /></linearGradient>
                <linearGradient id="gw" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="var(--chart-2)" stopOpacity={0.5} /><stop offset="95%" stopColor="var(--chart-2)" stopOpacity={0} /></linearGradient>
                <linearGradient id="gf" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="var(--chart-3)" stopOpacity={0.5} /><stop offset="95%" stopColor="var(--chart-3)" stopOpacity={0} /></linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="date" stroke="var(--muted-foreground)" fontSize={11} />
              <YAxis yAxisId="left" stroke="var(--muted-foreground)" fontSize={11} />
              <YAxis yAxisId="right" orientation="right" stroke="var(--muted-foreground)" fontSize={11} />
              <Tooltip
                contentStyle={{ background: "var(--surface-elevated)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12, color: "var(--foreground)" }}
                itemStyle={{ color: "var(--foreground)" }}
                labelStyle={{ color: "var(--foreground)", fontWeight: 600 }}
              />
              <Area yAxisId="left" type="monotone" dataKey="elec" name="Electricity (kWh)" stroke="var(--chart-1)" fill="url(#ge)" strokeWidth={2} />
              <Area yAxisId="left" type="monotone" dataKey="foot" name="Footfall" stroke="var(--chart-3)" fill="url(#gf)" strokeWidth={2} />
              <Area yAxisId="right" type="monotone" dataKey="water" name="Water (m³)" stroke="var(--chart-2)" fill="url(#gw)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>

      {/* Two-up: zone breakdown + peak hours */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="rounded-xl border border-border bg-surface p-5">
          <h2 className="text-base font-semibold">Electricity by zone</h2>
          <p className="text-xs text-muted-foreground">Where the kWh (and CO₂e) actually go</p>
          <div className="mt-4 h-56">
            <ResponsiveContainer>
              <BarChart data={zoneBreak} layout="vertical" margin={{ left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
                <XAxis type="number" tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="label" width={110} tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip
                  cursor={{ fill: "color-mix(in oklab, var(--foreground) 6%, transparent)" }}
                  contentStyle={{ background: "var(--surface-elevated)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12, color: "var(--foreground)" }}
                  itemStyle={{ color: "var(--foreground)" }}
                  labelStyle={{ color: "var(--foreground)", fontWeight: 600 }}
                  formatter={(v: number) => `${v.toLocaleString()} kWh`}
                />
                <Bar dataKey="value" radius={[0, 6, 6, 0]}>
                  {zoneBreak.map((_, i) => <Cell key={i} fill={`var(--chart-${(i % 5) + 1})`} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-xl border border-border bg-surface p-5">
          <h2 className="text-base font-semibold">Peak demand windows</h2>
          <p className="text-xs text-muted-foreground">Highest-traffic hours · plan staffing & lighting around these</p>
          <ul className="mt-4 space-y-2">
            {peaks.map((p, i) => (
              <li key={i} className="flex items-center justify-between rounded-lg border border-border bg-surface-elevated/60 px-3 py-2">
                <span className="text-sm font-medium">{p.label}</span>
                <span className="text-sm text-muted-foreground">{p.avg_count} avg visitors</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* What to do tonight */}
      <section className="rounded-xl border border-border bg-surface p-5">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold">What to act on next</h2>
            <p className="text-xs text-muted-foreground">Prioritised across waste, inventory and anomalies</p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <ActionList
            title="Top spoiling SKUs"
            linkTo="/inventory"
            rows={spoilers.items.slice(0, 4).map((s) => ({ left: s.name, right: fmtRM(s.spoilage_cost_myr) }))}
            empty="No spoilage in the last 30 days."
          />
          <ActionList
            title="High-severity anomalies"
            linkTo="/anomalies"
            rows={anomalies.filter((a) => a.severity === "HIGH").slice(0, 4).map((a) => ({
              left: `${a.metric}${a.zone ? ` · ${ZONE_LABEL[a.zone as Zone] ?? a.zone}` : ""}`,
              right: `${Math.abs(a.z).toFixed(1)}σ`,
            }))}
            empty="No high-severity anomalies."
          />
          <ActionList
            title="Waste hot-spots"
            linkTo="/waste-savings"
            rows={Object.entries(waste.categories).sort((a, b) => b[1].cost_myr - a[1].cost_myr).slice(0, 4).map(([cat, v]) => ({
              left: cat.replace("_", " "),
              right: fmtRM(v.cost_myr),
            }))}
            empty="No waste flagged."
          />
        </div>
      </section>
    </div>
  );
}

function HeadlineTile({ icon, label, value, sub, delta, invert }: {
  icon: React.ReactNode; label: string; value: string; sub: string; delta?: number; invert?: boolean;
}) {
  return (
    <div className="rounded-xl border border-border bg-surface p-4">
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span className="flex items-center gap-1.5">{icon}{label}</span>
        {delta !== undefined && <Delta pct={delta} invert={invert} />}
      </div>
      <p className="mt-2 text-xl font-semibold tracking-tight">{value}</p>
      <p className="text-xs text-muted-foreground">{sub}</p>
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone: "pos" | "neg" }) {
  return (
    <div>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={`text-base font-semibold ${tone === "pos" ? "text-chart-2" : "text-destructive"}`}>{value}</p>
    </div>
  );
}

function ActionList({ title, linkTo, rows, empty }: {
  title: string; linkTo: string; rows: { left: string; right: string }[]; empty: string;
}) {
  return (
    <div className="rounded-lg border border-border bg-surface-elevated/40 p-4">
      <div className="mb-3 flex items-center justify-between">
        <p className="text-sm font-semibold">{title}</p>
        <Link to={linkTo} className="flex items-center gap-1 text-xs text-accent-blue hover:underline">Open <ArrowRight className="h-3 w-3" /></Link>
      </div>
      {rows.length === 0 ? (
        <p className="text-xs text-muted-foreground">{empty}</p>
      ) : (
        <ul className="space-y-1.5">
          {rows.map((r, i) => (
            <li key={i} className="flex items-center justify-between gap-2 text-sm">
              <span className="truncate capitalize">{r.left}</span>
              <span className="shrink-0 font-medium text-foreground">{r.right}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
