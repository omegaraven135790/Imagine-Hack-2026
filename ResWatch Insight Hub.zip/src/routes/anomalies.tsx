import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { AlertTriangle, Filter, CheckCircle2, RotateCcw } from "lucide-react";
import { format, parseISO } from "date-fns";
import { detectAnomalies, type Severity, type AnomalyEvent } from "@/lib/reswatch-services";

export const Route = createFileRoute("/anomalies")({
  head: () => ({ meta: [{ title: "Anomalies — ResWatch" }] }),
  component: AnomaliesPage,
});

const SEV_STYLES: Record<Severity, string> = {
  HIGH: "bg-destructive/15 text-destructive border-destructive/30",
  MEDIUM: "bg-chart-1/15 text-chart-1 border-chart-1/30",
  LOW: "bg-chart-2/10 text-chart-2 border-chart-2/30",
};

const STORAGE_KEY = "reswatch:resolved-anomalies";

function anomalyKey(a: AnomalyEvent): string {
  return `${a.ts}|${a.metric}|${a.zone ?? "_all"}`;
}

function useResolvedSet() {
  const [set, setSet] = useState<Set<string>>(() => {
    if (typeof window === "undefined") return new Set();
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      return raw ? new Set(JSON.parse(raw) as string[]) : new Set();
    } catch { return new Set(); }
  });
  useEffect(() => {
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify([...set])); } catch { /* ignore */ }
  }, [set]);
  return [set, setSet] as const;
}

function AnomaliesPage() {
  const [sev, setSev] = useState<"all" | Severity>("all");
  const [metric, setMetric] = useState<"all" | "electricity" | "water" | "footfall" | "sales">("all");
  const [view, setView] = useState<"open" | "resolved">("open");
  const [resolved, setResolved] = useResolvedSet();

  const all = useMemo(() => detectAnomalies(80), []);

  const openList = all.filter((a) => !resolved.has(anomalyKey(a)));
  const resolvedList = all.filter((a) => resolved.has(anomalyKey(a)));
  const visible = (view === "open" ? openList : resolvedList)
    .filter((a) => sev === "all" || a.severity === sev)
    .filter((a) => metric === "all" || a.metric === metric);

  const counts: Record<Severity, number> = { HIGH: 0, MEDIUM: 0, LOW: 0 };
  for (const a of openList) counts[a.severity]++;

  function toggle(a: AnomalyEvent) {
    const k = anomalyKey(a);
    const next = new Set(resolved);
    if (next.has(k)) next.delete(k); else next.add(k);
    setResolved(next);
  }

  return (
    <div className="space-y-6 p-8">
      <header className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-3">
          <AlertTriangle className="h-6 w-6 text-accent-blue" />
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Anomalies</h1>
            <p className="text-sm text-muted-foreground">Z-score + IQR detection across electricity, water, footfall & sales</p>
          </div>
        </div>
        <div className="flex items-center gap-1 rounded-lg border border-border bg-surface p-1">
          <button onClick={() => setView("open")} className={`rounded px-3 py-1 text-sm font-medium ${view === "open" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>
            Open <span className="ml-1 text-xs opacity-70">{openList.length}</span>
          </button>
          <button onClick={() => setView("resolved")} className={`rounded px-3 py-1 text-sm font-medium ${view === "resolved" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>
            Resolved <span className="ml-1 text-xs opacity-70">{resolvedList.length}</span>
          </button>
        </div>
      </header>

      <div className="grid grid-cols-3 gap-4">
        {(["HIGH", "MEDIUM", "LOW"] as Severity[]).map((s) => (
          <button key={s} onClick={() => setSev(sev === s ? "all" : s)}
            className={`rounded-xl border p-5 text-left transition-all ${sev === s ? "border-accent-blue/60 bg-accent-blue/5" : "border-border bg-surface hover:border-accent-blue/40"}`}>
            <p className={`text-xs font-semibold uppercase tracking-wide ${s === "HIGH" ? "text-destructive" : s === "MEDIUM" ? "text-chart-1" : "text-chart-2"}`}>{s}</p>
            <p className="text-3xl font-semibold mt-2">{counts[s]}</p>
            <p className="text-xs text-muted-foreground mt-1">open events (last 30d)</p>
          </button>
        ))}
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <Filter className="h-4 w-4 text-muted-foreground" />
        {(["all", "electricity", "water", "footfall", "sales"] as const).map((m) => (
          <button key={m} onClick={() => setMetric(m)}
            className={`rounded-full px-3 py-1 text-xs font-medium border transition-colors ${metric === m ? "border-accent-blue bg-accent-blue text-accent-blue-foreground" : "border-border bg-surface text-muted-foreground hover:text-foreground"}`}>
            {m === "all" ? "All metrics" : m}
          </button>
        ))}
        {sev !== "all" && (
          <button onClick={() => setSev("all")} className="ml-auto text-xs text-muted-foreground hover:text-foreground">Clear severity filter</button>
        )}
      </div>

      <div className="space-y-2">
        {visible.length === 0 && <div className="rounded-xl border border-border bg-surface p-8 text-center text-sm text-muted-foreground">{view === "resolved" ? "No resolved anomalies yet." : "No anomalies match your filters."}</div>}
        {visible.map((a) => {
          const isResolved = resolved.has(anomalyKey(a));
          return (
            <div key={anomalyKey(a)} className="rounded-xl border border-border bg-surface p-4 flex items-start gap-4">
              <span className={`shrink-0 rounded-md border px-2 py-0.5 text-xs font-semibold ${SEV_STYLES[a.severity]}`}>{a.severity}</span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 text-xs text-muted-foreground flex-wrap">
                  <span>{format(parseISO(a.ts), "d MMM yyyy")}</span><span>·</span>
                  <span className="capitalize">{a.metric}</span>
                  {a.zone && <><span>·</span><span className="capitalize">{a.zone.replace("_", " ")}</span></>}
                  <span>·</span><span>z = {a.z.toFixed(2)}</span>
                </div>
                <p className={`mt-1 text-sm ${isResolved ? "text-muted-foreground line-through" : "text-foreground"}`}>{a.description}</p>
              </div>
              <button onClick={() => toggle(a)}
                className={`shrink-0 flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors ${isResolved ? "border-border bg-surface-elevated text-muted-foreground hover:text-foreground" : "border-chart-2/40 bg-chart-2/10 text-chart-2 hover:bg-chart-2/20"}`}>
                {isResolved ? <><RotateCcw className="h-3.5 w-3.5" /> Reopen</> : <><CheckCircle2 className="h-3.5 w-3.5" /> Mark resolved</>}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
