import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import {
  Package, AlertTriangle, TrendingDown, Layers, ShoppingCart,
  Thermometer, Box, Wind,
} from "lucide-react";
import {
  inventoryEnriched, inventorySummary, topSpoilers,
  type InventoryStatus, type EnrichedInventoryItem,
} from "@/lib/reswatch-services";

export const Route = createFileRoute("/inventory")({
  head: () => ({ meta: [{ title: "Inventory & Stock — ResWatch" }] }),
  component: InventoryPage,
});

const STATUS_CFG: Record<InventoryStatus, { label: string; cls: string }> = {
  ok:           { label: "OK",           cls: "bg-muted text-muted-foreground" },
  low_stock:    { label: "Low Stock",    cls: "bg-chart-1/15 text-chart-1 ring-1 ring-chart-1/30" },
  at_risk:      { label: "At Risk",      cls: "bg-destructive/15 text-destructive ring-1 ring-destructive/30" },
  out_of_stock: { label: "Out of Stock", cls: "bg-destructive/20 text-destructive ring-1 ring-destructive/40" },
  overstock:    { label: "Overstock",    cls: "bg-chart-3/15 text-chart-3 ring-1 ring-chart-3/30" },
};

const ZONE_ICON: Record<string, React.ReactNode> = {
  cold:    <Thermometer className="h-3 w-3 text-chart-2" />,
  dry:     <Box className="h-3 w-3 text-chart-1" />,
  ambient: <Wind className="h-3 w-3 text-muted-foreground" />,
};

type StatusFilter = "all" | "at_risk" | "low_stock" | "overstock";

function SummaryCard({
  icon, label, value, sub, highlight = false,
}: { icon: React.ReactNode; label: string; value: string | number; sub: string; highlight?: boolean }) {
  return (
    <div className={`rounded-xl border p-5 space-y-2 ${highlight ? "border-destructive/30 bg-destructive/5" : "border-border bg-surface"}`}>
      <div className="flex items-center gap-2 text-sm text-muted-foreground">{icon}{label}</div>
      <p className={`text-2xl font-semibold ${highlight ? "text-destructive" : "text-foreground"}`}>{value}</p>
      <p className="text-xs text-muted-foreground">{sub}</p>
    </div>
  );
}

function InventoryPage() {
  const items = useMemo(() => inventoryEnriched(), []);
  const summary = useMemo(() => inventorySummary(), []);
  const spoilage = useMemo(() => topSpoilers(7), []);

  const [filter, setFilter] = useState<StatusFilter>("all");
  const [category, setCategory] = useState<string>("all");

  const categories = useMemo(() => Array.from(new Set(items.map((i) => i.category))), [items]);

  const filtered: EnrichedInventoryItem[] = items
    .filter((i) =>
      filter === "all" ? true :
      filter === "low_stock" ? i.status === "low_stock" || i.status === "out_of_stock" :
      i.status === filter
    )
    .filter((i) => category === "all" || i.category === category);

  const reorderItems = items.filter((i) => i.reorder_qty != null && i.reorder_qty > 0);

  const FILTER_TABS: { key: StatusFilter; label: string; count: number }[] = [
    { key: "all",       label: "All",       count: summary.total_items },
    { key: "at_risk",   label: "At Risk",   count: summary.at_risk },
    { key: "low_stock", label: "Low Stock", count: summary.low_stock },
    { key: "overstock", label: "Overstock", count: summary.overstock },
  ];

  return (
    <div className="space-y-6 p-8">
      <div className="flex items-center gap-3">
        <Package className="h-6 w-6 text-accent-blue" />
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Inventory & Stock</h1>
          <p className="text-sm text-muted-foreground">Stock levels, days of cover & spoilage alerts</p>
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <SummaryCard icon={<Package className="h-4 w-4 text-accent-blue" />} label="Total Items" value={summary.total_items} sub="items tracked" />
        <SummaryCard icon={<AlertTriangle className="h-4 w-4 text-destructive" />} label="At Risk" value={summary.at_risk} sub="perishables expiring before sold" highlight={summary.at_risk > 0} />
        <SummaryCard icon={<TrendingDown className="h-4 w-4 text-chart-1" />} label="Low / Out of Stock" value={summary.low_stock} sub="below reorder point" highlight={summary.low_stock > 0} />
        <SummaryCard icon={<Layers className="h-4 w-4 text-chart-2" />} label="Spoilage Cost" value={`RM ${summary.spoilage_cost_myr.toLocaleString("en-MY", { minimumFractionDigits: 2 })}`} sub="last 30 days" />
      </div>

      {/* Items table */}
      <div className="rounded-xl border border-border bg-surface p-5 space-y-4">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          {/* Status filter tabs */}
          <div className="flex items-center gap-1 rounded-lg border border-border bg-surface-elevated p-1">
            {FILTER_TABS.map(({ key, label, count }) => (
              <button key={key} onClick={() => setFilter(key)}
                className={`flex items-center gap-1.5 rounded px-3 py-1.5 text-xs font-medium transition-colors ${filter === key ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>
                {label}
                <span className={`rounded px-1 text-xs tabular-nums ${filter === key ? "bg-primary-foreground/20 text-primary-foreground" : "bg-muted text-muted-foreground"}`}>{count}</span>
              </button>
            ))}
          </div>
          {/* Category filter */}
          <div className="flex items-center gap-1 flex-wrap">
            <button onClick={() => setCategory("all")} className={`rounded-full px-3 py-1 text-xs font-medium border ${category === "all" ? "border-accent-blue bg-accent-blue text-accent-blue-foreground" : "border-border bg-surface-elevated text-muted-foreground hover:text-foreground"}`}>All categories</button>
            {categories.map((c) => (
              <button key={c} onClick={() => setCategory(c)} className={`rounded-full px-3 py-1 text-xs font-medium border ${category === c ? "border-accent-blue bg-accent-blue text-accent-blue-foreground" : "border-border bg-surface-elevated text-muted-foreground hover:text-foreground"}`}>{c}</button>
            ))}
          </div>
        </div>

        {filtered.length === 0 ? (
          <p className="py-8 text-center text-sm text-muted-foreground">No items match these filters</p>
        ) : (
          <div className="overflow-x-auto no-scrollbar">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left text-xs text-muted-foreground">
                  <th className="pb-2 pr-4 font-medium">Item</th>
                  <th className="pb-2 pr-4 font-medium">Category</th>
                  <th className="pb-2 pr-4 font-medium">Zone</th>
                  <th className="pb-2 pr-4 font-medium text-right">Stock / Reorder</th>
                  <th className="pb-2 pr-4 font-medium text-right">Days Covered</th>
                  <th className="pb-2 pr-4 font-medium">Status</th>
                  <th className="pb-2 font-medium text-right">Spoilage (30d)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/60">
                {filtered.map((item) => {
                  const s = STATUS_CFG[item.status];
                  return (
                    <tr key={item.id} className="hover:bg-surface-elevated/40 transition-colors">
                      <td className="py-2.5 pr-4">
                        <p className="text-foreground font-medium leading-tight">{item.name}</p>
                        {item.perishable && <p className="text-[10px] uppercase tracking-wide text-chart-4 mt-0.5">perishable</p>}
                      </td>
                      <td className="py-2.5 pr-4">
                        <span className="rounded px-2 py-0.5 text-xs bg-surface-elevated text-muted-foreground">{item.category}</span>
                      </td>
                      <td className="py-2.5 pr-4">
                        <span className="flex items-center gap-1 text-xs text-muted-foreground capitalize">
                          {ZONE_ICON[item.storage_zone] ?? null}{item.storage_zone}
                        </span>
                      </td>
                      <td className="py-2.5 pr-4 text-right tabular-nums">
                        <span className="font-medium text-foreground">{item.current_stock}</span>
                        <span className="text-muted-foreground"> / {item.reorder_point}</span>
                      </td>
                      <td className="py-2.5 pr-4 text-right tabular-nums text-muted-foreground">
                        {item.days_of_cover == null ? "—" : item.days_of_cover > 999 ? <span className="text-muted-foreground">&gt;999d</span> : `${item.days_of_cover}d`}
                      </td>
                      <td className="py-2.5 pr-4">
                        <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${s.cls}`}>{s.label}</span>
                      </td>
                      <td className="py-2.5 text-right tabular-nums">
                        {item.perishable && item.spoilage_cost_30d > 0
                          ? <span className="text-destructive">RM {item.spoilage_cost_30d.toFixed(2)}</span>
                          : <span className="text-muted-foreground">—</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Bottom row: Top spoilers + Reorder suggestions */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-xl border border-border bg-surface p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold">Top Spoilers — Last 30 Days</h2>
            {spoilage.total_spoilage_myr > 0 && (
              <span className="text-xs text-destructive font-medium tabular-nums">RM {spoilage.total_spoilage_myr.toFixed(2)} total</span>
            )}
          </div>
          {spoilage.items.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4">No spoilage recorded</p>
          ) : (
            <div className="space-y-3">
              {spoilage.items.map((item) => {
                const pct = spoilage.total_spoilage_myr > 0 ? (item.spoilage_cost_myr / spoilage.total_spoilage_myr) * 100 : 0;
                return (
                  <div key={item.id} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-foreground truncate pr-2">{item.name}</span>
                      <span className="text-destructive tabular-nums shrink-0">RM {item.spoilage_cost_myr.toFixed(2)}</span>
                    </div>
                    <div className="h-1.5 w-full rounded-full bg-surface-elevated">
                      <div className="h-1.5 rounded-full bg-destructive/60 transition-all" style={{ width: `${Math.max(pct, 2)}%` }} />
                    </div>
                    <p className="text-xs text-muted-foreground">{item.spoiled_qty} units · {item.category}</p>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="rounded-xl border border-border bg-surface p-5 space-y-4">
          <div className="flex items-center gap-2">
            <ShoppingCart className="h-4 w-4 text-chart-1" />
            <h2 className="text-sm font-semibold">Reorder Suggestions</h2>
          </div>
          <p className="text-xs text-muted-foreground">{reorderItems.length} items below reorder point</p>
          {reorderItems.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">All items are adequately stocked</p>
          ) : (
            <div className="space-y-2 max-h-80 overflow-y-auto no-scrollbar pr-1">
              {reorderItems.map((item) => (
                <div key={item.id} className="flex items-center justify-between rounded-lg border border-border bg-surface-elevated/40 px-3 py-2.5">
                  <div className="min-w-0 pr-2">
                    <p className="text-sm text-foreground truncate">{item.name}</p>
                    <p className="text-xs text-muted-foreground">{item.current_stock} in stock · reorder at {item.reorder_point}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-sm font-medium text-chart-1">+{item.reorder_qty} units</p>
                    <p className="text-xs text-muted-foreground">RM {((item.reorder_qty ?? 0) * item.unit_cost_myr).toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
