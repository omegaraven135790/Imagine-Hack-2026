import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import {
  ComposedChart, Area, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, ReferenceLine,
} from "recharts";
import { Zap, Droplets, Leaf, Sparkles, Calendar } from "lucide-react";
import { format, parseISO } from "date-fns";

import { KpiCard, PeriodSelector } from "@/components/reswatch/kpi-card";
import {
  energySummary, dailyEnergyTrend, energyByZone, forecast, dailyAggregate, elecRate, waterRate,
} from "@/lib/reswatch-services";

export const Route = createFileRoute("/energy-water")({
  head: () => ({ meta: [{ title: "Energy & Water — ResWatch" }] }),
  component: EnergyWaterPage,
});

type Resource = "electricity" | "water";

const TODAY = new Date().toISOString().slice(0, 10);

function EnergyWaterPage() {
  const [days, setDays] = useState(14);
  const [resource, setResource] = useState<Resource>("electricity");
  const [showForecast, setShowForecast] = useState(false);

  const summary = useMemo(() => energySummary(days), [days]);
  const trend = useMemo(() => dailyEnergyTrend(resource, days), [resource, days]);
  const zones = useMemo(() => energyByZone(resource, days), [resource, days]);
  const fc = useMemo(() => showForecast ? forecast(dailyAggregate(resource), 7) : null, [showForecast, resource]);

  // Merge historical (under `actual`) + forecast (under `predicted`) to avoid drop-to-zero artefacts.
  const chartData = useMemo(() => {
    const hist = trend.map((p, i) => ({
      date: p.date,
      actual: p.value,
      ...(fc && i === trend.length - 1 ? { predicted: p.value, lower: p.value, upper: p.value } : {}),
    }));
    if (!fc) return hist;
    const f = fc.points.map((pt) => ({
      date: pt.ts.slice(0, 10), predicted: pt.predicted, lower: pt.lower, upper: pt.upper,
    }));
    return [...hist, ...f];
  }, [trend, fc]);

  const lineColor = resource === "electricity" ? "var(--chart-1)" : "var(--chart-2)";
  const unit = resource === "electricity" ? "kWh" : "m³";

  // forecast aggregate stats
  const fcTotal = fc ? fc.points.reduce((s, p) => s + p.predicted, 0) : 0;
  const fcRate = resource === "electricity" ? elecRate() : waterRate();
  const fcAvg = fc && fc.points.length ? fcTotal / fc.points.length : 0;

  return (
    <div className="space-y-6 p-8">
      <header className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3">
          <Zap className="h-6 w-6 text-accent-blue" />
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Energy & Water</h1>
            <p className="text-sm text-muted-foreground">Usage, cost & carbon — last {days} days vs prior {days} days</p>
          </div>
        </div>
        <PeriodSelector value={days} onChange={setDays} />
      </header>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <KpiCard
          icon={<Zap className="h-4 w-4 text-chart-1" />} label={`Electricity · last ${days}d`}
          primary={`${summary.electricity.kwh.toLocaleString()} kWh`}
          secondary={`RM ${summary.electricity.cost_myr.toLocaleString("en-MY", { minimumFractionDigits: 2 })} · vs prior ${days}d`}
          delta={summary.electricity.delta_pct} invertDelta
        />
        <KpiCard
          icon={<Droplets className="h-4 w-4 text-chart-2" />} label={`Water · last ${days}d`}
          primary={`${summary.water.m3.toLocaleString()} m³`}
          secondary={`RM ${summary.water.cost_myr.toLocaleString("en-MY", { minimumFractionDigits: 2 })} · vs prior ${days}d`}
          delta={summary.water.delta_pct} invertDelta
        />
        <KpiCard
          icon={<Leaf className="h-4 w-4 text-chart-4" />} label="Carbon Footprint"
          primary={`${summary.electricity.co2e_kg.toLocaleString()} kg`}
          secondary={`CO₂e from electricity · last ${days}d`}
          delta={summary.electricity.delta_pct} invertDelta
        />
      </div>

      <div className="rounded-xl border border-border bg-surface p-5 space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h2 className="text-sm font-semibold">Daily Usage Trend</h2>
            {fc && <p className="text-xs text-muted-foreground mt-0.5">Dashed line = 7-day forecast · shaded band = uncertainty</p>}
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {(["electricity", "water"] as const).map((r) => (
              <button key={r} onClick={() => setResource(r)}
                className={`rounded-lg px-3 py-1.5 text-sm font-medium transition-colors ${resource === r ? "bg-accent-blue text-accent-blue-foreground" : "bg-surface-elevated text-muted-foreground hover:text-foreground"}`}>
                {r === "electricity" ? "Electricity" : "Water"}
              </button>
            ))}
            <button onClick={() => setShowForecast((v) => !v)}
              className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-sm font-medium transition-colors ${showForecast ? "border-accent-blue/50 bg-accent-blue/10 text-accent-blue" : "border-border bg-surface-elevated text-muted-foreground hover:text-foreground"}`}>
              <Sparkles className="h-3.5 w-3.5" /> Forecast
            </button>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={260}>
          <ComposedChart data={chartData} margin={{ top: 8, right: 16, bottom: 0, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="date" tickFormatter={(v) => format(parseISO(v), "d MMM")} tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} axisLine={false} tickLine={false} width={50} label={{ value: unit, angle: -90, position: "insideLeft", fill: "var(--muted-foreground)", fontSize: 10 }} />
            <Tooltip
              contentStyle={{ background: "var(--surface-elevated)", border: "1px solid var(--border)", borderRadius: 8, color: "var(--foreground)" }}
              labelFormatter={(v) => format(parseISO(v as string), "EEEE, d MMM yyyy")}
              formatter={(val: number, name: string) => {
                if (name === "actual") return [`${val.toLocaleString()} ${unit}`, "Actual"];
                if (name === "predicted") return [`${val.toLocaleString()} ${unit}`, "Forecast"];
                return [val, name];
              }}
            />
            {fc && (
              <>
                <ReferenceLine x={TODAY} stroke="var(--border)" strokeDasharray="4 4" label={{ value: "Today", position: "top", fill: "var(--muted-foreground)", fontSize: 10 }} />
                <Area type="monotone" dataKey="upper" stroke="none" fill={lineColor} fillOpacity={0.14} legendType="none" isAnimationActive={false} />
                <Area type="monotone" dataKey="lower" stroke="none" fill="var(--background)" fillOpacity={1} legendType="none" isAnimationActive={false} />
              </>
            )}
            <Line type="monotone" dataKey="actual" stroke={lineColor} strokeWidth={2} dot={false} connectNulls={false} />
            {fc && <Line type="monotone" dataKey="predicted" stroke={lineColor} strokeWidth={2} strokeDasharray="6 4" dot={false} opacity={0.85} connectNulls={false} />}
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* Forecast summary stats */}
      {fc && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div className="rounded-xl border border-border bg-surface p-5 space-y-1">
            <p className="text-xs uppercase tracking-wide text-muted-foreground flex items-center gap-1.5"><Calendar className="h-3 w-3" /> Next 7 days · predicted</p>
            <p className="text-2xl font-semibold">{fcTotal.toLocaleString(undefined, { maximumFractionDigits: 0 })} {unit}</p>
            <p className="text-xs text-muted-foreground">≈ RM {(fcTotal * fcRate).toLocaleString("en-MY", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          </div>
          <div className="rounded-xl border border-border bg-surface p-5 space-y-1">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Daily average · predicted</p>
            <p className="text-2xl font-semibold">{fcAvg.toLocaleString(undefined, { maximumFractionDigits: 1 })} {unit}</p>
            <p className="text-xs text-muted-foreground">≈ RM {(fcAvg * fcRate).toLocaleString("en-MY", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}/day</p>
          </div>
          <div className="rounded-xl border border-border bg-surface p-5 space-y-1">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">Forecast model</p>
            <p className="text-lg font-semibold capitalize">{fc.model.replace("_", " ")}</p>
            <p className="text-xs text-muted-foreground">{fc.model === "seasonal_naive" ? "Same weekday last week ± 15%" : "Linear trend ± 20%"}</p>
          </div>
        </div>
      )}

      <div className="rounded-xl border border-border bg-surface p-5 space-y-4">
        <h2 className="text-sm font-semibold">Usage by Zone — last {days} days ({unit})</h2>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={zones} layout="vertical" margin={{ left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal={false} />
            <XAxis type="number" tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis type="category" dataKey="label" width={110} tick={{ fill: "var(--muted-foreground)", fontSize: 11 }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ background: "var(--surface-elevated)", border: "1px solid var(--border)", borderRadius: 8 }} />
            <Bar dataKey="value" radius={[0, 6, 6, 0]}>
              {zones.map((_, i) => <Cell key={i} fill={`var(--chart-${(i % 5) + 1})`} />)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
