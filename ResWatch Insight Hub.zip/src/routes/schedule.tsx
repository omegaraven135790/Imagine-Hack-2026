import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Calendar, ChevronLeft, ChevronRight, RefreshCw, Users } from "lucide-react";
import { generateSchedule, SCHEDULE_METHODS, type ScheduleAssignment, type ScheduleMethod } from "@/lib/reswatch-services";
import { STAFF } from "@/lib/reswatch-data";

export const Route = createFileRoute("/schedule")({
  head: () => ({ meta: [{ title: "Schedule — ResWatch" }] }),
  component: SchedulePage,
});

const SHIFTS = ["morning", "afternoon", "evening"] as const;
type Shift = typeof SHIFTS[number];

const SHIFT_META: Record<Shift, { label: string; time: string; color: string; bg: string }> = {
  morning:   { label: "Morning",   time: "10:00–15:00", color: "text-chart-1", bg: "bg-chart-1/10" },
  afternoon: { label: "Afternoon", time: "14:00–19:00", color: "text-chart-2", bg: "bg-chart-2/10" },
  evening:   { label: "Evening",   time: "18:00–22:00", color: "text-chart-4", bg: "bg-chart-4/10" },
};

const ROLE_CHIP: Record<string, string> = {
  supervisor: "bg-chart-1/15 text-chart-1 border border-chart-1/30",
  cashier:    "bg-chart-2/15 text-chart-2 border border-chart-2/30",
  associate:  "bg-surface-elevated text-foreground border border-border",
};

const DOW_LABELS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

function upcomingMonday(): Date {
  const t = new Date();
  const dow = t.getDay();
  const diff = dow === 0 ? 1 : (8 - dow) % 7;
  const m = new Date(t);
  m.setDate(t.getDate() + diff);
  m.setHours(0, 0, 0, 0);
  return m;
}

function addDays(d: Date, n: number): Date { const x = new Date(d); x.setDate(x.getDate() + n); return x; }
function isoDay(d: Date): string { return d.toISOString().slice(0, 10); }
function fmtDate(d: Date): string { return d.toLocaleDateString("en-MY", { month: "short", day: "numeric" }); }

function StaffChip({ a }: { a: ScheduleAssignment }) {
  const cls = ROLE_CHIP[a.role] ?? ROLE_CHIP.associate;
  const first = a.staff_name.split(" ")[0];
  return (
    <div className={`rounded px-1.5 py-0.5 mb-1 text-xs leading-snug ${cls}`}>
      <div className="font-medium truncate max-w-[88px]">{first}</div>
      <div className="opacity-60 capitalize text-[10px]">{a.role}</div>
    </div>
  );
}

function DemandBadge({ required, got }: { required: number; got: number }) {
  const met = got >= required;
  return (
    <div title={met ? `${got} assigned — demand met (need ${required})` : `${got} assigned — ${required - got} short`}
      className={`mt-1 text-[10px] font-medium tabular-nums select-none ${met ? "text-muted-foreground" : "text-destructive"}`}>
      {met ? `need ${required} ✓` : `need ${required} · ${required - got} short`}
    </div>
  );
}

function SchedulePage() {
  const [weekStart, setWeekStart] = useState<Date>(upcomingMonday);
  const [method, setMethod] = useState<ScheduleMethod>("greedy");
  const [seed, setSeed] = useState<number>(1);

  const schedule = useMemo(
    () => generateSchedule(weekStart, 7, { method, seed }),
    [weekStart, method, seed],
  );
  const days = useMemo(() => Array.from({ length: 7 }, (_, i) => addDays(weekStart, i)), [weekStart]);
  const activeMethod = SCHEDULE_METHODS.find((m) => m.id === method)!;

  const grid = useMemo(() => {
    const g: Record<string, Record<Shift, ScheduleAssignment[]>> = {};
    for (const d of days) g[isoDay(d)] = { morning: [], afternoon: [], evening: [] };
    for (const a of schedule.assignments) g[a.date]?.[a.shift].push(a);
    return g;
  }, [schedule, days]);

  return (
    <div className="space-y-6 p-8">
      <header className="flex items-start justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <Calendar className="h-6 w-6 text-accent-blue" />
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">Staff Schedule</h1>
            <p className="text-sm text-muted-foreground">Demand-driven roster from forecasted footfall</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={method}
            onChange={(e) => setMethod(e.target.value as ScheduleMethod)}
            className="rounded-lg border border-border bg-surface px-3 py-2 text-sm font-medium hover:bg-surface-elevated transition-colors"
          >
            {SCHEDULE_METHODS.map((m) => (
              <option key={m.id} value={m.id}>{m.label}</option>
            ))}
          </select>
          <button
            onClick={() => setSeed((s) => s + 1)}
            className="flex items-center gap-2 rounded-lg bg-accent-blue px-4 py-2 text-sm font-medium text-accent-blue-foreground hover:opacity-90 transition-opacity"
          >
            <RefreshCw className="h-4 w-4" /> Regenerate
          </button>
        </div>
      </header>

      {/* KPIs */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div className="rounded-xl border border-border bg-surface p-4">
          <p className="text-xs text-muted-foreground mb-1">Labor Cost</p>
          <p className="text-xl font-semibold tabular-nums">RM {schedule.total_cost_myr.toLocaleString("en-MY", { minimumFractionDigits: 2 })}</p>
        </div>
        <div className="rounded-xl border border-border bg-surface p-4">
          <p className="text-xs text-muted-foreground mb-1">Staff on Roster</p>
          <p className="text-xl font-semibold tabular-nums">{new Set(schedule.assignments.map((a) => a.staff_id)).size}</p>
        </div>
        <div className="rounded-xl border border-border bg-surface p-4">
          <p className="text-xs text-muted-foreground mb-1">Total Shifts</p>
          <p className="text-xl font-semibold tabular-nums">{schedule.assignments.length}</p>
        </div>
        <div className="rounded-xl border border-border bg-surface p-4">
          <p className="text-xs text-muted-foreground mb-1">Solver</p>
          <p className="text-sm font-semibold uppercase tracking-wide">{schedule.method}</p>
          <p className="text-[11px] text-muted-foreground mt-0.5">seed #{seed}</p>
        </div>
      </div>

      {/* Reason banner */}
      <div className="rounded-lg border border-border bg-surface/60 px-4 py-3 text-sm">
        <span className="font-semibold text-chart-1">{activeMethod.label}</span>
        <span className="text-muted-foreground"> — {activeMethod.description} Required staff per shift = ceil(forecasted visitors × shift-share ÷ 120), minimum 1. Off-days and max-weekly-hours always respected.</span>
      </div>

      {/* Week navigation */}
      <div className="flex items-center gap-3">
        <button onClick={() => setWeekStart(addDays(weekStart, -7))} className="rounded-lg border border-border bg-surface p-1.5 text-muted-foreground hover:text-foreground hover:bg-surface-elevated transition-colors">
          <ChevronLeft className="h-4 w-4" />
        </button>
        <span className="text-sm font-medium">
          {fmtDate(weekStart)} — {fmtDate(addDays(weekStart, 6))}
        </span>
        <button onClick={() => setWeekStart(addDays(weekStart, 7))} className="rounded-lg border border-border bg-surface p-1.5 text-muted-foreground hover:text-foreground hover:bg-surface-elevated transition-colors">
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>

      {/* Schedule grid */}
      <div className="overflow-x-auto no-scrollbar rounded-xl border border-border">
        <table className="w-full min-w-[680px] border-collapse text-sm">
          <thead>
            <tr className="bg-surface border-b border-border">
              <th className="w-28 px-4 py-3 text-left text-muted-foreground font-medium">Shift</th>
              {days.map((d, i) => {
                const ctx = schedule.demand[isoDay(d)];
                return (
                  <th key={isoDay(d)} className="px-2 py-2 text-center font-medium">
                    <div className="font-semibold">{DOW_LABELS[i]}</div>
                    <div className="text-xs text-muted-foreground font-normal">{fmtDate(d)}</div>
                    {ctx && ctx.footfall > 0 && (
                      <div className="mt-1 text-[10px] text-muted-foreground/70 font-normal" title={`Forecasted ${ctx.footfall} visitors`}>
                        ~{ctx.footfall.toLocaleString()} visitors
                      </div>
                    )}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {SHIFTS.map((shift, si) => {
              const meta = SHIFT_META[shift];
              return (
                <tr key={shift} className={si < SHIFTS.length - 1 ? "border-b border-border" : ""}>
                  <td className={`px-4 py-3 align-top ${meta.bg} border-r border-border`}>
                    <div className={`font-semibold ${meta.color}`}>{meta.label}</div>
                    <div className="text-[11px] text-muted-foreground">{meta.time}</div>
                  </td>
                  {days.map((d) => {
                    const cell = grid[isoDay(d)]?.[shift] ?? [];
                    const required = schedule.demand[isoDay(d)]?.required[shift] ?? 1;
                    return (
                      <td key={isoDay(d)} className="px-2 py-2 align-top bg-surface/40 hover:bg-surface transition-colors" style={{ minWidth: 96 }}>
                        {cell.length > 0
                          ? cell.map((a) => <StaffChip key={a.staff_id} a={a} />)
                          : <div className="h-8 flex items-center justify-center"><span className="text-[11px] text-muted-foreground/60">—</span></div>}
                        <DemandBadge required={required} got={cell.length} />
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Staff roster */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 text-muted-foreground" />
          <h2 className="text-sm font-medium text-muted-foreground">Staff Roster & Availability</h2>
        </div>
        <div className="rounded-xl border border-border overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-surface">
                <th className="text-left px-4 py-2.5 text-muted-foreground font-medium">Name</th>
                <th className="text-left px-4 py-2.5 text-muted-foreground font-medium">Role</th>
                <th className="text-left px-4 py-2.5 text-muted-foreground font-medium">Rate/hr</th>
                <th className="text-left px-4 py-2.5 text-muted-foreground font-medium">Max hrs/wk</th>
                <th className="text-left px-4 py-2.5 text-muted-foreground font-medium">Days off</th>
              </tr>
            </thead>
            <tbody>
              {STAFF.map((s, i) => {
                const offDays = DOW_LABELS.filter((_, idx) => s.off_days.includes(idx));
                return (
                  <tr key={s.id} className={i % 2 === 0 ? "bg-surface/40" : "bg-surface/20"}>
                    <td className="px-4 py-2 font-medium">{s.name}</td>
                    <td className="px-4 py-2"><span className={`text-xs rounded px-1.5 py-0.5 ${ROLE_CHIP[s.role] ?? ROLE_CHIP.associate}`}>{s.role}</span></td>
                    <td className="px-4 py-2 text-muted-foreground tabular-nums">RM {s.hourly_rate_myr.toFixed(2)}</td>
                    <td className="px-4 py-2 text-muted-foreground tabular-nums">{s.max_hours_week}h</td>
                    <td className="px-4 py-2 text-muted-foreground">{offDays.length ? offDays.join(", ") : "—"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
