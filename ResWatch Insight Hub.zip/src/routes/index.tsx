import { useMemo } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import {
  TrendingDown, TrendingUp, Zap, Users, DollarSign, Leaf, AlertTriangle, ArrowRight,
} from "lucide-react";
import { MetricCard } from "@/components/dashboard/metric-card";
import { Recommendations, type Recommendation } from "@/components/dashboard/recommendations";
import { UsageChart, type UsagePoint } from "@/components/dashboard/usage-chart";
import { YearlyGoalCard } from "@/components/dashboard/yearly-goal-card";
import {
  energySummary, footfallSummary, wasteSummary, detectAnomalies,
  dailyEnergyTrend, co2eFactor, inventorySummary, topSpoilers,
} from "@/lib/reswatch-services";
import { STORE, ZONE_LABEL, type Zone } from "@/lib/reswatch-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dashboard — ResWatch" },
      { name: "description", content: "ResWatch dashboard overview of savings, sales, and usage." },
    ],
  }),
  component: DashboardPage,
});

const ANNUAL_REVENUE_GOAL = 720000; // RM

function fmtRM(n: number) {
  return `RM ${Math.round(n).toLocaleString("en-MY")}`;
}

function DashboardPage() {
  const energy = useMemo(() => energySummary(30), []);
  const foot = useMemo(() => footfallSummary(30), []);
  const waste = useMemo(() => wasteSummary(), []);
  const inv = useMemo(() => inventorySummary(), []);
  const anomalies = useMemo(() => detectAnomalies(20), []);
  const spoilers = useMemo(() => topSpoilers(3), []);
  const elec14 = useMemo(() => dailyEnergyTrend("electricity", 14), []);

  const co2 = energy.electricity.co2e_kg;
  const metrics = [
    {
      label: "Revenue (30d)",
      value: fmtRM(foot.sales.revenue_myr),
      icon: <DollarSign className="h-5 w-5" />,
      delta: foot.sales.delta_pct,
      invertDelta: true,
    },
    {
      label: "Footfall (30d)",
      value: foot.footfall.total.toLocaleString(),
      icon: <Users className="h-5 w-5" />,
      delta: foot.footfall.delta_pct,
      invertDelta: true,
    },
    {
      label: "Electricity",
      value: `${energy.electricity.kwh.toLocaleString()} kWh`,
      icon: <Zap className="h-5 w-5" />,
      delta: energy.electricity.delta_pct,
      invertDelta: false,
    },
    {
      label: "CO₂e Emissions",
      value: `${co2.toLocaleString()} kg`,
      icon: <Leaf className="h-5 w-5" />,
      delta: energy.electricity.delta_pct,
      invertDelta: false,
    },
  ];

  // Build recommendations from anomalies + waste + spoilage + inventory risk
  const recs: Recommendation[] = useMemo(() => {
    const out: Recommendation[] = [];
    const high = anomalies.filter((a) => a.severity === "HIGH").slice(0, 2);
    for (const a of high) {
      const zone = a.zone ? ` in ${ZONE_LABEL[a.zone as Zone] ?? a.zone}` : "";
      out.push({ id: `a-${a.ts}-${a.metric}`, text: `Investigate ${a.metric} spike${zone} (${Math.abs(a.z).toFixed(1)}σ)` });
    }
    const cats = Object.entries(waste.categories).sort((a, b) => b[1].cost_myr - a[1].cost_myr).slice(0, 2);
    for (const [cat, v] of cats) {
      out.push({ id: `w-${cat}`, text: `Cut ${cat.replace("_", " ")} waste — ${fmtRM(v.cost_myr)} recoverable` });
    }
    if (spoilers.items[0]) {
      out.push({ id: "s-top", text: `Reduce spoilage on ${spoilers.items[0].name} (${fmtRM(spoilers.items[0].spoilage_cost_myr)})` });
    }
    if (inv.at_risk + inv.low_stock > 0) {
      out.push({ id: "inv", text: `Reorder ${inv.low_stock} low-stock SKUs, review ${inv.at_risk} at-risk` });
    }
    return out.slice(0, 6);
  }, [anomalies, waste, spoilers, inv]);

  const chartData: UsagePoint[] = useMemo(
    () => elec14.map((d) => ({ month: d.date.slice(5), liters: Math.round(d.value) })),
    [elec14],
  );

  return (
    <div className="grid flex-1 gap-6 p-8 lg:grid-cols-[1fr_280px]">
      <div className="flex flex-col gap-6">
        <header>
          <h1 className="text-2xl font-semibold tracking-tight">{STORE.name}</h1>
          <p className="text-sm text-muted-foreground">Live operations snapshot · last 30 days vs prior 30</p>
        </header>

        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {metrics.map((m) => (
            <div key={m.label} className="relative">
              <MetricCard label={m.label} value={m.value} icon={m.icon} />
              <DeltaBadge pct={m.delta} invert={m.invertDelta} />
            </div>
          ))}
        </section>

        <Recommendations items={recs} />

        <UsageChart data={chartData} title="Electricity — last 14 days (kWh/day)" />

        {anomalies.length > 0 && (
          <section className="rounded-2xl border border-border bg-surface p-5">
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-destructive" />
                <h2 className="text-sm font-semibold">Recent anomalies</h2>
              </div>
              <Link to="/anomalies" className="flex items-center gap-1 text-xs text-accent-blue hover:underline">
                View all <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
            <ul className="grid gap-2 sm:grid-cols-2">
              {anomalies.slice(0, 4).map((a) => (
                <li key={`${a.ts}-${a.metric}-${a.zone ?? ""}`} className="flex items-center justify-between rounded-lg border border-border bg-surface-elevated/50 px-3 py-2 text-sm">
                  <span className="truncate">
                    <span className={`mr-2 inline-block rounded px-1.5 py-0.5 text-[10px] font-semibold ${a.severity === "HIGH" ? "bg-destructive/15 text-destructive" : a.severity === "MEDIUM" ? "bg-amber-500/15 text-amber-500" : "bg-muted text-muted-foreground"}`}>{a.severity}</span>
                    {a.metric}{a.zone ? ` · ${ZONE_LABEL[a.zone as Zone] ?? a.zone}` : ""}
                  </span>
                  <span className="text-xs text-muted-foreground">{Math.abs(a.z).toFixed(1)}σ</span>
                </li>
              ))}
            </ul>
          </section>
        )}
      </div>

      <aside className="flex flex-col gap-6">
        <YearlyGoalCard current={Math.round(foot.sales.revenue_myr * 12)} goal={ANNUAL_REVENUE_GOAL} />
        <div className="rounded-2xl border border-border bg-surface p-5">
          <p className="text-xs uppercase tracking-wide text-muted-foreground">Recoverable waste (30d)</p>
          <p className="mt-2 text-2xl font-semibold">{fmtRM(waste.total_cost_myr)}</p>
          <p className="text-xs text-muted-foreground">≈ {waste.total_co2e_kg} kg CO₂e avoidable</p>
          <Link to="/waste-savings" className="mt-3 inline-flex items-center gap-1 text-xs text-accent-blue hover:underline">
            Open waste & savings <ArrowRight className="h-3 w-3" />
          </Link>
        </div>
        <div className="rounded-2xl border border-border bg-surface p-5">
          <p className="text-xs uppercase tracking-wide text-muted-foreground">Grid CO₂ factor</p>
          <p className="mt-2 text-2xl font-semibold">{co2eFactor()} <span className="text-sm font-normal text-muted-foreground">kg/kWh</span></p>
          <Link to="/insights" className="mt-3 inline-flex items-center gap-1 text-xs text-accent-blue hover:underline">
            See full insights <ArrowRight className="h-3 w-3" />
          </Link>
        </div>
      </aside>
    </div>
  );
}

function DeltaBadge({ pct, invert }: { pct: number; invert?: boolean }) {
  if (Math.abs(pct) < 0.1) return null;
  const isGood = invert ? pct > 0 : pct < 0;
  const Icon = pct < 0 ? TrendingDown : TrendingUp;
  const cls = isGood ? "bg-emerald-500/20 text-emerald-200" : "bg-rose-500/20 text-rose-100";
  return (
    <span className={`absolute right-3 top-3 flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[10px] font-semibold ${cls}`}>
      <Icon className="h-3 w-3" />
      {pct < 0 ? "−" : "+"}{Math.abs(pct).toFixed(1)}%
    </span>
  );
}
