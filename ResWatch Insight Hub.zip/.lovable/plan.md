## Goal
Make the project install/run cleanly with `npm` in a GitHub Codespace, no `bun` required.

## Changes

1. **Remove bun-specific files**
   - Delete `bun.lock`
   - Delete `bunfig.toml` (its `minimumReleaseAge` guard is a bun-only feature; npm ignores it anyway)

2. **Generate npm lockfile**
   - Run `npm install` to produce `package-lock.json` so the Codespace gets deterministic installs.

3. **Add `.npmrc`** with `legacy-peer-deps=true` only if `npm install` surfaces peer-dep conflicts (React 19 + some Radix/recharts combos sometimes do). Otherwise skip.

4. **Add a short `README.md`** (or update it if present) with npm-only instructions:
   ```
   npm install
   npm run dev       # local dev
   npm run build     # production build
   npm run preview   # serve built output
   ```
   Plus a note on filling in `.env` (Supabase URL/key + `GEMINI_API_KEY`).

5. **No code changes** — `package.json` scripts already use `vite` directly (not `bun`), so `npm run dev/build/preview` already work as-is.

## Out of scope
- No dependency upgrades or swaps.
- No changes to app logic, routes, or `.env` values.
